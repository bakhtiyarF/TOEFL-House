# TOEFL House ERP v3 — Architecture Documentation
### Start Here

This is a rewrite of a live-in-development ERP for a multi-branch English-language institute (Kabul, Afghanistan). v2 wasn't large (51K lines) but had become tangled — not from missing architecture, but from 38 architecture documents that were never enforced against the actual code (`00`, below). This series replaces that with 14 documents: one diagnosis, then a locked, cross-referenced specification for everything that follows.

**Every document assumes zero prior context.** A developer or AI coding agent can open any single file below and have everything it needs, including pointers to whatever else it depends on.

---

## Reading Order

| # | Document | What it decides |
|---|---|---|
| 00 | `CURRENT_STATE_AUDIT.md` | Why v2 became tangled — evidence, not opinion. Read this first regardless of role; everything else answers what this one diagnoses. |
| 01 | `TARGET_ARCHITECTURE.md` | The 8-module map, tech stack (React/TanStack Query/Zustand/shadcn on Laravel/MySQL/Redis), file-size budget, layering rules. *Revision 2 — stack changed once, RBAC approach amended once.* |
| 02 | `BUSINESS_LOGIC_AND_DOMAIN_CONTRACT.md` | Every formula, RBAC rule, and rule-engine definition extracted from v2's actual code — not re-derived from memory. **The most safety-critical document**, since the backend language changed and nothing carries over by copy-paste. |
| 03 | `DESIGN_SYSTEM_AND_UX_STANDARDS.md` | Tokens, components (shadcn/ui), accessibility (WCAG 2.2 AA), RTL rules for the Dari-speaking locale, state contracts. |
| 04 | `REPO_BOOTSTRAP_AND_IAM_MODULE.md` | Repo scaffolding + the Identity & Access module. Everything else depends on this. |
| 05 | `ACADEMIC_MODULE.md` | Programs, levels, classes, students, enrollment, exams, journey. The largest module. |
| 06 | `PEOPLE_HR_MODULE.md` | Teachers, employees, evaluations. |
| 07 | `FINANCE_AND_PAYROLL_MODULE.md` | Budget, payments, payroll, ownership/profit distribution. |
| 08 | `PLATFORM_SERVICES_MODULE.md` | The rule engine, event bus, workflow engine, notifications, audit log — shared by every module above and below it. |
| 09 | `CRM_AND_ENROLLMENT_MODULE.md` | Visitors, lead pipeline, visitor→student conversion. |
| 10 | `INVENTORY_MODULE.md` | Books and sales. |
| 11 | `FUNDING_AND_IMPACT_MODULE.md` | Donors, scholarships, sponsorships, impact reporting. |
| 12 | `REPORTING_DASHBOARD_AND_LAUNCH_READINESS.md` | The presentation-only composition layer, plus what "ready to launch" means for a system with no live users yet. |
| 13 | `INFRASTRUCTURE_AND_DEPLOYMENT.md` | Hosting, CI/CD, environment config, backups — sized to the institute's actual scale. |
| 14 | `ROLE_WORKSPACE_SPECIFICATIONS.md` | Per-role navigation, dashboard content, and quick actions for all 10 roles — the concrete output of `03`'s generative navigation principle. |

**Module build order (04→11) follows dependency, not the numbers above being arbitrary:** IAM first (everything needs auth), then Academic, People & HR, and Finance & Payroll (each depends on the last), then Platform Services (resequenced ahead of schedule once `05`/`07` turned out to already need its rule engine), then CRM & Enrollment, Inventory, and Funding & Impact.

---

## If You're Picking This Up to Build

1. Read `00` and `01` in full. Skim `02`–`03` for shape; you'll return to their exact detail per module.
2. Bootstrap the repo per `04` Part A.
3. Build modules in the order listed above. Each module document is self-contained — its schema, algorithms, routes, and acceptance criteria are all there.
4. Set up `13`'s CI pipeline **before** the first module is considered done — it's the enforcement loop that keeps this from becoming a second `00_CURRENT_STATE_AUDIT.md` in a year.

## The Discipline Every Document Follows

- **One canonical file per concern.** No competing versions — corrections are dated amendments appended in place (see `01`'s §16, `02`'s §10 decision log), never a second document.
- **Specification, not implementation.** None of these 14 files contain PHP or TypeScript source. They specify precisely enough that source code is a mechanical next step, not a judgment call.
- **Every document has Acceptance Criteria and a Definition of Done** — "finished" is a checklist, not a feeling.
- **Flag real ambiguity instead of silently resolving it.** Every place v2's own behavior was internally inconsistent (promotion rules, the reserve fund, scholarship connections, and others) is recorded as a decision with its answer and reasoning, not quietly picked one way.

## Status

All 15 documents are locked as of 2026-08-20. No open decisions remain — the three that surfaced during module builds (promotion mechanism, reserve fund scope, scholarship-to-tuition connection) are resolved and cross-referenced in `02`, `05`, `07`, and `11`. `14` was added after a person-supplied reference file turned out to cover 6 of 10 roles, unverified against real permissions — rebuilt against `02` §5.1 instead, covering all 10.
