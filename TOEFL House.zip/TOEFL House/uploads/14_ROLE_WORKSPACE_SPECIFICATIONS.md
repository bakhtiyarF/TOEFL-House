# 14 — Role Workspace Specifications
### TOEFL House ERP v3 — Per-Role Navigation, Dashboard & Actions

> **Status:** Locked once §8 is confirmed.
> **Depends on:** `02_BUSINESS_LOGIC_AND_DOMAIN_CONTRACT.md` §5.1–5.2 (the only source of truth for what each role may see), `03_DESIGN_SYSTEM_AND_UX_STANDARDS.md` §7 (the generative principle this document produces concrete output for), `12_REPORTING_DASHBOARD_AND_LAUNCH_READINESS.md` (dashboard composition).
> **Audience:** AI coding agent or human developer, zero prior conversation context.
> **Source note:** the person's uploaded `Role_Based_Workspace_UX_UI_Design_Specification.md` covered 6 of v3's 10 roles (Owner, Teacher, Finance, Registrar, Donor Manager, Management), in each case as a plausible-sounding nav tree not checked against real permission codes. Four roles (`head_of_department`, `counselor`, `data_entry`, `designer`) had no description at all. Every section below was rebuilt against `02` §5.1's exact, extracted permission set — the old file's drafts appear only where they held up.

---

## 1. Objective

Specify, per role, exactly what navigation, dashboard content, and quick actions a user sees — precise enough to implement without inventing a screen's contents mid-build.

## 2. Scope / Non-Goals

**In scope:** all 10 roles from `02` §5.1.
**Not in scope:** pixel layout, exact component arrangement — that's ordinary frontend implementation work once tokens/components (`03`) and content (this document) are both fixed. This document says *what's on the screen*, not *where exactly*.

## 3. The Generative Principle, Restated Concretely

`03_DESIGN_SYSTEM_AND_UX_STANDARDS.md` §7 already established the rule: navigation and dashboard widgets are **generated** from the current user's resolved permissions against a `{permission_code → nav item / widget}` registry — never hand-built per role in code. Everything below is **the output of applying that rule to each of the 10 roles**, written out explicitly so nothing has to be inferred or guessed during implementation. Adding an 11th role later means adding rows to the permission tables (`04` §6) — nothing in this document's structure needs to change, and no frontend code changes either, per `03` §7's whole point.

---

## 4. Part A — Per-Role Specifications

Each role: permission summary (from `02` §5.1, not re-derived), the job the workspace is designed around, navigation, dashboard widgets, and primary quick actions (`03` §3's "every widget ends in an action" rule, applied).

### 4.1 `owner` — Course Owner

**Permissions:** `organization` scope on nearly everything. **Cannot** `Attendance.Edit`, `Grade.Edit`, `Student.Delete`, `Payment.Delete` — a deliberate segregation of duties, not an oversight. The UI reflects this exactly: these specific actions are absent for the owner even though almost everything else is present, not just permission-gated the same way as an unauthorized role would see it (§7's state-contract note applies — see there for the distinction).

**Job:** organization-wide oversight and strategic decisions, not day-to-day operations.

**Navigation:** all 8 modules, plus Security (Users, Roles & Permissions), Settings, Audit Logs. Branch selector defaults to "All Branches" (`02` §5.5 — `owner` is the one role that can genuinely request `branchId=all`).

**Dashboard:** cross-branch executive summary — revenue vs. prior period, active students, pending approvals across departments, branch-by-branch comparison, the AI executive summary (`12` §3a). This is the screen replacing v2's 1,723-line `DashboardView.tsx` (`00` §4) most directly.

**Quick actions:** none that bypass the four exclusions above — the owner's dashboard is oversight-first; operational actions route to the role that actually owns them.

### 4.2 `general_manager` — General Manager (legacy role: `manager`)

**Permissions:** `branch` scope on most operational permissions, but **including** `Budget.Allocate` (unlike `finance_manager`). Also the one legacy role with the hardcoded cross-branch carve-out in `resolveBranchScope` (`02` §5.5) — can view a specific other branch by ID even though their permission scope alone wouldn't grant it.

**Job:** run one branch with full operational and budget authority.

**Navigation:** the same 8-module breadth as `owner`, scoped to their branch by default, with the ability to switch to a specific other branch (not "all," per `02` §5.5's exact algorithm) — Security/Audit Logs excluded (that's `owner`-only).

**Dashboard:** branch performance (academic + finance + HR summary in one view), budget utilization (they can allocate it — show it prominently), pending approvals for their branch.

**Quick actions:** Allocate Budget, Approve Expense Request (ties to `08_PLATFORM_SERVICES_MODULE.md`'s workflow instances), switch branch view.

### 4.3 `head_of_department` — Head of Department

**Permissions:** `department` scope, **academic only** — classes, sessions, attendance, exams, grades, promotion approval, certificates. No finance, no HR, no CRM visibility.

**Job:** run the academic side of one department — not in the old uploaded file at all; built fresh against the permission list.

**Navigation:** Academic module only — Classes, Sessions, Attendance, Exams, Grades, Promotions, Certificates. Nothing from Finance & Payroll, People & HR, or CRM & Enrollment appears.

**Dashboard:** department class/session overview, attendance-rate summary (`02` §7.4 #10/#11's warning thresholds surfaced here first), **pending promotion approvals** (`05_ACADEMIC_MODULE.md` §5's now-authoritative `promotion_rules`-based decisions — this is the role that acts on them), certificate issuance queue.

**Quick actions:** Approve/Reject Promotion, Issue Certificate, Review Attendance Exception.

### 4.4 `finance_manager` — Finance Manager

**Permissions:** `branch` scope — payments, invoices, ledger, payroll. **No `Budget.Allocate`** (explicit exclusion, `02` §5.1 — that authority sits with `general_manager`/`owner`).

**Job:** day-to-day financial operations — process payments, run payroll, manage the ledger — without reshaping the budget structure itself.

**Navigation:** Finance & Payroll module in full (Payments, Invoices, Expenses, Payroll, Ledger, Financial Reports), read-only visibility into Budget (can see it, can't allocate it).

**Dashboard:** today's revenue, pending payments, outstanding balances (`07_FINANCE_AND_PAYROLL_MODULE.md`'s `invoices.status` states), payroll due this period (`02` §8.4's ledger), recent transactions. Visual language: the old uploaded file's instinct here — "accuracy, control, trust" — is worth keeping as a design intent, not just a slogan: minimal color, high information density option available (`03` §8), no decorative motion on financial figures (`03` §12).

**Quick actions:** Record Payment, Run Payroll, Create Invoice, Process Expense Request.

### 4.5 `receptionist` — Receptionist (legacy role: `registrar`)

**Permissions:** `branch` scope — leads, student registration, class assignment, payments, **and book sales** (`Book.*` — present in the permission catalog, `02` §5.2, but missing from the old uploaded file's Registration Workspace draft entirely; added here).

**Job:** front desk — the first and most frequent point of contact for visitors and students.

**Navigation:** CRM & Enrollment (Leads/Visitors), Academic (Student registration, Class assignment), Finance & Payroll (Payments — recording only, not the full finance suite), Inventory (Book sales).

**Dashboard:** new leads today, pending registrations, today's enrollments, incomplete student documents.

**Quick actions:** Register Student, Assign Class, Record Payment, Sell Book, Search Student — this is the role most likely on a phone or a shared front-desk device, so these five actions are exactly what `03_DESIGN_SYSTEM_AND_UX_STANDARDS.md` §9's `< 640px` breakpoint requirement is built around.

### 4.6 `counselor` — Counselor

**Permissions:** `branch` scope, **CRM follow-up only** — leads, plus *view-only* students/classes. Not in the old uploaded file at all.

**Job:** nurture leads through the pipeline — needs to reference existing students/classes in conversation (e.g. "here's what a typical class looks like") without being able to edit either.

**Navigation:** CRM & Enrollment (Leads, Follow-ups) as the only editable area; Students and Classes appear read-only, for reference during a lead conversation, not as a working area.

**Dashboard:** my assigned leads, follow-ups due today, pipeline stage breakdown (`08_PLATFORM_SERVICES_MODULE.md`'s `pipeline_metrics`, this role's own pipeline), recent lead activity.

**Quick actions:** Log Follow-up, Update Lead Stage, Search Students/Classes (read-only result).

### 4.7 `teacher` — Teacher

**Permissions:** the one role with per-permission scope rather than one scope for everything (`02` §5.1's exact list): `Dashboard.View`(own), `Student.View`(class), `Class.View`(own), `Session.View`/`Edit`(own), `Attendance.View`/`Edit`(own), `Exam.View`(own), `Grade.View`/`Edit`(own).

**Job:** teach — the old uploaded file's draft here was solid and is preserved with minor precision fixes.

**Navigation:** My Classes, My Timetable, My Students, Attendance, Exams & Grades, My Profile. Nothing outside "own"/"class" scope is reachable, not just hidden — `02` §5.6's ABAC `canAccessClass` check enforces this at the API layer regardless of what the frontend shows.

**Dashboard:** today's classes, next class, pending attendance to mark, upcoming exams, homework to review (`05_ACADEMIC_MODULE.md` §4.2's `homework` table).

**Quick actions:** Mark Attendance, Enter Grades, View Class Roster — the primary mobile-first actions per `03` §9, alongside `receptionist`'s.

### 4.8 `data_entry` — Data Entry

**Permissions:** `branch` scope, entry-focused — create/edit across student, teacher, class, and session records, **no delete, no finance**. Not in the old uploaded file.

**Job:** keep records current — onboarding paperwork, updating contact details, completing partial records — without financial or destructive capability.

**Navigation:** Students, Teachers, Classes, Sessions — create and edit forms only; no delete action ever renders, not just disabled (`03` §7's "UI never implies access it doesn't have").

**Dashboard:** records with incomplete required fields (a genuinely useful "your queue" view for this specific role, not a generic list), recent entries by this user.

**Quick actions:** Add Student, Add Teacher, Complete Profile, Update Contact Info.

### 4.9 `designer` — Designer

**Permissions:** `branch` scope, templates/print only — certificates, student ID card printing, settings *view* (not edit). Not in the old uploaded file. The narrowest operational role in the system.

**Job:** produce physical/printable materials — certificates, ID cards — using the branch's configured templates.

**Navigation:** Certificates (print queue), Student ID Cards (print queue), Settings (read-only — template/branding reference).

**Dashboard:** pending certificate print jobs, pending ID card print jobs.

**Quick actions:** Print Certificate, Print ID Card, Reprint (`05_ACADEMIC_MODULE.md`'s `certificates` table; v2's `ID_CARD_REPRINTED` journey event, `02` §9.1 — this role is exactly who that event represents).

### 4.10 `donor_manager` — Donor Manager

**Permissions:** mixed — `organization` scope for Funding/Impact permissions, `branch` scope for Dashboard/Student/Finance.Report.

**Job:** manage donor relationships, campaigns, and scholarship/sponsorship programs, with organization-wide visibility into that specific domain.

The old uploaded file explicitly flagged this workspace as needing "audit [of] the actual donor functionality rather than assuming a simplified model" before finalizing — that audit is `11_FUNDING_AND_IMPACT_MODULE.md`, done since. Real entities, not a guess:

**Navigation:** Donors, Funding Campaigns, Donations, Scholarships (+ Awards), Sponsorship Agreements, Impact Metrics, Impact Reports, Success Stories — every one a real table in `11` §4, not a "potential" list.

**Dashboard:** active campaign progress (target vs. `raised_amount`), recent donations, pending scholarship awards, sponsorship agreement status, impact metrics snapshot.

**Quick actions:** Record Donation, Award Scholarship (triggers `11` §5's now-automatic tuition connection — this role should see confirmation that awarding a scholarship actually reduced what the student owes, not just that a record was created), Log Impact Metric, Publish Success Story.

---

## 5. Part B — Cross-Role Notes

**Multiple roles per user:** `02` §5.4's resolution order already handles this (a user can hold more than one `user_roles` row) — the generated navigation/dashboard is the *union* of every role's permitted items, not a forced single-role view.

**A new custom role** (the old uploaded file's §11–12, "Custom Role Support"/"Role Builder"): creating one is a data operation — new rows in `roles`/`role_permissions` (`04_REPO_BOOTSTRAP_AND_IAM_MODULE.md` §5) — not a frontend code change, precisely because every section above is generated output, not hand-built. If a future custom role needs a workspace not well-approximated by generation from its permissions alone, that's a new decision at that time, not something this document pre-solves.

---

## 6. Acceptance Criteria

- [ ] Every navigation item and dashboard widget in §4 traces to a specific permission code from `02` §5.1–5.2 — nothing shown "because it seemed relevant."
- [ ] `owner`'s four exclusions (§4.1) render as genuinely absent, not merely disabled.
- [ ] `teacher`'s and `counselor`'s view-only areas cannot be edited from the UI, and the API rejects an edit attempt regardless (`02` §5.6).
- [ ] A role not covered by the old uploaded file (`head_of_department`, `counselor`, `data_entry`, `designer`) has a working dashboard with zero widget-specific code — only permission-registry entries, proving `03` §7's generative principle actually holds.

## 7. Definition of Done

Locked once §6 passes for all 10 roles.

## 8. Rollback

Not applicable — this document only specifies read/generation rules against already-locked permission data; nothing here has state to roll back.

## 9. Where This Gets Implemented

Not a new module. The permission-registry mechanism lives in `03_DESIGN_SYSTEM_AND_UX_STANDARDS.md` §7's `shared/` navigation component; each module's own components (built per `04`–`11`) register their nav items and widgets against it; `12_REPORTING_DASHBOARD_AND_LAUNCH_READINESS.md`'s `DashboardController` composes the dashboard side. This document is what each of those implementations is checked against, not a fifteenth thing to build separately.
