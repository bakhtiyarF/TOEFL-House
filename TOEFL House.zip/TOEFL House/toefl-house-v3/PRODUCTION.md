# TOEFL House ERP v3 — Production & XAMPP Notes
## Per 13_INFRASTRUCTURE_AND_DEPLOYMENT.md

### XAMPP (Windows) — Recommended for local/dev
1. Create DB `toefl_house_v3` in phpMyAdmin
2. Use `server/.env.mysql-xampp` (or copy the block)
3. `php artisan key:generate && php artisan migrate:fresh --force && php artisan db:seed --class=DatabaseSeeder`
4. `php artisan storage:link`
5. `php artisan serve` + `npm run dev` in client

All modules are live-data only.

### Docker (optional local)
```bash
docker compose up --build
```
Includes MySQL, Redis, Mailpit, app service.

### Production (VPS)
- Use `server/.env.production.example`
- `APP_DEBUG=false`
- `APP_TIMEZONE=Asia/Kabul`
- Run `scripts/deploy.sh v3.0.0-launch` (or manual equivalent)
- Supervisor manages php-fpm + nginx + queue worker
- Daily backups via `scripts/backup-cron.sh`

### CI/CD
- Every PR/push: Pest + Vitest + tsc --noEmit (blocks merge on failure)
- Merge to main → staging
- Tag → production only

### Launch Checklist (12 + 13)
- [x] All modules acceptance criteria
- [x] CI blocks bad merges
- [x] Backups tested (script + manual)
- [x] Timezone correct
- [x] APP_DEBUG=false in prod templates
- [ ] Tag v3.0.0-launch when ready

Current overall progress: ~93-94% (see BUILD_ORDER.md)