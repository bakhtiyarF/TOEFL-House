# TOEFL House ERP v3

**Production-grade Laravel 12 + React 19 educational institute ERP** (Kabul, Afghanistan).

Fully implements 14 locked specification documents with:
- 10 generative role-based workspaces (owner, general_manager, head_of_department, finance_manager, receptionist, counselor, teacher, data_entry, designer, donor_manager)
- Strict RBAC via PermissionResolutionService + BranchScopeService
- Live data everywhere (no hardcoded demo numbers)
- Generative navigation, dashboards, quick actions (from `navRegistry`)
- Full live flows: promotions (exam avg + roster attendance), certificates (3 templates + print/PDF), donor impact/ledger, CRM follow-ups, payments, attendance, etc.

## Tech
- Backend: Laravel 12 (PHP 8.4), Sanctum, multi-tenancy
- Frontend: React 19 + Vite + TanStack Query + shadcn + Zustand (UI only)
- Bundle target: ~770-800 KB

## Quick Start (Dev)
```bash
# Backend
cd server
cp .env.example .env
composer install
php artisan key:generate
php artisan migrate

# Seed realistic live data (highly recommended)
php artisan db:seed --class=DatabaseSeeder
# or
php artisan db:seed --class=EnhancedSampleDataSeeder

# Frontend
cd ../client
npm install
npm run dev
```

## Seeding for Live Features
The **EnhancedSampleDataSeeder** creates realistic data that powers:
- Active students + classes + rosters (attendance + promotion)
- Payments, journey events
- **Certificates** (classic/modern/minimal) → live issuance + preview + print/PDF
- **Donations + campaigns + impact metrics** → donor_manager Funding/Impact + ledger
- **Follow-ups** → CRM Visitors follow-up dialog (useVisitorFollowups)
- Exam results → live PromotionService recommendations

After seeding you can:
- Switch roles (bottom-right RoleSwitcher)
- See fully live dashboards, GenerativeQuickActions, promotion tab, certificate queue, donor ledger, etc.
- Use "Record Donation", "Issue Certificate", "Log Follow-up" etc. with real mutations

## Key Live Features (per 14_ROLE + 02 specs)
- Generative nav + widgets + quick actions (usePermissions + navRegistry)
- Promotion tab in Classes (evaluatePromotion using live exam avg + roster attendance_rate)
- Certificates: issue + live preview (3 templates) + `usePrintCertificate` (backend HTML + printable.html + JSON + DomPDF path)
- Donor Manager: organization Funding/Impact + DonorLedger + exports
- CRM: live visitors + follow-up dialog with prior history
- Finance: live transactions, budget, payroll computation
- Owner exclusions enforced (`Attendance.Edit`, `Grade.Edit`, `Student.Delete`, `Payment.Delete`)

## Build
```bash
cd client
npm run build   # ~795-800 KB (gz ~222 KB)
```

## Current Status (as of 2026-08-23)
- 100% live data preference (zero user-facing hardcoded demo numbers)
- Full generative RBAC navigation/dashboards/QA
- Certificates print/PDF hardened (backend blade + client printable + future blob)
- Donor ledger + impact + quick actions live
- CRM follow-ups fully wired
- Enhanced seeder for all 10 roles
- Clean successful builds

Advanced items (real Zoom, PWA, full DomPDF blob in all envs) remain future scope.

See `docs/` and the 14 specification files for exact contracts.
