# Per-Role Workspace Validation Checklist
**For 14_ROLE_WORKSPACE_SPECIFICATIONS.md (now 100% complete)**

Use this checklist after every `continue` or before tagging releases.

## Prerequisites (XAMPP + Live Data)
1. `.env` (server) exactly:
   ```
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=toefl_house_v3
   DB_USERNAME=root
   DB_PASSWORD=
   ```
2. `cd server && php artisan migrate:fresh --force && php artisan db:seed --class=DatabaseSeeder`
3. Start:
   - Backend: `php artisan serve`
   - Client: `cd ../client && npm run dev`
4. Open http://localhost:5173 (or Vite port)

## How to Validate (Two Tools)
- **RoleSwitcher** (bottom-right floating panel) — switches live user
- **RoleWorkspaceValidator** (bottom of Dashboard + inside Settings → Security tab) — automated PASS/FAIL table

**Recommended flow for each role:**
1. Switch role with RoleSwitcher.
2. Hard refresh (Ctrl+Shift+R) if needed.
3. Scroll to bottom of Dashboard → run "Validate Current".
4. Manually verify the items below.
5. Try 1–2 live quick actions.

---

## Role-by-Role Checklist

### 1. owner (username: owner)
- [ ] Sidebar: Dashboard, Students, Classes, Finance, Inventory, Funding & Impact, Settings, Audit Logs, Users & Roles, Certificates, **Teachers**, **Employees**
- [ ] Dashboard shows: executiveSummary, stats, budgetUtilization, impactMetrics, pendingPromotions, certificateQueue
- [ ] Quick Actions: recordPayment, recordDonation, allocateBudget, awardScholarship, exportImpactReport, issueCertificate, **addTeacherEvaluation**, etc.
- [ ] **Owner exclusions visible**: "sensitive operational actions ... hidden" notice + no Attendance.Edit / Grade.Edit / Student.Delete / Payment.Delete buttons
- [ ] **06 HR verification**: Navigate to Teachers → see 5+ seeded teachers → open detail (Dollar icon) → see live Evaluations list + "+ Add Evaluation" dialog (date, criteria dropdown, score 0-5, notes) → live save + avg badge refresh + Salary History panel + "Process Full Salary (Live)" button
- [ ] Can view all reports (Financial, Payroll, Certificate PDF via DomPDF)
- [ ] RoleWorkspaceValidator: PASS + 06 HR column green + "✓ 06 Teachers + Evaluations + Salary History visible" indicator

### 2. general_manager (general_mgr)
- [ ] Nav: Dashboard + Students + Classes + Finance + Inventory + Funding + **Teachers** + **Employees**
- [ ] Widgets: stats, budgetUtilization, leadsPipeline, pendingPromotions
- [ ] Quick Actions include allocateBudget + recordPayment + **addTeacherEvaluation**
- [ ] **06 HR verification**: Teachers nav visible + open Teachers detail → Evaluations + Add Evaluation live + Salary History visible
- [ ] Validator: PASS + 06 HR column green

### 3. head_of_department (hod)
- [ ] Nav: Dashboard, Students, Classes, Sessions, Certificates, **Teachers**
- [ ] Prominent: pendingPromotions + certificateQueue
- [ ] Quick Action: Approve Promotion (goes to Classes#promotion)
- [ ] **06 HR verification**: Teachers nav present (but limited access); Teachers detail shows Evaluations + Add Evaluation (live) + performance avg
- [ ] No Finance or Funding nav items
- [ ] Validator: PASS + 06 HR column green

### 4. finance_manager (finance_mgr)
- [ ] Nav: Dashboard, Finance, Inventory, Funding (view), Students (limited)
- [ ] Widgets: todayRevenue, pendingPayments, payrollDue
- [ ] Can record payments + view donor ledger
- [ ] **No** Budget.Allocate quick action (per spec)
- [ ] Validator: PASS

### 5. receptionist (reception)
- [ ] Nav: Dashboard, Students, Classes, Visitors & Leads, Inventory, Finance (limited)
- [ ] Strong: leadsPipeline + followUpsDue
- [ ] Quick actions: Add Visitor, Log Follow-up, Register Student, Record Payment
- [ ] Validator: PASS

### 6. counselor (counselor)
- [ ] Nav: Dashboard, Visitors & Leads, Students (view), Classes (view)
- [ ] Focus: leadsPipeline + followUpsDue
- [ ] Quick actions limited to logFollowup / addVisitor
- [ ] Validator: PASS

### 7. teacher (teacher1)
- [ ] Nav: Dashboard, Classes (own), Students (class-scoped), Sessions (own)
- [ ] Widgets: attendanceSummary, upcomingExams, gradesOverview (narrow)
- [ ] Quick action: Mark Attendance (goes to class)
- [ ] **Very limited** — only own classes visible in live data
- [ ] Validator: PASS

### 8. data_entry (data_entry)
- [ ] Nav: Dashboard, Students, Classes, Visitors & Leads
- [ ] Quick actions: registerStudent, addVisitor, markAttendance (no delete, no finance)
- [ ] Validator: PASS

### 9. designer (designer)
- [ ] Nav: Dashboard, Certificates, Students/Classes (view only)
- [ ] Strong certificateQueue
- [ ] Quick actions: Issue Certificate + Print Recent Certificate (uses DomPDF path)
- [ ] Validator: PASS

### 10. donor_manager (donor_mgr)
- [ ] Nav: Dashboard, Funding & Impact, Students (view), Finance (report)
- [ ] Prominent: impactMetrics, campaignProgress, recentDonations, DonorLedger snapshot
- [ ] Quick actions: recordDonation, awardScholarship, newCampaign, exportImpactReport, exportDonorLedger
- [ ] Exports produce live CSV + printable HTML
- [ ] Validator: PASS

---

## Full Automated + Manual Sweep (Recommended)
1. Click **"Validate All 10 Roles"** in the validator (on Dashboard).
2. For every role that shows FAIL:
   - Switch to it
   - Manually inspect sidebar + widgets + quick actions
   - Run "Validate Current"
3. For every role: perform at least one live mutation (e.g. record a donation or issue a certificate).

## Expected Outcome
- All 10 roles produce **correct generative workspaces** instantly.
- No hardcoded demo numbers anywhere.
- Owner exclusions strictly enforced.
- All quick actions perform real DB writes.

## After Validation
- Update this checklist with date + tester name.
- If all green → 14_ROLE is production-ready.

**Last validated:** 2026-08-24 (via RoleWorkspaceValidator + RoleSwitcher)

---
*This checklist is the practical implementation of 14 §7 (Validation Requirements) and §8 (Acceptance Criteria).*
