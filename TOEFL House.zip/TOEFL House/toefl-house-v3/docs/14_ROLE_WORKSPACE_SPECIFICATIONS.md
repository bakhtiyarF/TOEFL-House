# 14 — Role Workspace Specifications
### TOEFL House ERP v3 — Per-Role Navigation, Dashboards & Quick Actions

> **Status:** Locked (2026-08-24)  
> **Depends on:** `02_BUSINESS_LOGIC_AND_DOMAIN_CONTRACT.md` §5 (roles/permissions/scope), `03_DESIGN_SYSTEM_AND_UX_STANDARDS.md` §7 (generative nav/widgets), `04_REPO_BOOTSTRAP_AND_IAM_MODULE.md`, `05_ACADEMIC_MODULE.md`, `07_FINANCE...`, `08_PLATFORM...`, `09_CRM...`, `11_FUNDING...`, `12_REPORTING...`  
> **Audience:** AI coding agent or human developer. This document is the authoritative definition of per-role "workspace" (nav + dashboard + quick actions + exclusions).  
> **Core Principle (03 §7 + 02 §5):** Everything is **generative**. Navigation, dashboard widgets, and quick actions are derived from the current user's resolved permissions (via `PermissionResolutionService` + `navRegistry.ts`). No hand-coded per-role pages. A new role requires only a permission row + registry entry.

---

## 1. Objective

Define **exactly** what each of the 10 roles sees and can do in their primary workspace:
- Sidebar navigation items (and groups)
- Dashboard widgets (composition layer + module fallbacks)
- Generative Quick Actions (live mutations)
- Owner exclusions (14 §4.1)
- Scope behavior (branch vs org)
- Role-specific notes (e.g. teacher limited to own classes)

All must be **live-data only** (zero hardcoded demo numbers except extreme fallbacks). Must be verifiable instantly via RoleSwitcher + seeded users.

## 2. The 10 Roles (from 02 §5.1)

| Role Code          | Display Name         | Default Scope | Key Permissions (examples)                          | Notable Carve-outs / Notes |
|--------------------|----------------------|---------------|-----------------------------------------------------|----------------------------|
| `owner`            | Course Owner        | organization  | Full access except 4 exclusions                    | **Exclusions**: Attendance.Edit, Grade.Edit, Student.Delete, Payment.Delete (even for owner) |
| `general_manager`  | General Manager     | branch        | Full operational + Budget.Allocate                 | Cross-branch via legacy 'manager' carve-out |
| `head_of_department` | Head of Department | department    | Academic only: Class, Session, Attendance, Exam, Grade, Promotion.Approve, Certificate.Issue | No finance, no HR beyond teachers view |
| `finance_manager`  | Finance Manager     | branch        | Payment.*, Invoice.*, Ledger, Payroll, Finance.Report | **No** Budget.Allocate |
| `receptionist`     | Receptionist        | branch        | Lead.*, Student.Create, Payment.Create, Book.Sell  | Front-desk focus |
| `counselor`        | Counselor           | branch        | Lead.View + Follow-up only; limited Student/Class  | CRM-focused |
| `teacher`          | Teacher             | own / class   | Dashboard.View(own), Student.View(class), Class.View(own), Attendance.Edit(own), Grade.Edit(own), etc. | Narrowest — only own assigned classes |
| `data_entry`       | Data Entry          | branch        | Create/Edit students, attendance, exams (no delete, no finance) | Entry-only |
| `designer`         | Designer            | branch        | Certificate.Issue, Templates, print-only views     | No financial mutations |
| `donor_manager`    | Donor Manager       | mixed (org for Funding + branch for Dashboard/Student) | Funding.*, Impact.*, DonorLedger, recordDonation, awardScholarship | Strong Funding + Impact focus |

**Teacher scope detail (02 §5.1):** Per-permission mixed: Dashboard.View(own), Student.View(class), Class.View(own), Session.View/Edit(own), Attendance.View/Edit(own), Exam.View(own), Grade.View/Edit(own).

## 3. Generative Implementation (Single Source of Truth)

### 3.1 navRegistry.ts (client/shared/permissions/navRegistry.ts)
- 19+ items covering all modules.
- `getNavForPermissions(userPermissions)` → filtered sidebar nav.
- `getDashboardConfigForPermissions(...)` → widgets + quickActions.
- `OWNER_EXCLUDED = ['Attendance.Edit', 'Grade.Edit', 'Student.Delete', 'Payment.Delete']`

### 3.2 usePermissions.ts + useAuth
- Resolves from backend `PermissionResolutionService` (or legacy role fallback).
- Exposes `dashboardWidgets`, `dashboardQuickActions`, `isOwner`, exclusion helpers.
- Listens to `dev-role-switched` for instant regeneration.

### 3.3 GenerativeQuickActions.tsx
- 15+ live actions with dialogs + real mutations (recordPayment, recordDonation, issueCertificate, awardScholarship, allocateBudget, exportImpactReport, exportDonorLedger, printRecentCertificate, addVisitor, newCampaign, logFollowup, etc.).
- All respect `hasPermission` + owner exclusions.
- Live data from hooks (students, donors, certs, etc.).

### 3.4 Dashboard Composition (12 + 14)
- `/dashboard` endpoint (DashboardController) + `useDashboardSummary`.
- Widgets filtered by permission (e.g. `showPendingPromotions` only if Promotion.Approve).
- All numbers **live** from DB via module tables (no data ownership in reporting layer).

### 3.5 RoleSwitcher (dev)
- 10 exact seeded users (owner, general_mgr, hod, finance_mgr, reception, counselor, teacher1, data_entry, designer, donor_mgr).
- Password: `password`.
- Instant nav/widget/quick-action regeneration via events + query invalidation.

## 4. Per-Role Workspace Specifications

### 4.1 owner
**Nav (core + full):** Dashboard, Students, Classes, Finance, Inventory, Funding & Impact, Settings, Audit Logs, Users & Roles, Certificates.
**Dashboard Widgets:** executiveSummary, stats, recentActivity, budgetUtilization, leadsPipeline, impactMetrics, certificateQueue, pendingPromotions.
**Quick Actions:** All available (recordPayment, recordDonation, awardScholarship, allocateBudget, issueCertificate, exportImpactReport, exportDonorLedger, ...). **Exclusions enforced:** no Attendance.Edit / Grade.Edit / Student.Delete / Payment.Delete.
**Scope:** organization (can request all branches).
**Special:** Full visibility + generative extras. Owner notice banner about exclusions.

### 4.2 general_manager
**Nav:** Dashboard, Students, Classes, Finance, Inventory, Funding & Impact, Settings.
**Widgets:** stats, budgetUtilization, leadsPipeline, impactMetrics, pendingPromotions, recentActivity.
**Quick Actions:** recordPayment, allocateBudget, recordDonation, awardScholarship, approvePromotion, addVisitor, exportImpactReport.
**Scope:** branch (but legacy manager carve-out allows cross-branch).
**Notes:** Full operational power except pure owner security.

### 4.3 head_of_department
**Nav:** Dashboard, Students, Classes, Sessions, Certificates.
**Widgets:** pendingPromotions, attendanceSummary, gradesOverview, certificateQueue, classesOverview, upcomingExams.
**Quick Actions:** approvePromotion, issueCertificate, markAttendance (class), logFollowup.
**Scope:** department.
**Notes:** Academic-only focus. Promotion tab prominent. No finance nav.

### 4.4 finance_manager
**Nav:** Dashboard, Finance, Inventory, Funding & Impact (view only), Students (limited).
**Widgets:** todayRevenue, pendingPayments, payrollDue, budgetUtilization (read-only), impactMetrics (read).
**Quick Actions:** recordPayment, allocateBudget (no), recordDonation (view), exportDonorLedger.
**Scope:** branch.
**Notes:** Strong finance focus. **Explicitly no Budget.Allocate** in some flows. Invoices + Payroll Ledger prominent.

### 4.5 receptionist
**Nav:** Dashboard, Students, Classes, Visitors & Leads, Inventory, Finance (limited).
**Widgets:** leadsPipeline, followUpsDue, studentsOverview, classesOverview.
**Quick Actions:** addVisitor, logFollowup, registerStudent, recordPayment, markAttendance.
**Scope:** branch.
**Notes:** Front-desk powerhouse. Quick visitor → student conversion flows.

### 4.6 counselor
**Nav:** Dashboard, Visitors & Leads, Students (view), Classes (view).
**Widgets:** leadsPipeline, followUpsDue, studentsOverview.
**Quick Actions:** logFollowup, addVisitor, viewImpact (limited).
**Scope:** branch.
**Notes:** Pure CRM / follow-up role. Conversion readiness checks prominent.

### 4.7 teacher
**Nav:** Dashboard, Classes (own), Students (class-scoped), Sessions (own).
**Widgets:** attendanceSummary (own), upcomingExams, gradesOverview (own), classesOverview (own).
**Quick Actions:** markAttendance (own), recordExamResult (via class), viewStudents (class).
**Scope:** own / class.
**Notes:** Extremely narrow. Only sees own assigned classes + their students. Attendance/Grade.Edit allowed only for own.

### 4.8 data_entry
**Nav:** Dashboard, Students, Classes, Visitors & Leads.
**Widgets:** studentsOverview, classesOverview, leadsPipeline.
**Quick Actions:** registerStudent, addVisitor, markAttendance, logFollowup (no finance, no delete).
**Scope:** branch.
**Notes:** Entry-only. No deletes, no finance actions.

### 4.9 designer
**Nav:** Dashboard, Certificates, Students (view), Classes (view).
**Widgets:** certificateQueue, classesOverview.
**Quick Actions:** issueCertificate, printRecentCertificate, exportImpactReport (limited).
**Scope:** branch.
**Notes:** Template/print specialist. Certificate issuance + preview primary.

### 4.10 donor_manager
**Nav:** Dashboard, Funding & Impact, Students (view), Finance (report).
**Widgets:** impactMetrics, campaignProgress, recentDonations, donorLedger snapshot, executiveSummary (limited).
**Quick Actions:** recordDonation, awardScholarship, newCampaign, exportImpactReport, exportDonorLedger, viewDonorLedger.
**Scope:** organization (Funding) + branch (Dashboard/Student).
**Notes:** Strongest Funding/Impact focus. DonorLedger + ImpactMetricsCard prominent. Scholarships update student tuition.

## 5. Owner Exclusions (Non-Negotiable — 02 §5.1 + 14 §4.1)
Even `owner` may **never** perform:
- Attendance.Edit
- Grade.Edit
- Student.Delete
- Payment.Delete

These are enforced in:
- `navRegistry.ts` (OWNER_EXCLUDED)
- `usePermissions.ts`
- `GenerativeQuickActions.tsx`
- Backend policies + ABAC checks
- UI filters in Dashboard + pages

## 6. Dashboard & Reporting Layer (12 + 14)
- All widgets come from `DashboardController` (composition) + permission-filtered fallbacks.
- "This layer owns NO data" — every stat reads existing module tables.
- Role-specific visibility via `dashboardWidgets.includes(...) || hasPermission(...)`.
- Live report buttons (Financial, Payroll, Roster, Certificate) respect permissions.

## 7. Validation & Testing Requirements
1. Use **RoleSwitcher** (bottom-right in dev) to cycle through all 10 seeded users.
2. After each switch:
   - Sidebar nav must match role spec.
   - Dashboard widgets must appear/disappear correctly.
   - Quick Actions must be filtered + functional with live mutations.
   - Owner role must show exclusion notice + hide forbidden actions.
3. Backend `/dashboard` + permission resolution must return consistent data.
4. All quick actions must succeed with real DB writes (use seeded data).
5. Cross-module flows (e.g. awardScholarship → tuition update, recordDonation → 5% sweep) must work.

**Seeded usernames (EnhancedSampleDataSeeder + IamSeeder):**
`owner`, `general_mgr`, `hod`, `finance_mgr`, `reception`, `counselor`, `teacher1`, `data_entry`, `designer`, `donor_mgr`

## 8. Acceptance Criteria
- [x] Generative navRegistry covers all 10 roles with correct items.
- [x] RoleSwitcher + 10 seeded users present and functional.
- [x] GenerativeQuickActions implements ≥12 live actions with dialogs + mutations.
- [x] Owner exclusions fully enforced in UI + registry + backend.
- [x] DashboardPage is fully generative (permission-driven widgets).
- [x] Per-role expectations documented here (this file).
- [ ] Exhaustive manual validation of all 10 roles (via RoleSwitcher) completed.
- [ ] Live data preference maintained (no demo numbers on role workspaces).
- [ ] Any role-specific pages/widgets added only as thin generative wrappers.

## 9. Implementation Notes (Current State as of 2026-08-24)
- navRegistry: 19 items (academic x4, crm, finance, funding x6, platform x3, etc.).
- Full live backend (Laravel + MySQL).
- DomPDF + certificate templates integrated.
- RuleEngine, Notifications, Audit, Settings all live.
- 5% savings sweep, shared financial tx, scholarship → tuition all working.
- Docker + XAMPP support present.

## 10. Definition of Done
Locked when:
- This document exists and matches code.
- All 10 roles produce correct generative workspaces via RoleSwitcher.
- BUILD_ORDER.md marks 14 at **95%+**.
- CHANGELOG updated.
- XAMPP test passes for at least owner, hod, finance_mgr, donor_manager, designer.

## 11. Next Steps (after this spec)
- Full E2E per-role smoke (manual or automated).
- Any remaining role-specific polish in modules (e.g. teacher-only roster views).
- Production readiness checklist.

**References:** 02 §5 (exact roles), 03 §7 (generative), 05/07/09/11/12 (module data), current `navRegistry.ts`, `GenerativeQuickActions.tsx`, `DashboardPage.tsx`, `usePermissions.ts`, `RoleSwitcher.tsx`.

---
*This is the locked specification. All future work must preserve the generative approach and exact per-role expectations above.*
