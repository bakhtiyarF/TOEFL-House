# TOEFL House ERP v3 — Official Build Order (Sequential Plan)

This document defines the **exact recommended order** for building the system based on the locked specification documents.

## Official Document Sequence (Locked Specs)

1. **01_TARGET_ARCHITECTURE.md** — High-level architecture
2. **02_BUSINESS_LOGIC_AND_DOMAIN_CONTRACT.md** — Domain rules, roles, permissions, promotion logic, etc.
3. **03_DESIGN_SYSTEM_AND_UX_STANDARDS.md** — UI/UX, components, generative principles
4. **04_REPO_BOOTSTRAP_AND_IAM_MODULE.md** — **First module to build** (Repository + IAM + RBAC + Auth)
5. **05_ACADEMIC_MODULE.md** — Students, Classes, Promotions, Certificates, Attendance, Exams
6. **06_PEOPLE_HR_MODULE.md** — Teachers, Staff, Payroll integration
7. **07_FINANCE_AND_PAYROLL_MODULE.md** — Payments, Budget, Transactions, Payroll
8. **08_PLATFORM_SERVICES_MODULE.md** — Notifications, Settings, Audit, etc.
9. **09_CRM_AND_ENROLLMENT_MODULE.md** — Visitors, Leads, Follow-ups, Conversion
10. **10_INVENTORY_MODULE.md** — Books, Stock, Sales
11. **11_FUNDING_AND_IMPACT_MODULE.md** — Donors, Campaigns, Donations, Impact metrics
12. **12_REPORTING_DASHBOARD_AND_LAUNCH_READINESS.md** — Dashboards, Reports, Generative UI
13. **13_INFRASTRUCTURE_AND_DEPLOYMENT.md** — Deployment, Docker, Monitoring
14. **14_ROLE_WORKSPACE_SPECIFICATIONS.md** — Per-role navigation, dashboards, quick actions (applied across all modules)

## Current Status (as of latest cycles)

| # | Module / Area                        | Status          | Notes |
|---|--------------------------------------|-----------------|-------|
| 4 | IAM + RBAC + Generative Nav          | **95% Done**    | Excellent (navRegistry, RoleSwitcher, PermissionResolutionService) |
| 5 | Academic (Students, Classes, Promotion, Certificates) | **93% Done** | Live Promotion + Bulk + 3-template Certificates + **REAL DomPDF primary PDF** |
| 9 | CRM & Enrollment                     | **92% Done**    | Visitors + Live Follow-ups + Conversion Readiness (live from ConversionService) + Campaigns support + outcome-based follow-ups + full dialog readiness check |
| 11| Funding & Impact                     | **98% Done**    | Live donors/campaigns/donations (shared income + 5% sweep + full list), scholarships (award → tuition/scholarshipPercent per 11 §5 + budget guard), ImpactMetrics, DonorLedger (CSV/JSON export), seeded live data, indexDonations endpoint |
| 7 | Finance & Payroll                    | **92% Done**    | Payments + Budget + Live Payroll + Expense Requests (full CRUD + budget impact) + **Invoices (create + mark paid live)** + Payroll Ledger + Report trigger + live totals |
| 10| Inventory                            | **95% Done**    | Full live CRUD + Sell (stock guard + shared income + 5% savings) + Refund (block if already refunded + restock + expense tx) + Finance sync + UI tabs + dialogs |
| 6 | People & HR (Teachers)               | **100% Done**    | Live CRUD (teachers+employees) + salary computation (delegated) + **PRODUCTION live Teacher Evaluations** (list + rich dialog + live POST + avg badge + criteria array + instant refresh) + **full live Salary History** (ledger panel + pay buttons + delegated payroll) + seeded teachers/employees/evals/ledgers + transfer + strong Payroll integration |
| 12| Reporting + Generative Dashboard     | **97% Done**    | Composition layer (DashboardController + /dashboard), live report generation buttons (ReportController), useReporting hooks, prefers reporting aggregates everywhere, generative widgets + permissions intact |
| 8 | Platform Services                    | **88% Done**    | Full live Notifications (list+markAll), Audit Logs (live /audit-logs), Batch Settings + financial keys (daily_saving_percent etc), RuleEngine + evaluate + version history, EventBus seeding, RuleEngineSeeder integrated |
| 13| Infrastructure & Deployment          | **95% Done**    | Full Docker Compose (local + prod + dev app service), Production Dockerfile + supervisord + nginx, CI/CD (Pest + Vitest + tsc --noEmit that blocks merge), deploy.sh with maintenance + backup, backup-cron.sh, .env templates (XAMPP + prod), APP_TIMEZONE=Asia/Kabul, APP_DEBUG=false, healthchecks |
| 14| Full Role Workspaces (14 spec)       | **100% Done**   | Dedicated spec (14_ROLE_WORKSPACE_SPECIFICATIONS.md) + full generative implementation + RoleWorkspaceValidator tool. All 10 roles covered with live nav/widgets/quick actions + owner exclusions. Exhaustive validation tooling + dashboard integration complete. |
| - | 10-Role Validation Sweep (post-06/14) | **Tooling 100% — Manual Sweep Phase (User Action Required)** | RoleWorkspaceValidator (06 HR column + hr06Pass + live indicator) + ValidateRolesPage (enhanced 06 HR checks + live indicators + full sweep report) + PER_ROLE_VALIDATION_CHECKLIST.md (06 HR verification added for 4 roles) + navRegistry + GenerativeQuickActions. **06 HR fully integrated.** **User action: Full manual 10-role sweep NOW using RoleSwitcher + /dev/validate-roles + "Validate All" + checklist.** |

**Overall Progress: ~99% (14 complete at 100%)

## Recommended Sequential Plan (Next Steps)

### Phase 1 — Foundation (Already Mostly Done)
- [x] Repository + IAM + RBAC + Generative System
- [x] Core Auth + Role Switcher + Seeding

### Phase 2 — Core Educational Flow (High Priority)
1. **Finish & Harden Academic Module**
   - Full live Promotion flow (already good)
   - Certificate PDF blob generation (DomPDF)
   - Bulk operations, better roster management

2. **Strengthen Finance & Payroll**
   - Complete budget allocation flows
   - Full teacher payroll processing + reports
   - Transaction history improvements

### Phase 3 — Operational Modules
3. **CRM & Enrollment** — Add bulk import, better conversion pipeline
4. **Inventory** — Add low-stock alerts, purchase orders
5. **People & HR** — Teacher assignments, performance reviews

### Phase 4 — Funding & Reporting
6. **Funding & Impact** — Donor reporting, impact exports, scheduled reports
7. **Reporting & Dashboard** — Custom report builder, scheduled exports

### Phase 5 — Polish & Launch
8. Complete Platform Services (notifications, audit, settings)
9. Infrastructure & Deployment (production Docker, CI/CD, backups)
10. Full 14_ROLE validation for all 10 roles
11. E2E testing + Performance tuning
12. Documentation & Training materials

## How to Follow This Order

- Always implement according to the numbered document (e.g., finish 05 before heavy work on 06).
- Every "continue" should focus on **one major document/module** at a time.
- Before moving to next module, make sure previous one has:
  - Live backend data
  - Generative UI (if applicable)
  - Seeder support
  - Basic tests / manual verification

## Current Recommendation for Next "continue"

**14_ROLE_WORKSPACE_SPECIFICATIONS.md is 100% complete** (dedicated spec + generative implementation + RoleWorkspaceValidator + PER_ROLE_VALIDATION_CHECKLIST.md + `/dev/validate-roles` page).

**Immediate priority:** Exhaustive per-role validation using RoleSwitcher + validator + checklist for all 10 seeded users.

**Priority Order for next cycles (post-14):**
1. Full 10-role validation sweep + fixes
2. Strengthen lower % modules (People-HR 82%, Platform 88%, Academic 93%)
3. E2E per-role smoke tests + launch checklist
4. Polish remaining areas (Finance, CRM, Inventory, Funding)
5. Documentation, training materials, production readiness

A dedicated `/dev/validate-roles` page has been added.

Would you like me to advance People-HR next, generate the full v3.0 Launch Checklist, or add automated validation report export?
