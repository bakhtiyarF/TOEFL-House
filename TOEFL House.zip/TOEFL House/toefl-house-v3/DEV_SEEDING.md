# Dev Seeding & Role Testing (TOEFL House ERP v3)

## Quick Start for Full Live Data (after `continue` cycles)

1. In server/ (Laravel):
   ```bash
   php artisan migrate:fresh --seed --class=DatabaseSeeder
   # or explicitly
   php artisan db:seed --class=EnhancedSampleDataSeeder
   ```

   Creates:
   - 10 users (one per role) — **password: "password"** for all
   - 16+ students + enrollments + rosters + attendance
   - 5 classes + sessions + homework/exams + examResults (for live PromotionService)
   - Payments, journey events, 7+ certificates (classic/modern/minimal templates)
   - 2+ campaigns + donations + impact metrics (69%/67%)
   - Multiple follow-ups per visitor
   - Donors, budgets, etc.

2. Frontend dev:
   - Start client: `cd client && npm run dev`
   - Use bottom-right **RoleSwitcher** (visible in DEV) — instantly switches role + regenerates nav/widgets/QA + refetches live data.
   - Or use global: `window.__switchRole('donor_manager')` or username e.g. 'donor_mgr'

3. Verify per role (per 14_ROLE_WORKSPACE_SPECIFICATIONS):
   - owner: full + exclusions (no Attendance.Edit etc.)
   - donor_manager: Funding/Impact + DonorLedger + viewImpact export + recordDonation
   - designer: Certificates + Certificate.Issue + queue
   - head_of_department: pendingPromotions + approvePromotion
   - etc. for all 10 roles

4. Live flows to test:
   - Dashboard: 100% live stats/activity
   - GenerativeQuickActions: recordPayment, recordDonation, issueCertificate (with template), logFollowup, etc.
   - Classes → Promotion tab: live evaluate + apply (exam avg + roster attendance)
   - Certificates: issue + print (HTML + JSON + Download PDF)
   - Funding: DonorLedger + impact exports
   - Visitors: live follow-ups + useVisitorFollowups
   - Finance: live CSV export

## Notes
- All demo/fallback numbers removed.
- Bundle ~798KB (gz ~223KB)
- Sanctum + PermissionResolutionService drive generative system.
- For real backend testing use seeded users + role switcher.