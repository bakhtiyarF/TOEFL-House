import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { peopleHrApi } from '../api';

export const hrKeys = {
  teachers: (params?: any) => ['people-hr', 'teachers', params] as const,
  evaluations: (teacherId: string) => ['people-hr', 'evaluations', teacherId] as const,
};

export function useTeachers(params?: any) {
  return useQuery({
    queryKey: hrKeys.teachers(params),
    queryFn: () => peopleHrApi.teachers.list(params),
  });
}

export function useCreateTeacher() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: peopleHrApi.teachers.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['people-hr', 'teachers'] }),
  });
}

export function useTransferTeacher() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => peopleHrApi.teachers.transfer(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['people-hr', 'teachers'] }),
  });
}

// === Live Teacher Evaluations (06 spec) ===
export function useTeacherEvaluations(teacherId: string) {
  return useQuery({
    queryKey: hrKeys.evaluations(teacherId),
    queryFn: () => peopleHrApi.teachers.evaluations(teacherId),
    enabled: !!teacherId,
  });
}

export function useAddEvaluation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ teacherId, data }: { teacherId: string; data: any }) =>
      peopleHrApi.teachers.addEvaluation(teacherId, data),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: hrKeys.evaluations(vars.teacherId) });
      qc.invalidateQueries({ queryKey: ['people-hr', 'teachers'] });
    },
  });
}

// === Employees (06 spec — full CRUD + transfer, salary delegated) ===
const employeeKeys = (params?: any) => ['people-hr', 'employees', params] as const;

export function useEmployees(params?: any) {
  return useQuery({
    queryKey: employeeKeys(params),
    queryFn: () => peopleHrApi.employees.list(params),
  });
}

export function useCreateEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: peopleHrApi.employees.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['people-hr', 'employees'] }),
  });
}

export function useUpdateEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => peopleHrApi.employees.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['people-hr', 'employees'] }),
  });
}

export function useDeleteEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => peopleHrApi.employees.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['people-hr', 'employees'] }),
  });
}

export function useTransferEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => peopleHrApi.employees.transfer(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['people-hr', 'employees'] }),
  });
}
