/**
 * People HR Module public interface
 */
export * from './api';
export * from './hooks/usePeopleHr';
export { TeachersPage } from './components/TeachersPage';
export { EmployeesPage } from './components/EmployeesPage';
export type { Teacher } from './types';
