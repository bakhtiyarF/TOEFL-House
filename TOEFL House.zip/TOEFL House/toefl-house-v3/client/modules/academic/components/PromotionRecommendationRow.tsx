/**
 * PromotionRecommendationRow
 * Extracted reusable component for per-student promotion recommendation + apply
 * (per 05_ACADEMIC + 14_ROLE + 02 §5)
 * Uses live PromotionService data via usePromotionRecommend + useApplyPromotion
 * Cleanly manages hooks per row (no inline hooks in lists)
 */

import { Badge } from '@shared/components/ui/badge';
import { Button } from '@shared/components/ui/button';
import { usePromotionRecommend, useApplyPromotion } from '../hooks/useAcademic';
import { useAuth } from '@modules/iam/hooks/useAuth';
import { toast } from 'sonner';
import { RefreshCw } from 'lucide-react';

interface RosterItem {
  id?: string;
  student_id?: string;
  full_name?: string;
  student_name?: string;
  student_code?: string;
}

interface Props {
  rosterItem: RosterItem;
  classId?: string;
  onPromoted?: () => void;
  showOnlyEligible?: boolean;
  selectable?: boolean;
  selected?: boolean;
  onToggleSelect?: (sid: string) => void;
}

export function PromotionRecommendationRow({ 
  rosterItem, 
  classId, 
  onPromoted, 
  showOnlyEligible = false,
  selectable = false,
  selected = false,
  onToggleSelect 
}: Props) {
  const sid = rosterItem.student_id || rosterItem.id || '';
  const { data: rec, isLoading: recLoading, refetch: refetchRec } = usePromotionRecommend(sid);
  const apply = useApplyPromotion();
  const { hasPermission } = useAuth();

  const studentName = rosterItem.full_name || rosterItem.student_name || 'Student';
  const studentCode = rosterItem.student_code || sid;

  const canApprove = hasPermission('Promotion.Approve');

  // Hide if filter active and not eligible
  if (showOnlyEligible && rec && !rec.can_promote) {
    return null;
  }

  const handleToggle = () => {
    if (selectable && onToggleSelect && sid) {
      onToggleSelect(sid);
    }
  };

  const handleApply = (recItem: any) => {
    apply.mutate(
      {
        studentId: sid,
        data: {
          to_level_id: recItem.to_level,
          from_level_id: recItem.from_level,
          program_version_id: undefined,
          reason: `Promoted from class roster (live) - ${classId || ''}`,
        },
      },
      {
        onSuccess: (res) => {
          toast.success(`Promotion applied for ${studentName} → ${recItem.to_level}`);
          refetchRec();
          onPromoted?.();
        },
        onError: (err: any) => {
          toast.error(`Failed to promote: ${err?.message || 'Unknown error'}`);
        },
      }
    );
  };

  const handleRefreshRec = () => {
    refetchRec();
    toast.info('Recommendation refreshed');
  };

  // If we are in "eligible only" mode and still loading, show skeleton briefly
  if (showOnlyEligible && recLoading) {
    return (
      <div className="p-3 border rounded bg-background/50 animate-pulse">
        <div className="h-4 w-3/4 bg-muted rounded mb-2" />
        <div className="h-3 w-1/2 bg-muted rounded" />
      </div>
    );
  }

  return (
    <div className="p-3 border rounded bg-background/50">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          {selectable && (
            <input
              type="checkbox"
              checked={selected}
              onChange={handleToggle}
              className="h-4 w-4 accent-primary"
              disabled={!rec?.can_promote}
            />
          )}
          <div>
            <div className="font-medium">{studentName}</div>
            <div className="text-[10px] text-muted-foreground">{studentCode}</div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {rec && (
            <Badge variant={rec.can_promote ? 'default' : 'secondary'} className="text-xs">
              {rec.can_promote ? 'Eligible' : 'Not yet'}
            </Badge>
          )}
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleRefreshRec} title="Refresh recommendation">
            <RefreshCw className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {recLoading ? (
        <div className="mt-1 text-xs text-muted-foreground">Loading live recommendation…</div>
      ) : rec ? (
        <div className="mt-2 grid grid-cols-2 gap-x-4 text-xs">
          <div>Exam Avg: <span className="font-medium">{rec.exam_avg ?? '—'}</span></div>
          <div>Attendance: <span className="font-medium">{rec.attendance_rate ?? 0}%</span></div>
          <div>Current Level: <span className="font-medium">{rec.current_level || '—'}</span></div>
          <div>Recommendations: <span className="font-medium">{rec.recommendations?.length || 0}</span></div>
          {rec.recommendations?.[0] && (
            <div className="col-span-2 text-[10px] mt-0.5 text-muted-foreground">
              Next: {rec.recommendations[0].to_level} {rec.recommendations[0].auto_promote ? '(auto)' : ''}
            </div>
          )}
        </div>
      ) : (
        <div className="mt-1 text-xs text-muted-foreground">No recommendation data yet (run exams/attendance).</div>
      )}

      {rec?.recommendations?.length > 0 && rec.can_promote && canApprove && (
        <div className="mt-2 flex flex-wrap gap-2">
          {rec.recommendations.map((recItem: any, idx: number) => (
            <Button
              key={idx}
              size="sm"
              className="h-7 text-xs"
              disabled={apply.isPending}
              onClick={() => handleApply(recItem)}
            >
              {apply.isPending ? 'Applying…' : `Apply → ${recItem.to_level}${recItem.auto_promote ? ' (auto)' : ''}`}
            </Button>
          ))}
        </div>
      )}

      {!canApprove && rec?.can_promote && (
        <div className="mt-1 text-[10px] text-amber-600">Promotion.Approve permission required</div>
      )}

      {rec?.can_promote === false && rec.recommendations?.length === 0 && (
        <div className="mt-1 text-[10px] text-muted-foreground">Does not meet current promotion rules.</div>
      )}
    </div>
  );
}
