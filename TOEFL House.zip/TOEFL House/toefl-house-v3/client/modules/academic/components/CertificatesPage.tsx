/**
 * Certificates Page — Academic Module
 * Live certificate queue + issuance (per 14_ROLE + Certificate.Issue permission)
 * Designer + head_of_department primary audience
 */

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@shared/components/ui/card';
import { Button } from '@shared/components/ui/button';
import { Badge } from '@shared/components/ui/badge';
import { Input } from '@shared/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@shared/components/ui/dialog';
import { Label } from '@shared/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@shared/components/ui/select';
import { useStudents, useCertificates, useIssueCertificate, useRevokeCertificate, usePrintCertificate } from '../hooks/useAcademic';
import { useAuth } from '@modules/iam/hooks/useAuth';
import { toast } from 'sonner';
import { Award, Plus, Search, Eye } from 'lucide-react';
import { CertificatePreview } from './CertificatePreview';

export function CertificatesPage() {
  const { hasPermission } = useAuth();
  const canIssue = hasPermission('Certificate.Issue');

  const [search, setSearch] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [isIssueOpen, setIsIssueOpen] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewCert, setPreviewCert] = useState<any>(null);
  const [previewMode, setPreviewMode] = useState<'classic' | 'modern' | 'minimal'>('classic');

  const [issueForm, setIssueForm] = useState({
    certificate_no: '',
    grade: 'Pass',
    level_id: '',
    program_id: '',
    template: 'classic' as 'classic' | 'modern' | 'minimal',
  });

  // Live certificates (search is handled client-side for now; backend also accepts student_id/branch_id)
  const { data: certificates = [], isLoading } = useCertificates();

  // Live students for issuance
  const { data: students = [] } = useStudents({ status: 'active' });

  const issueCert = useIssueCertificate();
  const revokeCert = useRevokeCertificate();
  const printCert = usePrintCertificate();

  const filteredCerts = (certificates as any[]).filter((c: any) =>
    (c.student?.full_name || '').toLowerCase().includes(search.toLowerCase()) ||
    (c.certificate_no || '').toLowerCase().includes(search.toLowerCase())
  );

  const filteredStudents = (students as any[]).filter((s: any) =>
    s.full_name.toLowerCase().includes(search.toLowerCase()) ||
    (s.student_code || '').toLowerCase().includes(search.toLowerCase())
  );

  const handleOpenIssue = (student?: any) => {
    setSelectedStudent(student || null);
    setIssueForm({
      certificate_no: `CERT-${new Date().getFullYear()}-${Math.floor(Math.random() * 90000) + 10000}`,
      grade: 'Pass',
      level_id: '',
      program_id: '',
      template: 'classic',
    });
    setIsIssueOpen(true);
  };

  const handlePreview = (cert: any, student?: any) => {
    setPreviewCert({
      studentName: cert.student?.full_name || student?.full_name || 'Student',
      studentCode: cert.student?.student_code || student?.student_code || '',
      certificateNo: cert.certificate_no,
      grade: cert.grade,
      level: cert.level_id,
      issueDate: cert.issue_date,
    });
    setIsPreviewOpen(true);
  };

  const onIssueSubmit = () => {
    if (!selectedStudent) return;

    issueCert.mutate({
      studentId: selectedStudent.id || selectedStudent.student_id,
      data: {
        certificate_no: issueForm.certificate_no,
        grade: issueForm.grade,
        level_id: issueForm.level_id || undefined,
        program_id: issueForm.program_id || undefined,
        template: issueForm.template, // designer choice (stored for future print)
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Award className="h-8 w-8" /> Certificates
          </h1>
          <p className="text-muted-foreground">Issue and manage student certificates (live)</p>
        </div>
        {canIssue && (
          <Dialog open={isIssueOpen} onOpenChange={setIsIssueOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleOpenIssue()}>
                <Plus className="h-4 w-4 me-2" /> Issue Certificate
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Issue New Certificate</DialogTitle>
                <DialogDescription>Select student and enter details</DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {!selectedStudent && (
                  <div>
                    <Label>Student</Label>
                    <Select onValueChange={(val) => {
                      const stu = filteredStudents.find((s: any) => s.id === val);
                      setSelectedStudent(stu);
                    }}>
                      <SelectTrigger><SelectValue placeholder="Choose student" /></SelectTrigger>
                      <SelectContent>
                        {filteredStudents.slice(0, 30).map((s: any) => (
                          <SelectItem key={s.id} value={s.id}>{s.full_name} ({s.student_code})</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {selectedStudent && (
                  <div className="text-sm bg-muted p-2 rounded">
                    Issuing to: <strong>{selectedStudent.full_name}</strong> ({selectedStudent.student_code})
                  </div>
                )}

                <div>
                  <Label>Certificate Number</Label>
                  <Input value={issueForm.certificate_no} onChange={(e) => setIssueForm({ ...issueForm, certificate_no: e.target.value })} />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Grade</Label>
                    <Select value={issueForm.grade} onValueChange={(v) => setIssueForm({ ...issueForm, grade: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Pass">Pass</SelectItem>
                        <SelectItem value="Merit">Merit</SelectItem>
                        <SelectItem value="Distinction">Distinction</SelectItem>
                        <SelectItem value="A">A</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Level (optional)</Label>
                    <Input placeholder="e.g. L5" value={issueForm.level_id} onChange={(e) => setIssueForm({ ...issueForm, level_id: e.target.value })} />
                  </div>
                </div>

                {/* Designer template choice (live preview) */}
                <div>
                  <Label>Template (Designer)</Label>
                  <Select value={issueForm.template} onValueChange={(v: any) => setIssueForm({ ...issueForm, template: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="classic">Classic (Gold)</SelectItem>
                      <SelectItem value="modern">Modern (Slate)</SelectItem>
                      <SelectItem value="minimal">Minimal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Live inline preview for designer (per 14_ROLE) */}
                <div className="border rounded p-3 bg-muted/30">
                  <div className="text-[10px] font-medium mb-2 flex items-center gap-1">
                    <Eye className="h-3 w-3" /> Live Preview (updates as you type)
                  </div>
                  <CertificatePreview
                    studentName={selectedStudent?.full_name || 'Student Name'}
                    studentCode={selectedStudent?.student_code || 'STU-XXXX'}
                    certificateNo={issueForm.certificate_no || 'CERT-XXXX'}
                    grade={issueForm.grade}
                    level={issueForm.level_id || undefined}
                    mode={issueForm.template}
                  />
                </div>
              </div>

              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setIsIssueOpen(false)}>Cancel</Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setPreviewCert({
                      studentName: selectedStudent.full_name,
                      studentCode: selectedStudent.student_code,
                      certificateNo: issueForm.certificate_no,
                      grade: issueForm.grade,
                      level: issueForm.level_id,
                    });
                    setPreviewMode(issueForm.template);
                    setIsPreviewOpen(true);
                  }}
                >
                  <Eye className="h-4 w-4 mr-1" /> Live Preview
                </Button>
                <Button onClick={onIssueSubmit} disabled={!selectedStudent || issueCert.isPending}>
                  {issueCert.isPending ? 'Issuing...' : 'Issue Certificate'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search certificates or students..."
          className="ps-10"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Certificate Queue / List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" /> Issued Certificates
            <Badge variant="outline" className="text-xs ml-2">{filteredCerts.length} total</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-muted-foreground">Loading live certificates…</div>
          ) : filteredCerts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No certificates found. {canIssue && 'Issue the first one above.'}
            </div>
          ) : (
            <div className="space-y-2 text-sm">
              {filteredCerts.map((cert: any) => (
                <div key={cert.id} className="flex items-center justify-between border rounded p-3">
                  <div className="flex items-center gap-3">
                    <div>
                      <div className="font-medium">{cert.certificate_no}</div>
                      <div className="text-xs text-muted-foreground">
                        {cert.student?.full_name || '—'} • {cert.grade || 'Pass'} • {cert.issue_date?.slice(0, 10)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={cert.status === 'revoked' ? 'destructive' : 'default'}>
                      {cert.status || 'issued'}
                    </Badge>
                    {cert.template && (
                      <Badge variant="outline" className="text-[9px] capitalize">{cert.template}</Badge>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs"
                      onClick={() => {
                        setPreviewCert({
                          studentName: cert.student?.full_name,
                          studentCode: cert.student?.student_code,
                          certificateNo: cert.certificate_no,
                          grade: cert.grade,
                          level: cert.level_id,
                          issueDate: cert.issue_date,
                          id: cert.id,
                          template: cert.template,
                        });
                        setPreviewMode((cert.template as any) || 'classic');
                        setIsPreviewOpen(true);
                      }}
                    >
                      <Eye className="h-3 w-3 mr-1" /> Preview
                    </Button>
                    {canIssue && cert.id && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-xs"
                          onClick={() => {
                            printCert.mutate({ certificateId: cert.id, template: cert.template || 'classic' });
                          }}
                        >
                          Download PDF / Printable
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 text-xs"
                          onClick={() => {
                            // Direct downloadable printable HTML (client-side high-fidelity from preview data)
                            const tpl = cert.template || 'classic';
                            const html = `
                              <html><head><title>Certificate-${cert.certificate_no}</title>
                              <style>@page{size:A4 landscape;margin:1.5cm}body{font-family:system-ui;background:#f8fafc;padding:20px}.cert{max-width:900px;margin:0 auto;background:white;border:8px solid ${tpl==='modern'?'#334155':tpl==='minimal'?'#e5e7eb':'#d4af37'};padding:40px;text-align:center}</style>
                              </head><body>
                              <div class="cert">
                                <div style="position:absolute;top:18px;right:18px;font-size:10px;background:#f1f5f9;padding:2px 8px;border-radius:999px">${tpl.toUpperCase()}</div>
                                <h1 style="font-size:38px;color:#0f172a;margin:0">Certificate of Completion</h1>
                                <h2 style="font-size:18px;color:#64748b">TOEFL House — Afghanistan</h2>
                                <div style="font-size:16px;margin:20px 0">This certifies that</div>
                                <div style="font-size:36px;font-weight:700;border-bottom:3px solid #d4af37;display:inline-block;padding:0 20px;margin:12px 0">${cert.student?.full_name || 'Student'}</div>
                                <div style="font-size:15px">completed the program with grade <strong>${cert.grade || 'Pass'}</strong></div>
                                <div style="margin-top:40px;font-size:12px">No: ${cert.certificate_no} • Issued: ${cert.issue_date?.slice(0,10) || new Date().toISOString().slice(0,10)}</div>
                              </div>
                              <div style="text-align:center;margin-top:12px;font-size:11px"><button onclick="window.print()" style="background:#0f172a;color:white;border:none;padding:4px 12px;border-radius:4px">Print / Save PDF</button></div>
                              </body></html>`;
                            const blob = new Blob([html], {type:'text/html'});
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a'); a.href=url; a.download=`certificate-${cert.certificate_no}.printable.html`; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
                            toast.success('Printable HTML downloaded (open & Print → PDF)');
                          }}
                        >
                          HTML
                        </Button>
                      </>
                    )}
                    {canIssue && cert.status !== 'revoked' && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs"
                        onClick={() => revokeCert.mutate(cert.id)}
                      >
                        Revoke
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="text-[10px] text-muted-foreground">
        Live via <code>CertificateController</code>. Gated by <code>Certificate.Issue</code> (designer / head_of_department). 
        Generates journey <code>CERTIFICATE_ISSUED</code> event.
      </div>

      {/* Live Certificate Preview Dialog (designer / head_of_department feature) */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-[460px]">
          <DialogHeader>
            <DialogTitle>Certificate Preview</DialogTitle>
            <DialogDescription>Live visual preview (designer template)</DialogDescription>
          </DialogHeader>

          {previewCert && (
              <div className="space-y-4">
              <CertificatePreview
                studentName={previewCert.studentName}
                studentCode={previewCert.studentCode}
                certificateNo={previewCert.certificateNo}
                grade={previewCert.grade}
                level={previewCert.level}
                issueDate={previewCert.issueDate}
                mode={previewMode}
              />

              <div className="flex gap-2 justify-center text-xs">
                <Button size="sm" variant={previewMode==='classic'?'default':'outline'} onClick={() => setPreviewMode('classic')}>Classic</Button>
                <Button size="sm" variant={previewMode==='modern'?'default':'outline'} onClick={() => setPreviewMode('modern')}>Modern</Button>
                <Button size="sm" variant={previewMode==='minimal'?'default':'outline'} onClick={() => setPreviewMode('minimal')}>Minimal</Button>
              </div>
              <div className="text-center text-[10px] text-muted-foreground">
                Mode: {previewMode} — This is a live preview only
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>Close</Button>
              <Button 
              onClick={() => {
                const tpl = previewCert?.template || previewMode || 'classic';
                if (previewCert?.id) {
                  printCert.mutate(
                    { certificateId: previewCert.id, template: tpl },
                    {
                      onSuccess: (res: any) => {
                        const fn = res?.data?.filename || `certificate-${previewCert.certificateNo}-${tpl}.pdf`;
                        toast.success(`Certificate ready (${tpl}) — printable HTML + JSON downloaded`);
                        // The hook already handles window + downloads (HTML, JSON, future PDF blob)
                      },
                    }
                  );
                } else {
                  toast.success(`Print queued — template: ${tpl} (live backend report)`);
                  console.log('Certificate print (no id yet)', { ...previewCert, template: tpl });
                }
              }}
            >
              Print / Download PDF ({previewMode})
            </Button>
            {canIssue && (
              <Button 
                variant="default" 
                onClick={() => {
                  // Quick issue using current preview data
                  if (previewCert) {
                    // Find matching student if possible or use last selected
                    const stu = selectedStudent || filteredStudents[0];
                    if (stu) {
                      issueCert.mutate({
                        studentId: stu.id || stu.student_id,
                        data: {
                          certificate_no: previewCert.certificateNo,
                          grade: previewCert.grade,
                          level_id: previewCert.level,
                          template: previewMode,
                        },
                      });
                      setIsPreviewOpen(false);
                    }
                  }
                }}
              >
                Issue with this template
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
