/**
 * CertificatePreview
 * Simple live preview for designer / head_of_department (per 14_ROLE)
 * Used inside CertificatesPage for quick visual check before/after issuance.
 */
import { Card, CardContent } from '@shared/components/ui/card';
import { Badge } from '@shared/components/ui/badge';
import { Award } from 'lucide-react';

interface Props {
  studentName: string;
  studentCode: string;
  certificateNo: string;
  grade?: string;
  level?: string;
  issueDate?: string;
}

export function CertificatePreview({ studentName, studentCode, certificateNo, grade = 'Pass', level, issueDate, mode = 'classic' }: Props & { mode?: 'classic' | 'modern' | 'minimal' }) {
  const today = issueDate || new Date().toISOString().split('T')[0];

  if (mode === 'minimal') {
    return (
      <Card className="border border-muted max-w-[380px] mx-auto p-6 text-center">
        <div className="text-xs tracking-widest text-muted-foreground">TOEFL HOUSE</div>
        <div className="mt-3 text-xl font-medium">{studentName}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{studentCode}</div>
        <div className="my-4 text-lg font-semibold">{grade} — {certificateNo}</div>
        <div className="text-[10px] text-muted-foreground">Issued {today}</div>
        <Badge className="mt-3" variant="outline">MINIMAL — PREVIEW</Badge>
      </Card>
    );
  }

  if (mode === 'modern') {
    return (
      <Card className="border-0 shadow-xl max-w-[420px] mx-auto overflow-hidden">
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6">
          <div className="flex items-center gap-3">
            <Award className="h-8 w-8" />
            <div>
              <div className="text-sm tracking-[2px] opacity-70">TOEFL HOUSE</div>
              <div className="text-xl font-semibold">Certificate of Achievement</div>
            </div>
          </div>
        </div>
        <CardContent className="p-6 space-y-3 bg-white dark:bg-background">
          <div className="text-2xl font-semibold tracking-tight">{studentName}</div>
          <div className="text-xs text-muted-foreground">{studentCode} • {level ? `Level ${level}` : ''}</div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900 dark:text-white">{grade}</span>
            <span className="text-sm text-muted-foreground">Grade</span>
          </div>
          <div className="pt-3 text-xs border-t">
            {certificateNo} • {today}
          </div>
        </CardContent>
        <div className="bg-slate-50 dark:bg-slate-900 p-2 text-center text-[9px] text-muted-foreground">MODERN TEMPLATE — LIVE PREVIEW</div>
      </Card>
    );
  }

  // classic (default)
  return (
    <Card className="border-2 border-amber-300 bg-gradient-to-b from-amber-50 to-white dark:from-amber-950/30 dark:to-background max-w-[420px] mx-auto shadow-md">
      <CardContent className="p-8 text-center space-y-4">
        <div className="flex justify-center">
          <Award className="h-12 w-12 text-amber-600" />
        </div>

        <div className="text-[10px] tracking-[3px] text-amber-700/80 font-medium">TOEFL HOUSE EDUCATIONAL INSTITUTE</div>

        <div className="text-2xl font-serif tracking-wider text-amber-900 dark:text-amber-200">
          CERTIFICATE OF COMPLETION
        </div>

        <div className="text-sm text-muted-foreground">This is to certify that</div>

        <div className="text-3xl font-semibold text-amber-900 dark:text-amber-100 tracking-tight">
          {studentName}
        </div>

        <div className="text-xs text-muted-foreground">Student Code: {studentCode}</div>

        <div className="text-sm">
          has successfully completed the required coursework<br />
          {level ? `at Level ${level}` : 'in the program'} with grade
        </div>

        <div className="text-2xl font-bold text-amber-800 dark:text-amber-300">{grade}</div>

        <div className="pt-4 text-xs text-muted-foreground">
          Certificate No: <span className="font-mono font-medium text-amber-700">{certificateNo}</span><br />
          Issued: {today}
        </div>

        <div className="pt-6 text-[10px] text-muted-foreground border-t">
          Director of Academic Affairs • TOEFL House
        </div>

        <Badge variant="outline" className="mx-auto text-[9px]">PREVIEW — Not official until issued</Badge>
      </CardContent>
    </Card>
  );
}
