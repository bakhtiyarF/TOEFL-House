/**
 * Student Journey Timeline — Academic Module
 *
 * Append-only event log visualization (02 §9.1, 05 §4.3)
 * Shows the complete lifecycle of a student from registration through graduation
 */

import { Card, CardContent, CardHeader, CardTitle } from '@shared/components/ui/card';
import { Badge } from '@shared/components/ui/badge';
import {
  UserPlus, ClipboardCheck, BookOpen, CreditCard, Receipt, CreditCard as CardIcon,
  CalendarCheck, FileText, Award, GraduationCap, StickyNote, ArrowUpCircle,
  BookMarked, MapPin,
} from 'lucide-react';

interface JourneyEvent {
  id: string;
  event_type: string;
  occurred_at: string;
  payload?: Record<string, any>;
  actor_name?: string;
}

interface StudentJourneyTimelineProps {
  studentName: string;
  events?: JourneyEvent[];
}

const eventConfig: Record<string, { icon: React.ElementType; color: string; isFinancial?: boolean }> = {
  STUDENT_REGISTERED: { icon: UserPlus, color: 'bg-blue-500' },
  PLACEMENT_TEST_RECORDED: { icon: ClipboardCheck, color: 'bg-purple-500' },
  PLACEMENT_PASSED: { icon: ClipboardCheck, color: 'bg-green-500' },
  PLACEMENT_FAILED: { icon: ClipboardCheck, color: 'bg-red-500' },
  ENROLLMENT_CREATED: { icon: BookOpen, color: 'bg-indigo-500' },
  ENROLLMENT_STATUS_CHANGED: { icon: BookOpen, color: 'bg-yellow-500' },
  CLASS_ASSIGNED: { icon: MapPin, color: 'bg-teal-500' },
  INVOICE_ISSUED: { icon: Receipt, color: 'bg-orange-500', isFinancial: true },
  PAYMENT_RECORDED: { icon: CreditCard, color: 'bg-green-500', isFinancial: true },
  ID_CARD_ISSUED: { icon: CardIcon, color: 'bg-cyan-500' },
  BOOK_ISSUED: { icon: BookMarked, color: 'bg-amber-500' },
  ATTENDANCE_RECORDED: { icon: CalendarCheck, color: 'bg-lime-500' },
  EXAM_RESULT_RECORDED: { icon: FileText, color: 'bg-violet-500' },
  PROMOTION_DECIDED: { icon: ArrowUpCircle, color: 'bg-emerald-500' },
  STATUS_CHANGED: { icon: StickyNote, color: 'bg-gray-500' },
  GRADUATED: { icon: GraduationCap, color: 'bg-yellow-500' },
  NOTE_ADDED: { icon: StickyNote, color: 'bg-slate-500' },
};

const formatEventLabel = (eventType: string): string => {
  return eventType
    .split('_')
    .map((word) => word.charAt(0) + word.slice(1).toLowerCase())
    .join(' ');
};

const formatDate = (dateStr: string): string => {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export function StudentJourneyTimeline({ studentName, events = [] }: StudentJourneyTimelineProps) {
  // Strictly live data (no demo fallback). Show empty state when no events from backend.
  const displayEvents = (events && events.length > 0 ? events : []) as JourneyEvent[];
  const financialEvents = displayEvents.filter((e) => eventConfig[e.event_type]?.isFinancial);
  const totalPaid = financialEvents
    .filter((e) => e.event_type === 'PAYMENT_RECORDED')
    .reduce((sum, e) => sum + (e.payload?.amount || 0), 0);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Student Journey
            </CardTitle>
            <p className="text-sm text-muted-foreground">{studentName} · {displayEvents.length} events</p>
          </div>
          {totalPaid > 0 && (
            <Badge variant="outline" className="text-sm">
              Total Paid: {totalPaid.toLocaleString()} AFN
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute start-5 top-0 bottom-0 w-0.5 bg-border" />

          <div className="space-y-6">
            {displayEvents.length === 0 && (
              <div className="text-sm text-muted-foreground text-center py-4">No journey events yet. Events will appear as the student progresses through the system.</div>
            )}
            {displayEvents.map((event, index) => {
              const config = eventConfig[event.event_type] || { icon: StickyNote, color: 'bg-gray-400' };
              const Icon = config.icon;

              return (
                <div key={event.id} className="relative flex gap-4 ps-2">
                  {/* Timeline dot */}
                  <div className={`relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${config.color} text-white shadow-sm`}>
                    <Icon className="h-4 w-4" />
                  </div>

                  {/* Event content */}
                  <div className="flex-1 min-w-0 pb-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm">{formatEventLabel(event.event_type)}</span>
                      {config.isFinancial && (
                        <Badge variant="outline" className="text-xs">Financial</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {formatDate(event.occurred_at)}
                      {event.actor_name && ` · by ${event.actor_name}`}
                    </p>
                    {event.payload && Object.keys(event.payload).length > 0 && (
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        {Object.entries(event.payload).slice(0, 4).map(([key, value]) => (
                          <span key={key} className="inline-flex items-center rounded bg-muted px-2 py-0.5 text-xs">
                            <span className="text-muted-foreground me-1">{key}:</span>
                            <span className="font-medium">{String(value)}</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
