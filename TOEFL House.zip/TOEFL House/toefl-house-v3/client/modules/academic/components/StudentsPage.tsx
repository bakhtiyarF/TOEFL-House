/**
 * Students Page — Academic Module
 * Full CRUD with forms, search, filters, and journey timeline
 */

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@shared/components/ui/card';
import { Button } from '@shared/components/ui/button';
import { Badge } from '@shared/components/ui/badge';
import { Input } from '@shared/components/ui/input';
import { Label } from '@shared/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@shared/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@shared/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@shared/components/ui/select';
import { GraduationCap, Plus, Search, Filter, Eye, Edit, Trash2, Phone, MapPin, User, Download } from 'lucide-react';
import { StudentJourneyTimeline } from './StudentJourneyTimeline';
import { CertificatePreview } from './CertificatePreview';
import {
  useStudents,
  useCreateStudent,
  useEnrollStudent,
  useClasses,
  usePrograms,
  useProgramVersions,
  useStudentHomework,
  useStudentExams,
  useMarkHomeworkDone,
  useStudentJourney,
  useCreateExamResult,
  usePromotionRecommend,
  useApplyPromotion,
  useIssueCertificate,
  usePrintCertificate,
} from '../hooks/useAcademic';
import { exportStudents } from '@shared/lib/export';
import { useAuth } from '@modules/iam/hooks/useAuth';

const StudentSchema = z.object({
  full_name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: z.string().optional(),
  email: z.string().email('Invalid email').optional().or(z.literal('')),
  gender: z.enum(['male', 'female']).optional(),
  father_name: z.string().optional(),
  address_region: z.string().optional(),
  tazkira_no: z.string().optional(),
  whatsapp: z.string().optional(),
  dob: z.string().optional(),
  school_or_university: z.string().optional(),
  emergency_contact_name: z.string().optional(),
  emergency_contact_phone: z.string().optional(),
  discount_percent: z.string().optional(),
});

type StudentFormValues = z.infer<typeof StudentSchema>;

// No more mockStudents — pure live preference (backend data only)

const statusVariants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  active: 'default',
  inactive: 'secondary',
  graduated: 'outline',
  suspended: 'destructive',
};

export function StudentsPage() {
  const { hasPermission } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [isEnrollOpen, setIsEnrollOpen] = useState(false);
  const [enrollProgramId, setEnrollProgramId] = useState('');
  const [enrollVersionId, setEnrollVersionId] = useState('');

  const { data: studentsData = [] } = useStudents({ status: statusFilter === 'all' ? undefined : statusFilter });
  const createStudent = useCreateStudent();
  const enrollStudent = useEnrollStudent();
  const { data: classes = [] } = useClasses();
  const { data: programs = [] } = usePrograms();

  const { data: programVersions = [] } = useProgramVersions(enrollProgramId);

  // Live student assessments (when a student is selected)
  const { data: studentHomework = [] } = useStudentHomework(selectedStudent?.id || '');
  const { data: studentExams = [] } = useStudentExams(selectedStudent?.id || '');
  const markHomework = useMarkHomeworkDone();
  const createExamResult = useCreateExamResult();

  // Live journey events (for StudentJourneyTimeline)
  const { data: liveJourneyEvents = [] } = useStudentJourney(selectedStudent?.id || '');

  // Live promotion recommendation (uses live exam avg + attendance via PromotionService)
  const { data: promotionRec } = usePromotionRecommend(selectedStudent?.id || '', enrollProgramId || undefined);
  const applyPromotion = useApplyPromotion();

  // Live certificate issuance from student detail (great for designer / head_of_department)
  const issueCertFromStudent = useIssueCertificate();
  const printCert = usePrintCertificate(); // now available for real PDF/print from student detail too
  const [showCertPreviewInStudent, setShowCertPreviewInStudent] = useState(false);
  const [certTemplate, setCertTemplate] = useState<'classic' | 'modern' | 'minimal'>('classic');
  const [certGrade, setCertGrade] = useState('Pass');

  // Pure live preference (mocks removed)
  const liveStudents = Array.isArray(studentsData) ? studentsData : [];
  const students = liveStudents.filter((s: any) => {
    const matchesSearch = searchQuery === '' ||
      (s.full_name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.student_code || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.phone || '').includes(searchQuery);
    const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<StudentFormValues>({
    resolver: zodResolver(StudentSchema),
  });

  const onSubmit = (data: StudentFormValues) => {
    createStudent.mutate({
      full_name: data.full_name,
      phone: data.phone,
      email: data.email || undefined,
      gender: data.gender,
      father_name: data.father_name,
      address_region: data.address_region,
      tazkira_no: data.tazkira_no,
      whatsapp: data.whatsapp,
      dob: data.dob,
      discount_percent: Number(data.discount_percent) || 0,
      branch_id: 'branch-1', // TODO: from auth
    } as any, {
      onSuccess: () => {
        setIsAddDialogOpen(false);
        reset();
      }
    });
  };

  const handleDelete = (id: string) => {
    // TODO: real delete mutation
  };

  const handleEnroll = (studentId: string, classId: string) => {
    enrollStudent.mutate({
      studentId,
      data: {
        class_id: classId,
        program_version_id: enrollVersionId || undefined,
        enrollment_type: 'new',
      },
    }, {
      onSuccess: () => {
        setIsEnrollOpen(false);
        setEnrollProgramId('');
        setEnrollVersionId('');
      },
    });
  };

  const stats = {
    total: students.length,
    active: students.filter((s: any) => s.status === 'active').length,
    graduated: students.filter((s: any) => s.status === 'graduated').length,
    inactive: students.filter((s: any) => s.status !== 'active' && s.status !== 'graduated').length,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <GraduationCap className="h-8 w-8" />
            Students
          </h1>
          <p className="text-muted-foreground">Manage student records and enrollment</p>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={() => exportStudents(students as any)}>
            <Download className="h-4 w-4 me-2" />
            Export CSV
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 me-2" />
                Add Student
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Register New Student</DialogTitle>
              <DialogDescription>
                Fill in the student's information to create a new record
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="full_name">Full Name *</Label>
                  <Input id="full_name" placeholder="Student's full name" {...register('full_name')} />
                  {errors.full_name && <p className="text-xs text-destructive">{errors.full_name.message}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="father_name">Father's Name</Label>
                  <Input id="father_name" placeholder="Father's name" {...register('father_name')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" placeholder="+93 700 000 000" {...register('phone')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="whatsapp">WhatsApp</Label>
                  <Input id="whatsapp" placeholder="+93 700 000 000" {...register('whatsapp')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="student@example.com" {...register('email')} />
                  {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select onValueChange={(v) => register('gender').onChange({ target: { value: v } })}>
                    <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dob">Date of Birth</Label>
                  <Input id="dob" type="date" {...register('dob')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tazkira_no">Tazkira No.</Label>
                  <Input id="tazkira_no" placeholder="National ID number" {...register('tazkira_no')} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address_region">Address / Region</Label>
                  <Input id="address_region" placeholder="Address or region" {...register('address_region')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="school_or_university">School / University</Label>
                  <Input id="school_or_university" placeholder="Current school or university" {...register('school_or_university')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="discount_percent">Discount (%)</Label>
                  <Input id="discount_percent" type="number" min="0" max="100" placeholder="0" {...register('discount_percent')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emergency_contact_name">Emergency Contact Name</Label>
                  <Input id="emergency_contact_name" {...register('emergency_contact_name')} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emergency_contact_phone">Emergency Contact Phone</Label>
                  <Input id="emergency_contact_phone" {...register('emergency_contact_phone')} />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setIsAddDialogOpen(false); reset(); }}>
                  Cancel
                </Button>
                <Button type="submit">Register Student</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">Total Students</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-600">{stats.active}</div>
            <p className="text-xs text-muted-foreground">Active</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-blue-600">{stats.graduated}</div>
            <p className="text-xs text-muted-foreground">Graduated</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-orange-600">{stats.inactive}</div>
            <p className="text-xs text-muted-foreground">Inactive / Suspended</p>
          </CardContent>
        </Card>
      </div>

      {/* Search & Filter */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, code, or phone..."
                className="ps-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 me-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="graduated">Graduated</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Gender</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Class</TableHead>
                <TableHead>Discount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-end">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    No students found. {searchQuery && 'Try a different search term.'}
                  </TableCell>
                </TableRow>
              ) : (
                students.map((student: any) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-mono text-xs">{student.student_code}</TableCell>
                    <TableCell className="font-medium">{student.full_name}</TableCell>
                    <TableCell className="capitalize">{student.gender}</TableCell>
                    <TableCell className="text-muted-foreground">{student.phone}</TableCell>
                    <TableCell>{student.class_name}</TableCell>
                    <TableCell>{student.discount_percent > 0 ? `${student.discount_percent}%` : '—'}</TableCell>
                    <TableCell>
                      <Badge variant={statusVariants[student.status]}>{student.status}</Badge>
                    </TableCell>
                    <TableCell className="text-end">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setSelectedStudent(student)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => { setSelectedStudent(student); setIsEnrollOpen(true); }}>
                          Enroll
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => handleDelete(student.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Student Detail Dialog */}
      <Dialog open={!!selectedStudent} onOpenChange={() => setSelectedStudent(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedStudent && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  {selectedStudent.full_name}
                </DialogTitle>
                <DialogDescription>{selectedStudent.student_code}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Father's Name</p>
                    <p className="font-medium">{selectedStudent.father_name || '—'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Gender</p>
                    <p className="font-medium capitalize">{selectedStudent.gender}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <Phone className="h-3 w-3" /> Phone
                    </p>
                    <p className="font-medium">{selectedStudent.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Class</p>
                    <p className="font-medium">{selectedStudent.class_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Registration Date</p>
                    <p className="font-medium">{selectedStudent.registration_date}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Discount</p>
                    <p className="font-medium">{selectedStudent.discount_percent}%</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={statusVariants[selectedStudent.status]}>{selectedStudent.status}</Badge>
                  <Button size="sm" variant="outline" onClick={() => { setIsEnrollOpen(true); }}>Enroll in Class</Button>
                </div>

                {/* Student Journey Timeline — now fully live */}
                <div className="border-t pt-4">
                  <StudentJourneyTimeline 
                    studentName={selectedStudent.full_name} 
                    events={liveJourneyEvents as any} 
                  />
                </div>

                {/* Live Promotion Recommendation (uses PromotionService + live exam avg + attendance) */}
                {promotionRec && (
                  <div className="border-t pt-4">
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      Promotion Recommendation <Badge variant={promotionRec.can_promote ? 'default' : 'secondary'}>{promotionRec.can_promote ? 'Eligible' : 'Not yet'}</Badge>
                    </h4>
                    <div className="text-xs grid grid-cols-2 gap-x-4 gap-y-1 bg-muted/30 p-2 rounded">
                      <div>Current Level: <span className="font-medium">{promotionRec.current_level || '—'}</span></div>
                      <div>Exam Avg: <span className="font-medium">{promotionRec.exam_avg}</span></div>
                      <div>Attendance: <span className="font-medium">{promotionRec.attendance_rate}%</span></div>
                      <div>Recommendations: <span className="font-medium">{promotionRec.recommendations?.length || 0}</span></div>
                    </div>
                    {promotionRec.recommendations?.length > 0 && (
                      <div className="mt-1 text-[10px] text-muted-foreground flex items-center gap-2">
                        {promotionRec.recommendations.map((r: any, i: number) => (
                          <span key={i}>→ {r.to_level} (auto: {r.auto_promote ? 'yes' : 'no'}) </span>
                        ))}
                        {promotionRec.can_promote && (
                          <Button 
                            size="sm" 
                            className="h-6 px-2 text-xs"
                            onClick={() => {
                              const rec = promotionRec.recommendations[0];
                              applyPromotion.mutate({
                                studentId: selectedStudent.id,
                                data: {
                                  to_level_id: rec.to_level,
                                  from_level_id: rec.from_level,
                                  program_version_id: enrollProgramId || undefined,
                                  reason: 'Promoted via UI (live)',
                                }
                              });
                            }}
                            disabled={applyPromotion.isPending}
                          >
                            {applyPromotion.isPending ? 'Applying...' : 'Apply Promotion'}
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Live Certificate Issuance (designer / head_of_department) — per 14_ROLE + Certificate.Issue */}
                {hasPermission && hasPermission('Certificate.Issue') && (
                  <div className="border-t pt-4">
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      Issue Certificate <Badge variant="outline">Designer</Badge>
                    </h4>

                    <div className="flex flex-wrap gap-2 items-center text-xs">
                      <Select value={certTemplate} onValueChange={(v: any) => setCertTemplate(v)}>
                        <SelectTrigger className="h-7 w-[120px] text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="classic">Classic</SelectItem>
                          <SelectItem value="modern">Modern</SelectItem>
                          <SelectItem value="minimal">Minimal</SelectItem>
                        </SelectContent>
                      </Select>

                      <Select value={certGrade} onValueChange={setCertGrade}>
                        <SelectTrigger className="h-7 w-[90px] text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Pass">Pass</SelectItem>
                          <SelectItem value="Merit">Merit</SelectItem>
                          <SelectItem value="Distinction">Distinction</SelectItem>
                          <SelectItem value="A">A</SelectItem>
                        </SelectContent>
                      </Select>

                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs"
                        onClick={() => setShowCertPreviewInStudent(true)}
                      >
                        <Eye className="h-3 w-3 mr-1" /> Preview
                      </Button>

                      <Button
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() => {
                          issueCertFromStudent.mutate({
                            studentId: selectedStudent.id,
                            data: {
                              certificate_no: `CERT-${new Date().getFullYear()}-${Math.floor(10000 + Math.random()*90000)}`,
                              grade: certGrade,
                              level_id: enrollProgramId || undefined,
                              template: certTemplate,
                            },
                          });
                        }}
                        disabled={issueCertFromStudent.isPending}
                      >
                        {issueCertFromStudent.isPending ? 'Issuing...' : 'Issue Now'}
                      </Button>
                    </div>

                    {/* Inline live preview */}
                    {showCertPreviewInStudent && (
                      <div className="mt-3">
                        <CertificatePreview
                          studentName={selectedStudent.full_name}
                          studentCode={selectedStudent.student_code}
                          certificateNo={`CERT-${new Date().getFullYear()}-PREV`}
                          grade={certGrade}
                          level={enrollProgramId ? 'L5' : undefined}
                          mode={certTemplate}
                        />
                        <Button size="sm" variant="ghost" className="mt-1 h-6 text-xs" onClick={() => setShowCertPreviewInStudent(false)}>Close Preview</Button>
                      </div>
                    )}
                  </div>
                )}

                {/* Live Assessments (Homework + Exams) — new in this continue */}
                <div className="border-t pt-4 space-y-4">
                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      Homework <Badge variant="outline">{(studentHomework as any[]).length}</Badge>
                    </h4>
                    <div className="text-xs space-y-1 max-h-28 overflow-auto">
                      {(studentHomework as any[]).length > 0 ? (
                        (studentHomework as any[]).slice(0, 5).map((h: any) => (
                          <div key={h.id} className="flex justify-between p-1 bg-muted/30 rounded items-center">
                            <span>{h.title}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">{h.due_date || h.session_date}</span>
                              {h.status !== 'completed' && (
                                <Button size="sm" variant="ghost" className="h-6 px-1.5 text-[10px]" onClick={() => markHomework.mutate(h.id)}>
                                  Mark done
                                </Button>
                              )}
                            </div>
                          </div>
                        ))
                      ) : (
                        <span className="text-muted-foreground">No homework records.</span>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      Exam Results <Badge variant="outline">{(studentExams as any[]).length}</Badge>
                    </h4>
                    <div className="text-xs space-y-1">
                      {(studentExams as any[]).length > 0 ? (
                        (studentExams as any[]).slice(0, 4).map((er: any) => (
                          <div key={er.id} className="flex justify-between p-1 bg-muted/30 rounded">
                            <span>{er.title || er.exam_title}</span>
                            <span className="font-medium">{er.score} {er.exam_fee_paid ? '✓' : ''}</span>
                          </div>
                        ))
                      ) : (
                        <span className="text-muted-foreground">No exam results yet.</span>
                      )}
                    </div>

                    {/* Live quick result recorder */}
                    <div className="mt-2 flex gap-1 items-center text-[10px]">
                      <Input placeholder="Exam ID" className="h-6 w-20 text-[10px]" id="quick-exam-id" />
                      <Input placeholder="Score" type="number" className="h-6 w-16 text-[10px]" id="quick-score" />
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="h-6 px-2 text-[10px]"
                        onClick={() => {
                          const examId = (document.getElementById('quick-exam-id') as HTMLInputElement)?.value;
                          const score = (document.getElementById('quick-score') as HTMLInputElement)?.value;
                          if (examId && score && selectedStudent) {
                            createExamResult.mutate({
                              examId,
                              data: { student_id: selectedStudent.id, score: parseFloat(score) }
                            });
                          }
                        }}
                      >
                        Record
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setSelectedStudent(null)}>Close</Button>
                <Button>Edit Student</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Enroll Dialog */}
      <Dialog open={isEnrollOpen} onOpenChange={setIsEnrollOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enroll {selectedStudent?.full_name}</DialogTitle>
            <DialogDescription>Select program (for snapshot) + class</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Program (pins version + fee snapshot)</Label>
              <Select value={enrollProgramId} onValueChange={(v) => { setEnrollProgramId(v); setEnrollVersionId(''); }}>
                <SelectTrigger><SelectValue placeholder="Select program" /></SelectTrigger>
                <SelectContent>
                  {programs.length > 0 ? programs.map((p: any) => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  )) : <SelectItem value="">No programs</SelectItem>}
                </SelectContent>
              </Select>
            </div>
            {enrollProgramId && (
              <div>
                <Label>Program Version</Label>
                <Select value={enrollVersionId} onValueChange={setEnrollVersionId}>
                  <SelectTrigger><SelectValue placeholder="Select version" /></SelectTrigger>
                  <SelectContent>
                    {programVersions.length > 0 ? programVersions.map((v: any) => (
                      <SelectItem key={v.id} value={v.id}>{v.version_label || 'v' + (v.version_number || 1)}</SelectItem>
                    )) : <SelectItem value="">Default (latest)</SelectItem>}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div>
              <Label>Class</Label>
              <Select onValueChange={(classId) => {
                if (selectedStudent) handleEnroll(selectedStudent.id, classId);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.filter((c: any) => c.status === 'active').map((cls: any) => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name} — {cls.enrolled_count || 0}/{cls.capacity || 20}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsEnrollOpen(false); setEnrollProgramId(''); setEnrollVersionId(''); }}>Cancel</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
