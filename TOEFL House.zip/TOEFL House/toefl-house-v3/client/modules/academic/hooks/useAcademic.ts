/**
 * Academic Module - TanStack Query Hooks
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { academicApi } from '../api';
import type { Student, AcademicClass, Session } from '../types';
import { toast } from 'sonner';

export const academicKeys = {
  all: ['academic'] as const,
  students: (p?: any) => [...academicKeys.all, 'students', p] as const,
  student: (id: string) => [...academicKeys.students(), id] as const,
  classes: (p?: any) => [...academicKeys.all, 'classes', p] as const,
  class: (id: string) => [...academicKeys.classes(), id] as const,
  sessions: (classId: string) => [...academicKeys.all, 'sessions', classId] as const,
  programs: () => [...academicKeys.all, 'programs'] as const,
  programVersions: (programId: string) => [...academicKeys.all, 'programVersions', programId] as const,
};

export function useStudents(params?: any) {
  return useQuery({
    queryKey: academicKeys.students(params),
    queryFn: () => academicApi.students.list(params),
    staleTime: 30_000,
  });
}

export function useStudent(id: string) {
  return useQuery({
    queryKey: academicKeys.student(id),
    queryFn: () => academicApi.students.get(id),
    enabled: !!id,
  });
}

export function useClasses(params?: any) {
  return useQuery({
    queryKey: academicKeys.classes(params),
    queryFn: () => academicApi.classes.list(params),
  });
}

export function useClassRoster(classId: string) {
  return useQuery({
    queryKey: [...academicKeys.class(classId), 'roster'],
    queryFn: () => academicApi.classes.roster(classId),
    enabled: !!classId,
  });
}

export function useClass(id: string) {
  return useQuery({
    queryKey: academicKeys.class(id),
    queryFn: () => academicApi.classes.get(id),
    enabled: !!id,
  });
}

export function useSessions(classId: string) {
  return useQuery({
    queryKey: academicKeys.sessions(classId),
    queryFn: () => academicApi.sessions.list(classId),
    enabled: !!classId,
  });
}

export function useCreateStudent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: academicApi.students.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['academic', 'students'] }),
  });
}

export function useEnrollStudent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ studentId, data }: { studentId: string; data: any }) =>
      academicApi.students.enroll(studentId, data),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: academicKeys.student(vars.studentId) });
    },
  });
}

export function useCreateClass() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: academicApi.classes.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['academic', 'classes'] }),
  });
}

export function useCreateSession() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ classId, data }: { classId: string; data: any }) =>
      academicApi.sessions.create(classId, data),
    onSuccess: (_, vars) => qc.invalidateQueries({ queryKey: academicKeys.sessions(vars.classId) }),
  });
}

export function useUpdateAttendance() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ sessionId, attendance }: { sessionId: string; attendance: any }) =>
      academicApi.sessions.updateAttendance(sessionId, attendance),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['academic', 'sessions'] });
    },
  });
}

export function useRoster(sessionId: string) {
  return useQuery({
    queryKey: [...academicKeys.all, 'roster', sessionId],
    queryFn: () => academicApi.sessions.roster(sessionId),
    enabled: !!sessionId,
  });
}

export function usePrograms() {
  return useQuery({
    queryKey: academicKeys.programs(),
    queryFn: () => academicApi.programs.list(),
  });
}

export function useProgramVersions(programId: string) {
  return useQuery({
    queryKey: academicKeys.programVersions(programId),
    queryFn: () => academicApi.programs.versions(programId),
    enabled: !!programId,
  });
}

// === Homework + Exams (new live wiring) ===
const homeworkKeys = (classId: string) => [...academicKeys.all, 'homework', classId] as const;
const examKeys = (classId: string) => [...academicKeys.all, 'exams', classId] as const;
const examResultKeys = (examId: string) => [...academicKeys.all, 'examResults', examId] as const;

export function useHomeworks(classId: string) {
  return useQuery({
    queryKey: homeworkKeys(classId),
    queryFn: () => academicApi.homework.list(classId),
    enabled: !!classId,
  });
}

export function useCreateHomework() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ classId, data }: { classId: string; data: any }) =>
      academicApi.homework.create(classId, data),
    onSuccess: (_, vars) => qc.invalidateQueries({ queryKey: homeworkKeys(vars.classId) }),
  });
}

export function useUpdateHomework() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data, classId }: { id: string; data: any; classId: string }) =>
      academicApi.homework.update(id, data),
    onSuccess: (_, vars) => qc.invalidateQueries({ queryKey: homeworkKeys(vars.classId) }),
  });
}

// === Exams (new live) ===
export function useExams(classId: string) {
  return useQuery({
    queryKey: examKeys(classId),
    queryFn: () => academicApi.exams.list(classId),
    enabled: !!classId,
  });
}

export function useCreateExam() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ classId, data }: { classId: string; data: any }) =>
      academicApi.exams.create(classId, data),
    onSuccess: (_, vars) => qc.invalidateQueries({ queryKey: examKeys(vars.classId) }),
  });
}

export function useExamResults(examId: string) {
  return useQuery({
    queryKey: examResultKeys(examId),
    queryFn: () => academicApi.exams.results(examId),
    enabled: !!examId,
  });
}

export function useCreateExamResult() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ examId, data }: { examId: string; data: any }) =>
      academicApi.exams.createResult(examId, data),
    onSuccess: (_, vars) => qc.invalidateQueries({ queryKey: examResultKeys(vars.examId) }),
  });
}

// === Student Assessments (new live endpoints) ===
export function useStudentHomework(studentId: string) {
  return useQuery({
    queryKey: [...academicKeys.all, 'studentHomework', studentId],
    queryFn: () => academicApi.studentAssessments.homework(studentId),
    enabled: !!studentId,
  });
}

export function useStudentExams(studentId: string) {
  return useQuery({
    queryKey: [...academicKeys.all, 'studentExams', studentId],
    queryFn: () => academicApi.studentAssessments.exams(studentId),
    enabled: !!studentId,
  });
}

export function useMarkHomeworkDone() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (homeworkId: string) => academicApi.homework.markDone(homeworkId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['academic', 'homework'] });
      qc.invalidateQueries({ queryKey: ['academic', 'studentHomework'] });
    },
  });
}

// === Live Student Journey (append-only events) ===
export function useStudentJourney(studentId: string) {
  return useQuery({
    queryKey: [...academicKeys.all, 'journey', studentId],
    queryFn: () => academicApi.students.journey(studentId),
    enabled: !!studentId,
    staleTime: 15_000,
  });
}

// === Promotion (live from PromotionService)
export function usePromotionRecommend(studentId: string, programVersionId?: string) {
  return useQuery({
    queryKey: [...academicKeys.all, 'promotion', studentId, programVersionId],
    queryFn: () => academicApi.promotion.recommend(studentId, programVersionId),
    enabled: !!studentId,
  });
}

// === Certificates (live — Certificate.Issue + certificateQueue per 14_ROLE)
const certificateKeys = (params?: any) => [...academicKeys.all, 'certificates', params] as const;

export function useCertificates(params?: { student_id?: string; branch_id?: string }) {
  return useQuery({
    queryKey: certificateKeys(params),
    queryFn: () => academicApi.certificates.list(params),
    staleTime: 30_000,
  });
}

export function useIssueCertificate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ studentId, data }: { studentId: string; data: any }) =>
      academicApi.certificates.issue(studentId, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['academic', 'certificates'] });
      qc.invalidateQueries({ queryKey: ['academic', 'journey'] });
    },
  });
}

export function useRevokeCertificate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => academicApi.certificates.revoke(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['academic', 'certificates'] }),
  });
}

// NEW: Live certificate print / PDF generation with template (hardened per 14_ROLE + Report spec)
// Calls real /reports/certificates/{id}?template=  (backend ReportGenerationService + blade template support)
// PRIMARY PATH: Real DomPDF PDF (blob download via /storage/ + path)
// Fallbacks: HTML printable + JSON
export function usePrintCertificate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ certificateId, template }: { certificateId: string; template?: string }) =>
      academicApi.certificates.print(certificateId, template),
    onSuccess: (res: any, vars) => {
      qc.invalidateQueries({ queryKey: ['academic', 'certificates'] });

      const data = res?.data || res;
      const filename = data?.filename || `certificate-${vars.certificateId}-${vars.template || 'classic'}.pdf`;
      const templateUsed = vars.template || data?.template || 'classic';

      const cert = data?.certificate || data || {};
      const stu = data?.student || {};

      const backendHtml = data?.html;
      const realPdfPath = data?.download_url || data?.path;
      const isRealPdf = data?.pdf === true || !!realPdfPath;

      // === PRIMARY: Real PDF download (DomPDF) ===
      if (isRealPdf && realPdfPath) {
        const a = document.createElement('a');
        // Make absolute if relative (e.g. /storage/...)
        a.href = realPdfPath.startsWith('http') ? realPdfPath : (window.location.origin + realPdfPath);
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        // Also open printable window for review (with button to re-download)
        const win = window.open('', '_blank');
        if (win) {
          win.document.write(`
            <html><head><title>${filename}</title></head><body style="font-family:system-ui;padding:40px;text-align:center;background:#f8fafc">
              <h2>✅ Real PDF Generated</h2>
              <p><strong>${filename}</strong> downloaded automatically.</p>
              <p><a href="${a.href}" download="${filename}" style="background:#0f172a;color:white;padding:10px 18px;border-radius:6px;text-decoration:none">Download PDF Again</a></p>
              <p style="font-size:12px;color:#64748b;margin-top:30px">Template: ${templateUsed.toUpperCase()} • Generated via ReportGenerationService (DomPDF)</p>
            </body></html>
          `);
          win.document.close();
        }

        toast?.success?.(`✅ Real PDF downloaded: ${filename}`);
        return;
      }

      // === FALLBACK: HTML printable + files ===
      const win = window.open('', '_blank');
      let printableHtml = '';

      if (backendHtml) {
        printableHtml = backendHtml;
      } else {
        const isModern = templateUsed === 'modern';
        const isMinimal = templateUsed === 'minimal';
        const borderColor = isModern ? '#334155' : isMinimal ? '#e5e7eb' : '#d4af37';
        const headerColor = isModern ? '#334155' : isMinimal ? '#1f2937' : '#d4af37';

        printableHtml = `
          <html><head><title>${filename}</title>
          <style>
            @page { size: A4 landscape; margin: 1.5cm; }
            body { font-family: system-ui, sans-serif; background:#f8fafc; padding:20px; margin:0; }
            .cert { max-width:900px; margin:0 auto; background:white; border:8px solid ${borderColor}; padding:40px; box-shadow:0 10px 40px rgba(0,0,0,.15); text-align:center; position:relative; }
            .header h1 { font-size:38px; color:${headerColor}; margin:0; letter-spacing:2px; text-transform:uppercase; }
            .header h2 { font-size:20px; color:#64748b; margin:8px 0 30px; }
            .student { font-size:42px; font-weight:700; border-bottom:3px solid ${borderColor}; display:inline-block; padding:0 30px 8px; margin:20px 0; color:#0f172a; }
            .details { font-size:16px; color:#475569; margin:24px 0; line-height:1.7; }
            .grade { font-size:20px; font-weight:600; color:#1e40af; }
            .footer { margin-top:50px; display:flex; justify-content:space-around; font-size:13px; color:#334155; }
            .sig { text-align:center; }
            .sig-line { border-top:2px solid #334155; width:160px; margin:0 auto 6px; }
            .meta { position:absolute; bottom:16px; font-size:10px; color:#64748b; }
            .meta.left { left:20px; } .meta.right { right:20px; }
            .template-badge { position:absolute; top:18px; right:18px; font-size:10px; padding:2px 8px; background:#f1f5f9; border-radius:999px; color:#475569; }
          </style>
          </head><body>
            <div class="cert">
              <div class="template-badge">${templateUsed.toUpperCase()}</div>
              <div class="header">
                <h1>Certificate of Completion</h1>
                <h2>TOEFL House Educational Institute — Afghanistan</h2>
              </div>
              <div class="details">This is to certify that</div>
              <div class="student">${stu.full_name || 'Student'}</div>
              <div class="details">has successfully completed the requirements for<br>
                <strong>${data.program?.name || 'General English Program'}</strong>
                ${data.level?.name ? '<br>' + data.level.name : ''}
              </div>
              <div class="details">with a grade of <span class="grade">${cert.grade || 'Pass'}</span></div>

              <div class="footer">
                <div class="sig"><div class="sig-line"></div>Director</div>
                <div class="sig"><div class="sig-line"></div>Academic Coordinator</div>
              </div>

              <div class="meta left">Issued: ${cert.issue_date || new Date().toISOString().slice(0,10)}</div>
              <div class="meta right">No: ${cert.certificate_no || ''}</div>
            </div>
            <div style="text-align:center;margin-top:12px;font-size:11px;color:#64748b">
              Generated live via ReportGenerationService • Template: ${templateUsed} • <button onclick="window.print()" style="background:#0f172a;color:#fff;border:none;padding:4px 10px;border-radius:4px;cursor:pointer">Print / Save as PDF</button>
            </div>
          </body></html>
        `;
      }

      if (win) {
        win.document.write(printableHtml);
        win.document.close();
      }

      // Download printable HTML
      const printableBlob = new Blob([printableHtml], { type: 'text/html' });
      const printableUrl = URL.createObjectURL(printableBlob);
      const dl = document.createElement('a');
      dl.href = printableUrl;
      dl.download = filename.replace(/\.pdf$/, '.printable.html');
      document.body.appendChild(dl);
      dl.click();
      document.body.removeChild(dl);
      URL.revokeObjectURL(printableUrl);

      // JSON report
      const jsonBlob = new Blob([JSON.stringify({ ...data, template: templateUsed, filename, generated_via: 'report-endpoint' }, null, 2)], { type: 'application/json' });
      const jsonUrl = URL.createObjectURL(jsonBlob);
      const jsonA = document.createElement('a');
      jsonA.href = jsonUrl;
      jsonA.download = filename.replace('.pdf', '.report.json');
      document.body.appendChild(jsonA);
      jsonA.click();
      document.body.removeChild(jsonA);
      URL.revokeObjectURL(jsonUrl);

      toast?.success?.(`Certificate ready (${templateUsed}). Printable HTML + JSON downloaded. Use Print → Save as PDF.`);
    },
  });
}

export function usePromotionRules(programVersionId: string) {
  return useQuery({
    queryKey: [...academicKeys.all, 'promotionRules', programVersionId],
    queryFn: () => academicApi.promotion.rules(programVersionId),
    enabled: !!programVersionId,
  });
}

export function useApplyPromotion() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ studentId, data }: { studentId: string; data: any }) =>
      academicApi.promotion.apply(studentId, data),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ['academic', 'journey', vars.studentId] });
      qc.invalidateQueries({ queryKey: ['academic', 'promotion', vars.studentId] });
      qc.invalidateQueries({ queryKey: ['academic', 'students'] });
      qc.invalidateQueries({ queryKey: ['academic', 'classes'] });
      qc.invalidateQueries({ queryKey: ['academic', 'roster'] });
    },
  });
}
