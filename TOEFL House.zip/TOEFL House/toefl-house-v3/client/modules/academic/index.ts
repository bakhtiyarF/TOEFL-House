/**
 * Academic Module - Public Interface
 */

export {
  useStudents,
  useStudent,
  useClasses,
  useCreateStudent,
  useEnrollStudent,
  useCreateClass,
  useSessions,
  useCreateSession,
  useUpdateAttendance,
  useRoster,
  usePrograms,
  useProgramVersions,
  useHomeworks,
  useCreateHomework,
  useUpdateHomework,
  useExams,
  useCreateExam,
  useExamResults,
  useCreateExamResult,
  useStudentHomework,
  useStudentExams,
  useStudentJourney,
  useMarkHomeworkDone,
  usePromotionRecommend,
  usePromotionRules,
} from './hooks/useAcademic';

export { StudentsPage } from './components/StudentsPage';
export { ClassesPage } from './components/ClassesPage';
export { AttendanceMarking } from './components/AttendanceMarking';
export { StudentJourneyTimeline } from './components/StudentJourneyTimeline';

export type {
  Student,
  AcademicClass,
  Session,
  Enrollment,
  Homework,
  Exam,
  ExamResult,
} from './types';
