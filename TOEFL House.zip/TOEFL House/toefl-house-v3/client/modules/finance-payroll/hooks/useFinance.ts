import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { financeApi } from '../api';

export const financeKeys = {
  payments: (p?: any) => ['finance', 'payments', p] as const,
  studentFinance: (id: string) => ['finance', 'student', id] as const,
  teacherSalary: (id: string) => ['finance', 'teacher', id] as const,
  budget: () => ['finance', 'budget'] as const,
  expenses: (p?: any) => ['finance', 'expenses', p] as const,
  payrollLedger: (p?: any) => ['finance', 'payroll-ledger', p] as const,
};

export function usePayments(params?: any) {
  return useQuery({ queryKey: financeKeys.payments(params), queryFn: () => financeApi.payments.list(params) });
}

export function useStudentFinance(studentId: string) {
  return useQuery({ queryKey: financeKeys.studentFinance(studentId), queryFn: () => financeApi.studentFinance(studentId), enabled: !!studentId });
}

export function useCreatePayment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: financeApi.payments.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['finance'] }),
  });
}

export function useTeacherSalary(teacherId: string, period?: string) {
  return useQuery({
    queryKey: financeKeys.teacherSalary(teacherId),
    queryFn: () => financeApi.teacherSalary(teacherId, period),
    enabled: !!teacherId,
  });
}

export function useBudgetLines() {
  return useQuery({
    queryKey: financeKeys.budget(),
    queryFn: () => financeApi.budgetLines.list(),
  });
}

export function useCreateBudgetLine() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: financeApi.budgetLines.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['finance', 'budget'] }),
  });
}

export function useUpdateBudgetLine() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => financeApi.budgetLines.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['finance', 'budget'] }),
  });
}

export function usePayTeacherSalary() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ teacherId, data }: { teacherId: string; data: any }) =>
      financeApi.payTeacher(teacherId, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['finance'] });
      qc.invalidateQueries({ queryKey: ['people-hr'] });
    },
  });
}

export function useProcessPayroll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: financeApi.processPayroll,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['finance'] });
      qc.invalidateQueries({ queryKey: ['people-hr'] });
    },
  });
}

export function useBudgetOverview() {
  return useQuery({
    queryKey: ['finance', 'budget', 'overview'],
    queryFn: () => financeApi.budgetOverview(),
  });
}

// === NEW LIVE: Expense Requests (07 spec) ===
export function useExpenses(params?: any) {
  return useQuery({ queryKey: financeKeys.expenses(params), queryFn: () => financeApi.expenses.list(params) });
}

export function useCreateExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: financeApi.expenses.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['finance', 'expenses'] }),
  });
}

export function useApproveExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => financeApi.expenses.approve(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['finance', 'expenses'] });
      qc.invalidateQueries({ queryKey: ['finance', 'budget'] });
    },
  });
}

export function useRejectExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, reason }: { id: string; reason?: string }) => financeApi.expenses.reject(id, reason || ''),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['finance', 'expenses'] }),
  });
}

// === Payroll Ledger (live history) ===
export function usePayrollLedger(params?: any) {
  return useQuery({ queryKey: financeKeys.payrollLedger(params), queryFn: () => financeApi.payrollLedger(params) });
}

// === Per-teacher salary history (06 spec — live delegated ledger) ===
export function useTeacherSalaryHistory(teacherId: string) {
  return useQuery({
    queryKey: ['finance', 'teacher-salary-history', teacherId],
    queryFn: () => financeApi.teacherSalaryHistory(teacherId),
    enabled: !!teacherId,
  });
}

// === Invoices (live 07 spec) ===
export function useInvoices(params?: any) {
  return useQuery({ queryKey: ['finance', 'invoices', params], queryFn: () => financeApi.invoices.list(params) });
}

export function useCreateInvoice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: financeApi.invoices.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['finance', 'invoices'] }),
  });
}

export function useMarkInvoicePaid() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => financeApi.invoices.markPaid(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['finance', 'invoices'] }),
  });
}
