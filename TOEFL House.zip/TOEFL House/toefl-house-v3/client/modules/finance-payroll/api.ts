/**
 * Finance & Payroll Module - API Client
 */
const API_BASE = '/api';

async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers },
    credentials: 'include',
  });
  if (!res.ok) throw new Error(await res.text());
  return res.status === 204 ? ({} as T) : res.json();
}

export const financeApi = {
  payments: {
    list: (params?: any) => request<any[]>(`/payments?${new URLSearchParams(params || {}).toString()}`),
    create: (data: any) => request('/payments', { method: 'POST', body: JSON.stringify(data) }),
  },
  studentFinance: (studentId: string) => request(`/students/${studentId}/finance-summary`),
  teacherSalary: (teacherId: string, period?: string) =>
    request(`/teachers/${teacherId}/computed-salary${period ? `?period=${period}` : ''}`),
  payTeacher: (teacherId: string, data: any) =>
    request(`/teachers/${teacherId}/pay-salary`, { method: 'POST', body: JSON.stringify(data) }),
  budgetLines: {
    list: (params?: any) => {
      const q = new URLSearchParams(params || {}).toString();
      return request<any[]>(`/budget-lines?${q}`);
    },
    create: (d: any) => request('/budget-lines', { method: 'POST', body: JSON.stringify(d) }),
    update: (id: string, d: any) => request(`/budget-lines/${id}`, { method: 'PATCH', body: JSON.stringify(d) }),
  },
  budgetOverview: () => request<any>('/budget/overview'),
  // Payroll processing entry
  processPayroll: (data: any) => request('/payroll/process', { method: 'POST', body: JSON.stringify(data) }),

  // NEW: Live expenses (per 07 spec)
  expenses: {
    list: (params?: any) => request<any[]>(`/expense-requests?${new URLSearchParams(params || {}).toString()}`),
    create: (data: any) => request('/expense-requests', { method: 'POST', body: JSON.stringify(data) }),
    approve: (id: string) => request(`/expense-requests/${id}/approve`, { method: 'POST' }),
    reject: (id: string, reason: string) => request(`/expense-requests/${id}/reject`, { 
      method: 'POST', 
      body: JSON.stringify({ reject_reason: reason }) 
    }),
  },

  // Payroll ledger (live history)
  payrollLedger: (params?: any) => request<any[]>(`/payroll/ledger?${new URLSearchParams(params || {}).toString()}`),
  // Per-teacher salary history (06 spec - delegated)
  teacherSalaryHistory: (teacherId: string) => request<any[]>(`/payroll/ledger?teacher_id=${teacherId}`),

  // Reports
  generatePayrollReport: (data: { branch_id: string; period_key: string }) =>
    request('/reports/payroll', { method: 'POST', body: JSON.stringify(data) }),

  // Invoices (07 spec)
  invoices: {
    list: (params?: any) => request<any[]>(`/invoices?${new URLSearchParams(params || {}).toString()}`),
    create: (data: any) => request('/invoices', { method: 'POST', body: JSON.stringify(data) }),
    markPaid: (id: string) => request(`/invoices/${id}/mark-paid`, { method: 'POST' }),
  },
};
