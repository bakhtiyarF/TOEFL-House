/**
 * Visitors Page — CRM & Enrollment Module
 * Pipeline visualization, follow-up tracking, visitor → student conversion
 */

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@shared/components/ui/card';
import { Button } from '@shared/components/ui/button';
import { Badge } from '@shared/components/ui/badge';
import { Input } from '@shared/components/ui/input';
import { Label } from '@shared/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@shared/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@shared/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@shared/components/ui/select';
import {
  UserPlus, Plus, Search, Phone, ArrowRight, CheckCircle2, XCircle,
  Clock, MessageSquare, GraduationCap, AlertCircle, TrendingUp, Filter,
} from 'lucide-react';
import { toast } from 'sonner';
import { useVisitors, useConvertVisitor, useCreateVisitor, useCreateFollowup, useVisitorFollowups, useConversionReadiness, useCampaigns } from '../hooks/useCrm';
import { useClasses, usePrograms, useProgramVersions } from '@modules/academic/hooks/useAcademic';

const VisitorSchema = z.object({
  full_name: z.string().min(2, 'Name is required'),
  phone: z.string().min(5, 'Phone is required'),
  email: z.string().email().optional().or(z.literal('')),
  gender: z.enum(['male', 'female']).optional(),
  source: z.string().optional(),
  interested_course: z.string().optional(),
  notes: z.string().optional(),
});

type VisitorFormValues = z.infer<typeof VisitorSchema>;

interface Visitor {
  id: string;
  serial_no: string;
  full_name: string;
  phone: string;
  stage: string;
  source: string;
  visit_date: string;
  status: string;
  interested_course: string;
  placement_score: number | null;
  placement_fee_paid: boolean;
  next_contact_date: string | null;
  assigned_to: string;
}

const stages = ['lead', 'inquiry', 'follow_up', 'placement_booking', 'placement_completed', 'registration', 'enrollment'] as const;

const stageColors: Record<string, string> = {
  lead: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200',
  inquiry: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  follow_up: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  placement_booking: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  placement_completed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  registration: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
  enrollment: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
  lost: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
};

// mockVisitors removed — strictly prefer live data from backend (visitorsData) per spec. Empty state used when no live data.

export function VisitorsPage() {
  const { data: visitorsData = [], isLoading } = useVisitors();
  const createVisitor = useCreateVisitor();
  const convertVisitor = useConvertVisitor();
  const createFollowup = useCreateFollowup();
  const { data: campaigns = [] } = useCampaigns();

  const [isFollowupOpen, setIsFollowupOpen] = useState(false);
  const [followupVisitor, setFollowupVisitor] = useState<Visitor | null>(null);
  const [followupNote, setFollowupNote] = useState('');
  const [followupDate, setFollowupDate] = useState('');
  const [followupOutcome, setFollowupOutcome] = useState<'interested' | 'not_interested' | 'callback' | 'registered'>('interested');

  // Live follow-ups list per visitor (per 14_ROLE + full CRM)
  const { data: followups = [] } = useVisitorFollowups(followupVisitor?.id || '');

  const { data: programs = [] } = usePrograms();
  const [convertProgramId, setConvertProgramId] = useState('');
  const { data: convertVersions = [] } = useProgramVersions(convertProgramId);

  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isConvertDialogOpen, setIsConvertDialogOpen] = useState(false);
  const [selectedVisitor, setSelectedVisitor] = useState<Visitor | null>(null);

  // Live readiness for selected visitor (per 09 spec — real backend ConversionService)
  const { data: liveReadiness, isLoading: readinessLoading } = useConversionReadiness(selectedVisitor?.id || null);

  // Prefer live data exclusively (mocks only as last resort for empty first boot)
  const liveVisitors = (Array.isArray(visitorsData) ? visitorsData : []) as Visitor[];
  const visitors: Visitor[] = liveVisitors.length > 0 ? liveVisitors : [];

  const filtered = visitors.filter((v) => {
    const matchesSearch = searchQuery === '' ||
      v.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.phone.includes(searchQuery);
    const matchesStage = stageFilter === 'all' || v.stage === stageFilter;
    return matchesSearch && matchesStage;
  });

  const pipelineCounts = stages.reduce((acc, stage) => {
    acc[stage] = visitors.filter((v) => v.stage === stage).length;
    return acc;
  }, {} as Record<string, number>);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<VisitorFormValues>({
    resolver: zodResolver(VisitorSchema),
  });

  const onSubmit = (data: VisitorFormValues) => {
    createVisitor.mutate({
      full_name: data.full_name,
      phone: data.phone,
      email: data.email || undefined,
      source: data.source,
      interested_course: data.interested_course,
      notes: data.notes,
      branch_id: 'branch-1',
    } as any, {
      onSuccess: () => {
        setIsAddDialogOpen(false);
        reset();
      },
    });
  };

  const canConvert = (visitor: Visitor) => {
    // Prefer live backend readiness when available
    if (selectedVisitor?.id === visitor.id && liveReadiness) {
      return liveReadiness.canConvert === true;
    }
    return visitor.placement_score !== null && visitor.placement_fee_paid && visitor.status !== 'registered';
  };

  const handleConvert = (visitor: Visitor) => {
    if (!canConvert(visitor)) return;

    convertVisitor.mutate({
      id: visitor.id,
      data: {
        program_version_id: convertVersions?.[0]?.id || undefined,
      },
    }, {
      onSuccess: (result: any) => {
        setIsConvertDialogOpen(false);
        setSelectedVisitor(null);
        setConvertProgramId('');
        // TanStack auto-refreshes students + visitors
      },
    });
  };

  const conversionRate = visitors.length > 0
    ? Math.round((visitors.filter((v) => v.status === 'registered' || v.stage === 'enrollment').length / visitors.length) * 100)
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <UserPlus className="h-8 w-8" />
            Visitors & Leads
          </h1>
          <p className="text-muted-foreground">Manage visitor pipeline and enrollment conversion</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 me-2" /> Add Visitor</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Visitor</DialogTitle>
              <DialogDescription>Log a new visitor/lead</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2 col-span-2">
                  <Label>Full Name *</Label>
                  <Input placeholder="Visitor's name" {...register('full_name')} />
                  {errors.full_name && <p className="text-xs text-destructive">{errors.full_name.message}</p>}
                </div>
                <div className="space-y-2">
                  <Label>Phone *</Label>
                  <Input placeholder="+93 700 000 000" {...register('phone')} />
                  {errors.phone && <p className="text-xs text-destructive">{errors.phone.message}</p>}
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input type="email" {...register('email')} />
                </div>
                <div className="space-y-2">
                  <Label>Source</Label>
                  <Select onValueChange={(v) => register('source').onChange({ target: { value: v } })}>
                    <SelectTrigger><SelectValue placeholder="How did they find us?" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="friend">Friend Referral</SelectItem>
                      <SelectItem value="social">Social Media</SelectItem>
                      <SelectItem value="ads">Advertisement</SelectItem>
                      <SelectItem value="referral">Partner Referral</SelectItem>
                      <SelectItem value="organic">Walk-in / Organic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Interested Course</Label>
                  <Select onValueChange={(v) => register('interested_course').onChange({ target: { value: v } })}>
                    <SelectTrigger><SelectValue placeholder="Select course" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="General English">General English</SelectItem>
                      <SelectItem value="TOEFL Prep">TOEFL Preparation</SelectItem>
                      <SelectItem value="IELTS">IELTS</SelectItem>
                      <SelectItem value="Business English">Business English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Notes</Label>
                  <Input placeholder="Additional notes..." {...register('notes')} />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Campaign (optional)</Label>
                  <Select onValueChange={(v) => { /* attach to data if extended */ }}>
                    <SelectTrigger><SelectValue placeholder="Select campaign" /></SelectTrigger>
                    <SelectContent>
                      {campaigns.length > 0 ? campaigns.map((c: any) => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      )) : <SelectItem value="">No campaigns</SelectItem>}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setIsAddDialogOpen(false); reset(); }}>Cancel</Button>
                <Button type="submit">Add Visitor</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Pipeline Summary */}
      <div className="grid gap-2 grid-cols-2 md:grid-cols-4 lg:grid-cols-7">
        {stages.map((stage) => (
          <Card key={stage} className="text-center p-3 cursor-pointer hover:bg-accent transition-colors" onClick={() => setStageFilter(stageFilter === stage ? 'all' : stage)}>
            <p className="text-2xl font-bold">{pipelineCounts[stage] || 0}</p>
            <p className="text-xs text-muted-foreground capitalize">{stage.replace(/_/g, ' ')}</p>
          </Card>
        ))}
      </div>

      {/* Conversion Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-2xl font-bold">{conversionRate}%</p>
                <p className="text-xs text-muted-foreground">Conversion Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{visitors.filter(v => v.next_contact_date).length}</p>
                <p className="text-xs text-muted-foreground">Pending Follow-ups</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">{visitors.filter(v => v.placement_score !== null).length}</p>
                <p className="text-xs text-muted-foreground">Placement Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Visitors Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search visitors..." className="ps-10" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            </div>
            <Select value={stageFilter} onValueChange={setStageFilter}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 me-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stages</SelectItem>
                {stages.map((s) => (
                  <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Serial</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Stage</TableHead>
                <TableHead className="text-center">Placement</TableHead>
                <TableHead className="text-end">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((visitor) => (
                <TableRow key={visitor.id}>
                  <TableCell className="font-mono text-xs">{visitor.serial_no}</TableCell>
                  <TableCell className="font-medium">{visitor.full_name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Phone className="h-3 w-3" />
                      <span className="text-xs">{visitor.phone}</span>
                    </div>
                  </TableCell>
                  <TableCell className="capitalize text-sm">{visitor.source}</TableCell>
                  <TableCell className="text-sm">{visitor.interested_course}</TableCell>
                  <TableCell>
                    <Badge className={stageColors[visitor.stage]}>
                      {visitor.stage.replace(/_/g, ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    {visitor.placement_score !== null ? (
                      <div className="flex items-center justify-center gap-1">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium">{visitor.placement_score}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-xs">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-end">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => { setSelectedVisitor(visitor); setIsConvertDialogOpen(true); }}
                        disabled={!canConvert(visitor)}
                        className={canConvert(visitor) ? 'text-green-600' : ''}
                      >
                        <ArrowRight className="h-4 w-4 me-1" />
                        Convert
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => { setFollowupVisitor(visitor); setFollowupNote(''); setFollowupDate(''); setIsFollowupOpen(true); }}
                      >
                        <MessageSquare className="h-4 w-4 me-1" />
                        Follow-up
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Conversion Dialog */}
      <Dialog open={isConvertDialogOpen} onOpenChange={setIsConvertDialogOpen}>
        <DialogContent>
          {selectedVisitor && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <GraduationCap className="h-5 w-5" />
                  Convert to Student
                </DialogTitle>
                <DialogDescription>
                  Review conversion readiness for {selectedVisitor.full_name}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {/* Readiness Check — LIVE from ConversionService (09 spec) */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-2">
                    Conversion Readiness 
                    {readinessLoading && <span className="text-xs">(checking...)</span>}
                  </h4>
                  <div className="space-y-2 text-sm">
                    {liveReadiness ? (
                      <>
                        <div className="flex items-center gap-2">
                          {liveReadiness.placementCompleted ? (
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                          <span>Placement {liveReadiness.placementCompleted ? 'completed' : 'not completed'}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {liveReadiness.placementFeePaid ? (
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                          <span>Placement fee {liveReadiness.placementFeePaid ? 'paid' : 'unpaid'}</span>
                        </div>
                        <div>
                          {liveReadiness.canConvert ? (
                            <span className="text-green-600 font-medium">✓ Ready to convert</span>
                          ) : (
                            <div className="text-destructive">
                              <span className="font-medium">Blocked:</span>
                              <ul className="list-disc pl-5 mt-1 text-xs">
                                {liveReadiness.reasons?.map((r: string, i: number) => <li key={i}>{r}</li>)}
                              </ul>
                            </div>
                          )}
                        </div>
                      </>
                    ) : (
                      // Fallback to local visitor data
                      <>
                        <div className="flex items-center gap-2">
                          {selectedVisitor.placement_score !== null ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <XCircle className="h-4 w-4 text-red-600" />}
                          <span>Placement {selectedVisitor.placement_score !== null ? `completed (Score: ${selectedVisitor.placement_score})` : 'not completed'}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {selectedVisitor.placement_fee_paid ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <XCircle className="h-4 w-4 text-red-600" />}
                          <span>Placement fee {selectedVisitor.placement_fee_paid ? 'paid' : 'unpaid (300 AFN required)'}</span>
                        </div>
                      </>
                    )}
                    <div className="flex items-center gap-2">
                      {selectedVisitor.status !== 'registered' ? <CheckCircle2 className="h-4 w-4 text-green-600" /> : <AlertCircle className="h-4 w-4 text-orange-600" />}
                      <span>{selectedVisitor.status !== 'registered' ? 'Not yet converted' : 'Already converted'}</span>
                    </div>
                  </div>
                </div>

                {/* Enrollment Details */}
                {canConvert(selectedVisitor) && (
                  <div className="border-t pt-4 space-y-3">
                    <h4 className="text-sm font-medium">Enrollment Details (copy-on-write snapshot)</h4>
                    <div className="space-y-2">
                      <div>
                        <Label className="text-xs">Program</Label>
                        <Select value={convertProgramId} onValueChange={(v) => setConvertProgramId(v)}>
                          <SelectTrigger className="h-8"><SelectValue placeholder="Select program" /></SelectTrigger>
                          <SelectContent>
                            {programs.length > 0 ? programs.map((p: any) => (
                              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                            )) : <SelectItem value="">No programs</SelectItem>}
                          </SelectContent>
                        </Select>
                      </div>
                      {convertProgramId && (
                        <div>
                          <Label className="text-xs">Program Version</Label>
                          <Select defaultValue="">
                            <SelectTrigger className="h-8"><SelectValue placeholder="Latest" /></SelectTrigger>
                            <SelectContent>
                              {convertVersions.length > 0 ? convertVersions.map((v: any) => (
                                <SelectItem key={v.id} value={v.id}>{v.version_label || 'v' + (v.version_number || 1)}</SelectItem>
                              )) : <SelectItem value="">Use default</SelectItem>}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">Program version + fee snapshot will be pinned by backend EnrollmentService.</div>
                  </div>
                )}

                {!canConvert(selectedVisitor) && (
                  <div className="bg-destructive/10 rounded-lg p-3">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-destructive mt-0.5" />
                      <div className="text-sm text-destructive">
                        <p className="font-medium">Cannot convert</p>
                        <p className="text-xs mt-1">
                          {selectedVisitor.status === 'registered'
                            ? 'This visitor has already been converted to a student.'
                            : 'Complete placement test and pay the placement fee before converting.'}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => { setIsConvertDialogOpen(false); setSelectedVisitor(null); }}>Cancel</Button>
                <Button
                  onClick={() => handleConvert(selectedVisitor)}
                  disabled={!canConvert(selectedVisitor)}
                >
                  <GraduationCap className="h-4 w-4 me-2" />
                  Convert to Student
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Follow-up Dialog — live via useCreateFollowup + live follow-up history (per 14_ROLE + CRM specs) */}
      <Dialog open={isFollowupOpen} onOpenChange={setIsFollowupOpen}>
        <DialogContent className="max-w-md">
          {followupVisitor && (
            <>
              <DialogHeader>
                <DialogTitle>Log Follow-up — {followupVisitor.full_name}</DialogTitle>
                <DialogDescription>Record next contact (live)</DialogDescription>
              </DialogHeader>

              {/* Live prior follow-ups for context (per 14_ROLE + CRM) */}
              {Array.isArray(followups) && followups.length > 0 && (
                <div className="max-h-28 overflow-auto border rounded p-2 bg-muted/30 text-xs space-y-1">
                  <div className="font-medium text-[10px] mb-1">Prior follow-ups</div>
                  {followups.slice(0, 4).map((f: any, i: number) => (
                    <div key={i} className="flex justify-between border-b pb-0.5 last:border-none">
                      <span className="truncate">{f.note || f.description}</span>
                      <span className="text-[10px] text-muted-foreground whitespace-nowrap ml-2">{f.next_date || f.created_at?.slice(0,10)}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <Label>Note</Label>
                  <Input value={followupNote} onChange={(e) => setFollowupNote(e.target.value)} placeholder="Follow-up details..." />
                </div>
                <div>
                  <Label>Next Contact Date</Label>
                  <Input type="date" value={followupDate} onChange={(e) => setFollowupDate(e.target.value)} />
                </div>
                <div>
                  <Label>Outcome</Label>
                  <Select value={followupOutcome} onValueChange={(v: any) => setFollowupOutcome(v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="interested">Interested</SelectItem>
                      <SelectItem value="callback">Callback</SelectItem>
                      <SelectItem value="not_interested">Not Interested</SelectItem>
                      <SelectItem value="registered">Registered</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsFollowupOpen(false)}>Cancel</Button>
                <Button
                  disabled={!followupNote || !followupVisitor}
                  onClick={() => {
                    createFollowup.mutate({
                      visitorId: followupVisitor.id,
                      data: {
                        date: followupDate || new Date().toISOString().slice(0,10),
                        note: followupNote,
                        outcome: followupOutcome,
                      },
                    }, {
                      onSuccess: () => {
                        setIsFollowupOpen(false);
                        setFollowupVisitor(null);
                        setFollowupNote('');
                        setFollowupDate('');
                        setFollowupOutcome('interested');
                        toast.success('Follow-up logged live');
                      },
                    });
                  }}
                >
                  Log Follow-up
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
