import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { crmApi } from '../api';

export function useVisitors(params?: any) {
  return useQuery({ queryKey: ['crm', 'visitors', params], queryFn: () => crmApi.visitors.list(params) });
}

export function useCreateVisitor() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: crmApi.visitors.create,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['crm', 'visitors'] });
    },
  });
}

export function useConvertVisitor() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data?: any }) => crmApi.visitors.convert(id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['crm'] });
      qc.invalidateQueries({ queryKey: ['academic', 'students'] });
    },
  });
}

export function useCreateFollowup() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ visitorId, data }: { visitorId: string; data: any }) => crmApi.followups.create(visitorId, data),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ['crm', 'visitors'] });
      qc.invalidateQueries({ queryKey: ['crm', 'followups', vars.visitorId] });
    },
  });
}

export function useVisitorFollowups(visitorId: string) {
  return useQuery<any[]>({
    queryKey: ['crm', 'followups', visitorId],
    queryFn: async () => {
      const res = await crmApi.followups.list(visitorId);
      return Array.isArray(res) ? res : [];
    },
    enabled: !!visitorId,
  });
}

export function useCampaigns() {
  return useQuery({
    queryKey: ['crm', 'campaigns'],
    queryFn: () => crmApi.campaigns.list(),
    staleTime: 30_000,
  });
}

export function useCreateCampaign() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: crmApi.campaigns.create,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['crm', 'campaigns'] }),
  });
}

export function useConversionReadiness(visitorId: string | null) {
  return useQuery({
    queryKey: ['crm', 'readiness', visitorId],
    queryFn: () => (visitorId ? crmApi.visitors.getConversionReadiness(visitorId) : Promise.resolve(null)),
    enabled: !!visitorId,
    staleTime: 5_000,
  });
}
