const API_BASE = '/api';
async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, { ...options, headers: { 'Content-Type': 'application/json', ...options.headers }, credentials: 'include' });
  if (!res.ok) throw new Error(await res.text());
  return res.status === 204 ? ({} as T) : res.json();
}

export const crmApi = {
  visitors: {
    list: (params?: any) => request(`/visitors?${new URLSearchParams(params || {}).toString()}`),
    create: (d: any) => request('/visitors', { method: 'POST', body: JSON.stringify(d) }),
    show: (id: string) => request(`/visitors/${id}`),
    getConversionReadiness: (id: string) => request(`/visitors/${id}/conversion-readiness`),
    convert: (id: string, data?: any) => request(`/visitors/${id}/convert`, { method: 'POST', body: JSON.stringify(data || {}) }),
  },
  followups: {
    list: async (visitorId: string): Promise<any[]> => {
      try {
        const res = await request<any>(`/visitors/${visitorId}`);
        if (res && Array.isArray(res.followups)) return res.followups;
        const direct = await request<any[]>(`/visitors/${visitorId}/followups`);
        return Array.isArray(direct) ? direct : [];
      } catch {
        return [];
      }
    },
    create: (visitorId: string, data: any) => request(`/visitors/${visitorId}/followups`, { method: 'POST', body: JSON.stringify(data) }),
  },
  campaigns: {
    list: () => request('/campaigns'),
    create: (d: any) => request('/campaigns', { method: 'POST', body: JSON.stringify(d) }),
  },
};
