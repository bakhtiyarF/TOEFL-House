/**
 * DonorLedger
 * Rich, live donor ledger for donor_manager (per 14_ROLE_WORKSPACE_SPECIFICATIONS)
 * Shows donations with live data, search, export (CSV + JSON).
 * Organization-scope friendly.
 */
import { useState } from 'react';
import { useDonations, useDonors, useCampaigns } from '../hooks/useFunding';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@shared/components/ui/card';
import { Button } from '@shared/components/ui/button';
import { Input } from '@shared/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@shared/components/ui/table';
import { Badge } from '@shared/components/ui/badge';
import { Download, Search } from 'lucide-react';
import { formatAmount } from '@shared/lib/utils';
import { toast } from 'sonner';

export function DonorLedger() {
  const { data: donations = [] } = useDonations();
  const { data: donors = [] } = useDonors();
  const { data: campaigns = [] } = useCampaigns();

  const [search, setSearch] = useState('');

  const donorMap = Object.fromEntries((donors as any[]).map((d: any) => [d.id, d]));
  const campaignMap = Object.fromEntries((campaigns as any[]).map((c: any) => [c.id, c]));

  const filteredDonations = (donations as any[])
    .filter((d: any) => {
      const donor = donorMap[d.donor_id];
      const donorName = donor?.full_name || d.donor_id || '';
      const campaignName = d.campaign_id ? (campaignMap[d.campaign_id]?.name || '') : '';
      const q = search.toLowerCase();
      return (
        donorName.toLowerCase().includes(q) ||
        (d.receipt_no || '').toLowerCase().includes(q) ||
        campaignName.toLowerCase().includes(q) ||
        String(d.amount || '').includes(q)
      );
    })
    .sort((a: any, b: any) => (b.date || '').localeCompare(a.date || ''));

  const totalAmount = filteredDonations.reduce((sum: number, d: any) => sum + (Number(d.amount) || 0), 0);

  const exportLedger = (format: 'csv' | 'json') => {
    if (!filteredDonations.length) {
      toast.info('No donations to export');
      return;
    }

    if (format === 'csv') {
      const header = 'date,donor,amount,receipt,campaign,restricted\n';
      const rows = filteredDonations.map((d: any) => {
        const donor = donorMap[d.donor_id];
        const donorName = donor?.full_name || d.donor_id;
        const camp = d.campaign_id ? (campaignMap[d.campaign_id]?.name || d.campaign_id) : '';
        return `${d.date || ''},"${donorName}",${d.amount || 0},${d.receipt_no || ''},"${camp}",${d.restricted ? 'yes' : 'no'}`;
      }).join('\n');
      const blob = new Blob([header + rows], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `donor_ledger_${new Date().toISOString().slice(0,10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Donor ledger exported as CSV');
    } else {
      const payload = {
        exported_at: new Date().toISOString(),
        total: totalAmount,
        count: filteredDonations.length,
        donations: filteredDonations.map((d: any) => ({
          ...d,
          donor_name: donorMap[d.donor_id]?.full_name || d.donor_id,
        })),
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `donor_ledger_${new Date().toISOString().slice(0,10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Donor ledger exported as JSON');
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5" /> Donor Ledger
              <Badge variant="outline" className="text-xs ml-2">{filteredDonations.length} records</Badge>
            </CardTitle>
            <CardDescription>Live donations • Organization scope (donor_manager)</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => exportLedger('csv')}>
              <Download className="h-3 w-3 mr-1" /> CSV
            </Button>
            <Button size="sm" variant="outline" onClick={() => exportLedger('json')}>
              <Download className="h-3 w-3 mr-1" /> JSON
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 mb-3">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search donor, receipt, campaign..."
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="text-sm text-muted-foreground ml-auto">
            Total: <span className="font-semibold text-foreground">{formatAmount(totalAmount)} AFN</span>
          </div>
        </div>

        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Donor</TableHead>
                <TableHead>Campaign</TableHead>
                <TableHead className="text-end">Amount</TableHead>
                <TableHead>Receipt</TableHead>
                <TableHead className="w-12">Restricted</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDonations.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground text-sm">
                    No donations match your search. Record donations to populate the ledger.
                  </TableCell>
                </TableRow>
              ) : (
                filteredDonations.slice(0, 25).map((don: any, idx: number) => {
                  const donor = donorMap[don.donor_id];
                  const donorName = donor?.full_name || don.donor_id || '—';
                  const campName = don.campaign_id ? (campaignMap[don.campaign_id]?.name || don.campaign_id) : '—';
                  return (
                    <TableRow key={don.id || idx}>
                      <TableCell className="font-mono text-xs">{don.date || '—'}</TableCell>
                      <TableCell className="font-medium">{donorName}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{campName}</TableCell>
                      <TableCell className="text-end font-mono font-medium">
                        {formatAmount(don.amount)} AFN
                      </TableCell>
                      <TableCell className="font-mono text-xs">{don.receipt_no || '—'}</TableCell>
                      <TableCell>
                        {don.restricted ? (
                          <Badge variant="secondary" className="text-[10px]">Yes</Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>

        <div className="text-[10px] text-muted-foreground mt-2">
          Showing up to 25 most recent. Full export available above. Data live from backend.
        </div>
      </CardContent>
    </Card>
  );
}
