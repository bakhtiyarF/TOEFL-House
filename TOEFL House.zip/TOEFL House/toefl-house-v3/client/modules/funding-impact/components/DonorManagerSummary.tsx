/**
 * DonorManagerSummary
 * Generative, role-specific summary for donor_manager (per 14_ROLE_WORKSPACE_SPECIFICATIONS)
 * Shows live impact + campaign progress + quick donor actions.
 * Uses permission-driven visibility.
 */
import { useCampaigns, useImpactMetrics } from '../hooks/useFunding';
import { Card, CardContent, CardHeader, CardTitle } from '@shared/components/ui/card';
import { Badge } from '@shared/components/ui/badge';
import { Button } from '@shared/components/ui/button';
import { Link } from 'react-router-dom';
import { Heart, TrendingUp, Users, Award } from 'lucide-react';
import { formatAmount } from '@shared/lib/utils';

export function DonorManagerSummary() {
  const { data: campaigns = [] } = useCampaigns();
  const { data: impact = [] } = useImpactMetrics();

  const totalRaised = campaigns.reduce((s: number, c: any) => s + (c.raised_amount || 0), 0);
  const activeCampaigns = campaigns.filter((c: any) => c.status === 'active').length;
  const avgImpact = impact.length
    ? Math.round(impact.reduce((s: number, m: any) => s + (m.progress_percent || 0), 0) / impact.length)
    : 0;

  return (
    <Card className="border-rose-200 bg-rose-50/30 dark:bg-rose-950/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2 text-rose-700 dark:text-rose-300">
          <Heart className="h-5 w-5" />
          Donor Manager Overview
          <Badge variant="outline" className="ml-auto text-rose-600">Organization Scope</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <div className="text-xl font-bold text-rose-700">{formatAmount(totalRaised)} AFN</div>
            <div className="text-[10px] text-muted-foreground">Total Raised</div>
          </div>
          <div>
            <div className="text-xl font-bold text-rose-700">{activeCampaigns}</div>
            <div className="text-[10px] text-muted-foreground">Active Campaigns</div>
          </div>
          <div>
            <div className="text-xl font-bold text-rose-700">{avgImpact}%</div>
            <div className="text-[10px] text-muted-foreground">Avg Impact Progress</div>
          </div>
        </div>

        <div className="flex gap-2">
          <Link to="/funding">
            <Button size="sm" variant="outline" className="text-xs h-8">
              <TrendingUp className="h-3 w-3 mr-1" /> View Full Impact
            </Button>
          </Link>
          <Link to="/funding">
            <Button size="sm" className="text-xs h-8">
              <Users className="h-3 w-3 mr-1" /> Record Donation
            </Button>
          </Link>
        </div>

        {impact.length > 0 && (
          <div className="text-[10px] text-muted-foreground pt-1 border-t">
            Top metric: {impact[0]?.name} — {impact[0]?.progress_percent ?? 0}% of target
          </div>
        )}
      </CardContent>
    </Card>
  );
}
