/**
 * ImpactMetricsCard
 * Generative, live component for donor_manager + Funding roles
 * (per 14_ROLE + navRegistry 'impactMetrics' widget)
 */
import { useImpactMetrics } from '../hooks/useFunding';
import { Card, CardContent, CardHeader, CardTitle } from '@shared/components/ui/card';
import { Badge } from '@shared/components/ui/badge';
import { Star } from 'lucide-react';

export function ImpactMetricsCard() {
  const { data: metrics = [] } = useImpactMetrics();

  if (!metrics.length) {
    return (
      <Card className="border-dashed">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Star className="h-4 w-4" /> Impact Metrics
          </CardTitle>
        </CardHeader>
        <CardContent className="text-xs text-muted-foreground">
          No impact metrics recorded yet.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <Star className="h-4 w-4 text-rose-600" /> Live Impact Metrics
          <Badge variant="outline" className="text-[10px]">{metrics.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {metrics.slice(0, 4).map((m: any, idx: number) => {
          const progress = m.progress_percent ?? (m.target_value > 0 ? Math.round((m.current_value / m.target_value) * 100) : 0);
          return (
            <div key={idx} className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="font-medium truncate">{m.name}</span>
                <span className="text-muted-foreground tabular-nums">
                  {m.current_value} / {m.target_value}
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-1.5">
                <div
                  className={`h-1.5 rounded-full transition-all ${progress > 80 ? 'bg-emerald-500' : progress > 50 ? 'bg-yellow-500' : 'bg-rose-500'}`}
                  style={{ width: `${Math.min(100, progress)}%` }}
                />
              </div>
              <div className="text-[10px] text-muted-foreground text-end">{progress}% of target</div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
