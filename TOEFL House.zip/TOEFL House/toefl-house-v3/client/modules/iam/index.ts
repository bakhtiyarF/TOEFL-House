/**
 * IAM Module - Public Interface
 * Only these exports may be imported by other modules
 */

export { useAuth } from './hooks/useAuth';
// Placeholder stubs for legacy re-exports (not yet implemented in this module)
export const useBranches = () => ({ data: [] });
export const useOrganizations = () => ({ data: [] });
export const useCampuses = () => ({ data: [] });
export const useUsers = () => ({ data: [] });
export { LoginPage } from './components/LoginPage';
export { RouteGuard } from './components/RouteGuard';
export { AppLayout } from './components/AppLayout';
export type { AuthUser, User, Branch, Campus, Organization, ResolvedPermission, ScopeType } from './types';
