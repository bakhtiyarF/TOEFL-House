/**
 * App Layout Component
 * Main application shell with sidebar navigation
 * Uses mock auth for preview
 */

import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@shared/components/ui/button';
import { Badge } from '@shared/components/ui/badge';
import { cn } from '@shared/lib/utils';
import { CommandPalette } from '@shared/components/CommandPalette';
import { NotificationBell } from '@shared/components/NotificationBell';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  DollarSign,
  Package,
  Heart,
  Settings,
  LogOut,
  Menu,
  X,
  UserCircle,
  Building2,
  ClipboardList,
  UserPlus,
  Moon,
  Sun,
  FileText,
  Shield,
} from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  LayoutDashboard,
  GraduationCap,
  ClipboardList,
  Users,
  UserPlus,
  DollarSign,
  Package,
  Heart,
  Settings,
  FileText,
  Shield,
};
import { useUIStore } from '@shared/store';
import { useLocaleStore } from '@shared/store/locale';
import { GlobalSearch } from '@shared/components/GlobalSearch';
import { usePermissions } from '@modules/iam/hooks/usePermissions';
import { useAuth } from '@modules/iam/hooks/useAuth';
import { getNavForPermissions } from '@shared/permissions/navRegistry';

interface NavItem {
  label: string;
  icon: React.ElementType;
  href: string;
  permission?: string;
}

// Static navigation is now only a fallback. Primary source is the generative registry (14_ROLE_WORKSPACE_SPECIFICATIONS + navRegistry)
const staticNavigationFallback: any[] = [
  { label: 'Dashboard', icon: LayoutDashboard, href: '/', permission: 'Dashboard.View' },
  { label: 'Students', icon: GraduationCap, href: '/academic/students', permission: 'Student.View' },
  { label: 'Classes', icon: ClipboardList, href: '/academic/classes', permission: 'Class.View' },
  { label: 'Teachers', icon: Users, href: '/people-hr/teachers', permission: 'Teacher.View' },
  { label: 'Visitors & Leads', icon: UserPlus, href: '/crm/visitors', permission: 'Lead.View' },
  { label: 'Finance', icon: DollarSign, href: '/finance', permission: 'Payment.View' },
  { label: 'Inventory', icon: Package, href: '/inventory', permission: 'Book.View' },
  { label: 'Funding & Impact', icon: Heart, href: '/funding', permission: 'Funding.View' },
  { label: 'Settings', icon: Settings, href: '/settings', permission: 'Settings.View' },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout, hasPermission } = useAuth(); // hybrid live (Sanctum) + mock
  const { darkMode, toggleDarkMode } = useUIStore();
  const { locale, toggleLocale } = useLocaleStore();
  const { navItems: generativeNav, userPermissions, isOwner, canEditAttendance, canEditGrade } = usePermissions();

  // React to dev role switches instantly (seeded users from EnhancedSampleDataSeeder)
  const [roleVersion, setRoleVersion] = useState(0);
  useEffect(() => {
    const handler = () => setRoleVersion(v => v + 1);
    window.addEventListener('dev-role-switched', handler);
    return () => window.removeEventListener('dev-role-switched', handler);
  }, []);

  // Force sidebar regeneration on role change (key trick)
  const sidebarKey = `${user?.role || user?.username || 'anon'}-${roleVersion}`;

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  // Generative navigation (per 14_ROLE_WORKSPACE_SPECIFICATIONS + 03 §7)
  // Falls back to static only if registry returns nothing
  const filteredNavigation = generativeNav.length > 0
    ? generativeNav.map((n: any) => ({
        label: n.label,
        icon: iconMap[n.icon] || LayoutDashboard,
        href: n.href,
      }))
    : staticNavigationFallback.filter((item) => !item.permission || hasPermission(item.permission));

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 start-0 z-50 w-64 bg-sidebar border-e border-sidebar-border transform transition-transform duration-200 ease-in-out lg:translate-x-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex h-16 items-center justify-between px-6 border-b border-sidebar-border">
            <Link to="/" className="flex items-center gap-2">
              <Building2 className="h-6 w-6 text-sidebar-primary" />
              <span className="text-lg font-semibold text-sidebar-foreground">TOEFL House</span>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-4 space-y-1">
            {filteredNavigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href ||
                              (item.href !== '/' && location.pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                      : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* User section */}
          <div className="border-t border-sidebar-border p-4">
            <div className="flex items-center gap-3 mb-3">
              <UserCircle className="h-10 w-10 text-muted-foreground" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-sidebar-foreground truncate">
                  {user?.full_name}
                </p>
                <p className="text-xs text-muted-foreground truncate capitalize">
                  {user?.role?.replace('_', ' ')}
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4 me-2" />
              Sign out
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:ps-64">
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b border-border bg-background/95 backdrop-blur px-6">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>

          {/* Command palette / Global Search trigger */}
          <div className="hidden md:block flex-1 max-w-sm">
            <GlobalSearch />
          </div>

          <div className="flex-1 md:hidden" />
          <NotificationBell />
          <Button variant="ghost" size="icon" onClick={toggleLocale} title={locale === 'en' ? 'Switch to Dari' : 'Switch to English'}>
            <span className="text-xs font-bold">{locale === 'en' ? 'دری' : 'EN'}</span>
          </Button>
          <Button variant="ghost" size="icon" onClick={toggleDarkMode}>
            {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          {user?.branch && (
            <Badge variant="secondary" className="hidden sm:inline-flex">
              {user.branch.name}
            </Badge>
          )}

          {/* Dev role switcher lives in bottom-right <RoleSwitcher/> — fully generative */}
          {import.meta.env.DEV && (
            <Badge variant="outline" className="hidden sm:inline text-[10px] px-1.5">DEV MODE — use bottom-right switcher</Badge>
          )}
        </header>

        {/* Command Palette */}
        <CommandPalette />

        {/* Page content */}
        <main id="main-content" className="p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
