/**
 * usePermissions hook
 * Bridges mock/real auth to the generative nav registry (14_ROLE + 03 §7)
 */
import { useEffect, useState } from 'react';
import { useAuth } from './useAuth';
import { getNavForPermissions, getDashboardConfigForPermissions } from '@shared/permissions/navRegistry';

export function usePermissions() {
  const { user, hasPermission, refresh } = useAuth();   // hybrid live + mock

  // Force re-computation on dev role switches (instant generative UI)
  const [devRoleTick, setDevRoleTick] = useState(0);

  useEffect(() => {
    const handler = (e: any) => {
      setDevRoleTick(t => t + 1);
      refresh?.();
      // Also invalidate TanStack queries from outside if needed
      if ((window as any).__queryClient) {
        try { (window as any).__queryClient.invalidateQueries(); } catch {}
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('dev-role-switched', handler as any);
      return () => window.removeEventListener('dev-role-switched', handler as any);
    }
  }, [refresh]);

  // The tick is used implicitly to cause consumers to re-render when the hook runs
  const _ = devRoleTick; // eslint-disable-line

  const userPermissions = (user as any)?.permissions?.map?.((p: any) => p.code) 
    || (user as any)?.permissions?.map?.((p: any) => typeof p === 'string' ? p : p.code) 
    || [];

  const navItems = getNavForPermissions(userPermissions);
  const { widgets, quickActions } = getDashboardConfigForPermissions(userPermissions);

  // Expose the current effective role for debugging
  const effectiveRole = user?.role || user?.username || 'unknown';

  // Role-aware helpers (from 02 §5)
  const isOwner = user?.role === 'owner' || hasPermission('Dashboard.Executive');
  const canEditAttendance = hasPermission('Attendance.Edit');
  const canEditGrade = hasPermission('Grade.Edit');
  const canDeleteStudent = hasPermission('Student.Delete');
  const canDeletePayment = hasPermission('Payment.Delete');

  return {
    user,
    hasPermission,
    userPermissions,
    navItems,
    dashboardWidgets: widgets,
    dashboardQuickActions: quickActions,
    isOwner,
    // Explicit exclusions per 14 §4.1 (owner)
    canEditAttendance,
    canEditGrade,
    canDeleteStudent,
    canDeletePayment,
  };
}
