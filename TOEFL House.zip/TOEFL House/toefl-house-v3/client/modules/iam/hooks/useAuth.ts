/**
 * useAuth Hook — Real + Mock hybrid
 * Prefers live Sanctum /auth/me when authenticated.
 * Falls back to mock for dev/preview (as per 01 architecture).
 *
 * Returns the same interface as useMockAuth for drop-in compatibility.
 */
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { authApi } from '../api';
import { useMockAuth } from '@app/mockAuth';
import type { AuthUser } from '../types';

interface UseAuthReturn {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  hasPermission: (code: string) => boolean;
  refresh: () => void;
}

export function useAuth(): UseAuthReturn {
  const mock = useMockAuth();
  const qc = useQueryClient();

  // Live user query (only runs if we think we might be authenticated via cookies)
  const { data: liveUserData, isLoading: liveLoading, refetch } = useQuery({
    queryKey: ['auth', 'me'],
    queryFn: async () => {
      const res = await authApi.me();
      // Normalize: some backends return {user, permissions} directly
      if (res && (res as any).user) return res;
      // Legacy shape
      return { user: res as any, permissions: [] };
    },
    enabled: !!document.cookie.includes('XSRF-TOKEN') || mock.isAuthenticated,
    staleTime: 60_000,
    retry: false,
  });

  const liveUser = (liveUserData as any)?.user as AuthUser | undefined;
  const livePermissions = (liveUserData as any)?.permissions || [];

  // Unified user
  const user: AuthUser | null = liveUser || mock.user;
  const isAuthenticated = !!liveUser || mock.isAuthenticated;
  const isLoading = liveLoading || mock.isLoading;

  // Login mutation (tries real first, falls back to mock)
  const loginMutation = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      try {
        const res = await authApi.login({ username, password });
        if (res?.user) {
          // Live success — invalidate me
          await qc.invalidateQueries({ queryKey: ['auth', 'me'] });
          return { success: true, live: true };
        }
      } catch (e) {
        // fall through to mock
      }
      // Mock fallback
      const ok = await mock.login(username, password);
      return { success: ok, live: false };
    },
  });

  const login = async (username: string, password: string): Promise<boolean> => {
    const result = await loginMutation.mutateAsync({ username, password });
    if (result.success) {
      // Force all generative views (Dashboard, QuickActions, lists, nav) to re-evaluate with new role
      qc.invalidateQueries({ queryKey: ['auth'] });
      // Targeted for role-sensitive live data (certificates, funding, promotions, etc.)
      qc.invalidateQueries({ queryKey: ['academic'] });
      qc.invalidateQueries({ queryKey: ['funding'] });
      qc.invalidateQueries({ queryKey: ['crm'] });
      qc.invalidateQueries({ queryKey: ['finance'] });
    }
    return result.success;
  };

  const logout = async () => {
    try {
      await authApi.logout();
    } catch {}
    mock.logout();
    qc.invalidateQueries({ queryKey: ['auth'] });
  };

  const hasPermission = (code: string): boolean => {
    // Prefer live resolved permissions from PermissionResolutionService (02 §5.4)
    if (liveUser && livePermissions.length > 0) {
      return livePermissions.some((p: any) => p.code === code);
    }
    return mock.hasPermission(code);
  };

  return {
    user,
    isAuthenticated,
    isLoading,
    login,
    logout,
    hasPermission,
    refresh: () => refetch(),
  };
}
