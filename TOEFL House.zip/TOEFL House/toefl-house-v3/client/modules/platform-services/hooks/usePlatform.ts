import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { platformApi } from '../api';

export function useGlobalSearch(query: string, type = 'all') {
  return useQuery({
    queryKey: ['platform', 'search', query, type],
    queryFn: () => platformApi.search(query, type),
    enabled: query.length > 1,
    staleTime: 10_000,
  });
}

export function useNotifications() {
  return useQuery({
    queryKey: ['platform', 'notifications'],
    queryFn: () => platformApi.notifications.list(),
    staleTime: 15_000,
  });
}

export function useMarkNotificationRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => platformApi.notifications.markRead(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['platform', 'notifications'] }),
  });
}

export function useMarkAllNotificationsRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => platformApi.notifications.markAllAsRead(),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['platform', 'notifications'] }),
  });
}

export function useRules() {
  return useQuery({
    queryKey: ['platform', 'rules'],
    queryFn: () => platformApi.rules.list(),
    staleTime: 30_000,
  });
}

export function useEvaluateRule() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, context }: { id: string; context?: any }) =>
      platformApi.rules.evaluate(id, context),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['platform', 'rules'] });
    },
  });
}

export function useSettings() {
  return useQuery({
    queryKey: ['platform', 'settings'],
    queryFn: () => platformApi.settings.list(),
    staleTime: 20_000,
  });
}

export function useUpdateSetting() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ key, value }: { key: string; value: any }) =>
      platformApi.settings.update(key, value),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['platform', 'settings'] }),
  });
}

export function useBatchUpdateSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (settings: Record<string, any>) => platformApi.settings.batchUpdate(settings),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['platform', 'settings'] }),
  });
}

export function useAuditLogs(params?: Record<string, string>) {
  return useQuery({
    queryKey: ['platform', 'audit-logs', params],
    queryFn: () => platformApi.audit.list(params),
    staleTime: 20_000,
  });
}
