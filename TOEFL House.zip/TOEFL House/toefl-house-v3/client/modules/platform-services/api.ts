const API_BASE = '/api';
async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, { ...options, headers: { 'Content-Type': 'application/json', ...options.headers }, credentials: 'include' });
  if (!res.ok) throw new Error(await res.text());
  return res.status === 204 ? ({} as T) : res.json();
}

export const platformApi = {
  search: (q: string, type = 'all') => request(`/search?q=${encodeURIComponent(q)}&type=${type}`),

  rules: {
    list: () => request('/rules'),
    get: (id: string) => request(`/rules/${id}`),
    evaluate: (id: string, context: any = {}) =>
      request(`/rules/${id}/evaluate`, { method: 'POST', body: JSON.stringify({ data: context }) }),
  },

  notifications: {
    list: () => request('/notifications'),
    markRead: (id: string) => request(`/notifications/${id}/read`, { method: 'PATCH' }),
    markAllAsRead: () => request('/notifications/read-all', { method: 'POST' }),
  },

  settings: {
    list: () => request('/settings'),
    get: (k: string) => request(`/settings/${k}`),
    update: (key: string, value: any) => request(`/settings/${key}`, { method: 'PATCH', body: JSON.stringify({ value }) }),
    batchUpdate: (settings: Record<string, any>) => request('/settings/batch', { method: 'POST', body: JSON.stringify({ settings }) }),
  },

  audit: {
    list: (params?: Record<string, string>) => {
      const qs = params ? '?' + new URLSearchParams(params).toString() : '';
      return request(`/audit-logs${qs}`);
    },
  },
};
