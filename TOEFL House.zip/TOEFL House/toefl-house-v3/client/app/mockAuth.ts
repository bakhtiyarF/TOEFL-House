/**
 * Mock Auth Store — for development preview
 * Simulates authentication without a running backend
 */

import { create } from 'zustand';
import type { AuthUser } from '@modules/iam/types';

interface MockAuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  hasPermission: (code: string) => boolean;
}

// Mock user for preview purposes — default is general_manager (broad branch scope)
// You can switch role in dev via console: window.__switchRole('owner' | 'teacher' | ...)
// Seeded users from EnhancedSampleDataSeeder (password = "password")
const DEFAULT_ROLE = 'general_manager';

const SEEDED_USERNAMES: Record<string, string> = {
  owner: 'owner',
  general_manager: 'general_mgr',
  head_of_department: 'hod',
  finance_manager: 'finance_mgr',
  receptionist: 'reception',
  counselor: 'counselor',
  teacher: 'teacher1',
  data_entry: 'data_entry',
  designer: 'designer',
  donor_manager: 'donor_mgr',
};

const ROLE_PERMISSION_MAP: Record<string, any[]> = {
  owner: [
    { code: 'Dashboard.View', scope: 'organization', source: 'role' },
    { code: 'Dashboard.Executive', scope: 'organization', source: 'role' },
    { code: 'Student.View', scope: 'organization', source: 'role' },
    { code: 'Student.Create', scope: 'organization', source: 'role' },
    { code: 'Student.Edit', scope: 'organization', source: 'role' },
    { code: 'Class.View', scope: 'organization', source: 'role' },
    { code: 'Class.Create', scope: 'organization', source: 'role' },
    { code: 'Class.Edit', scope: 'organization', source: 'role' },
    { code: 'Teacher.View', scope: 'organization', source: 'role' },
    { code: 'Payment.View', scope: 'organization', source: 'role' },
    { code: 'Lead.View', scope: 'organization', source: 'role' },
    { code: 'Funding.View', scope: 'organization', source: 'role' },
    { code: 'Settings.View', scope: 'organization', source: 'role' },
    { code: 'Audit.View', scope: 'organization', source: 'role' },
    { code: 'User.View', scope: 'organization', source: 'role' },
    // NOTE: Owner explicitly EXCLUDES these (per 14 §4.1)
    // { code: 'Attendance.Edit' ... } — intentionally omitted
    // { code: 'Grade.Edit' ... }
    // { code: 'Student.Delete' ... }
    // { code: 'Payment.Delete' ... }
  ],
  general_manager: [
    { code: 'Dashboard.View', scope: 'branch', source: 'role' },
    { code: 'Dashboard.Executive', scope: 'branch', source: 'role' },
    { code: 'Student.View', scope: 'branch', source: 'role' },
    { code: 'Student.Create', scope: 'branch', source: 'role' },
    { code: 'Student.Edit', scope: 'branch', source: 'role' },
    { code: 'Class.View', scope: 'branch', source: 'role' },
    { code: 'Class.Create', scope: 'branch', source: 'role' },
    { code: 'Class.Edit', scope: 'branch', source: 'role' },
    { code: 'Teacher.View', scope: 'branch', source: 'role' },
    { code: 'Payment.View', scope: 'branch', source: 'role' },
    { code: 'Payment.Create', scope: 'branch', source: 'role' },
    { code: 'Budget.Allocate', scope: 'branch', source: 'role' },
    { code: 'Lead.View', scope: 'branch', source: 'role' },
    { code: 'Funding.View', scope: 'branch', source: 'role' },
    { code: 'Settings.View', scope: 'branch', source: 'role' },
    { code: 'Attendance.Edit', scope: 'branch', source: 'role' },
    { code: 'Grade.View', scope: 'branch', source: 'role' },
  ],
  head_of_department: [
    { code: 'Dashboard.View', scope: 'department', source: 'role' },
    { code: 'Class.View', scope: 'department', source: 'role' },
    { code: 'Session.View', scope: 'department', source: 'role' },
    { code: 'Attendance.View', scope: 'department', source: 'role' },
    { code: 'Attendance.Edit', scope: 'department', source: 'role' },
    { code: 'Exam.View', scope: 'department', source: 'role' },
    { code: 'Grade.View', scope: 'department', source: 'role' },
    { code: 'Promotion.Approve', scope: 'department', source: 'role' },
    { code: 'Certificate.Issue', scope: 'department', source: 'role' },
  ],
  finance_manager: [
    { code: 'Dashboard.View', scope: 'branch', source: 'role' },
    { code: 'Payment.View', scope: 'branch', source: 'role' },
    { code: 'Payment.Create', scope: 'branch', source: 'role' },
    { code: 'Invoice.View', scope: 'branch', source: 'role' },
    { code: 'Ledger.View', scope: 'branch', source: 'role' },
    { code: 'Payroll.View', scope: 'branch', source: 'role' },
    { code: 'Payroll.Process', scope: 'branch', source: 'role' },
    { code: 'Finance.Report', scope: 'branch', source: 'role' },
    // Explicitly NO Budget.Allocate (per 02 + 14)
  ],
  receptionist: [
    { code: 'Dashboard.View', scope: 'branch', source: 'role' },
    { code: 'Lead.View', scope: 'branch', source: 'role' },
    { code: 'Lead.Create', scope: 'branch', source: 'role' },
    { code: 'Lead.Convert', scope: 'branch', source: 'role' },
    { code: 'Student.View', scope: 'branch', source: 'role' },
    { code: 'Student.Create', scope: 'branch', source: 'role' },
    { code: 'Class.View', scope: 'branch', source: 'role' },
    { code: 'Payment.Create', scope: 'branch', source: 'role' },
    { code: 'Book.Sell', scope: 'branch', source: 'role' },
  ],
  counselor: [
    { code: 'Dashboard.View', scope: 'branch', source: 'role' },
    { code: 'Lead.View', scope: 'branch', source: 'role' },
    { code: 'Lead.Create', scope: 'branch', source: 'role' },
    { code: 'Student.View', scope: 'branch', source: 'role' }, // view-only
    { code: 'Class.View', scope: 'branch', source: 'role' },   // view-only
  ],
  teacher: [
    { code: 'Dashboard.View', scope: 'own', source: 'role' },
    { code: 'Student.View', scope: 'class', source: 'role' },
    { code: 'Class.View', scope: 'own', source: 'role' },
    { code: 'Session.View', scope: 'own', source: 'role' },
    { code: 'Session.Edit', scope: 'own', source: 'role' },
    { code: 'Attendance.View', scope: 'own', source: 'role' },
    { code: 'Attendance.Edit', scope: 'own', source: 'role' },
    { code: 'Exam.View', scope: 'own', source: 'role' },
    { code: 'Grade.View', scope: 'own', source: 'role' },
    { code: 'Grade.Edit', scope: 'own', source: 'role' },
  ],
  data_entry: [
    { code: 'Dashboard.View', scope: 'branch', source: 'role' },
    { code: 'Student.Create', scope: 'branch', source: 'role' },
    { code: 'Student.Edit', scope: 'branch', source: 'role' },
    { code: 'Teacher.Create', scope: 'branch', source: 'role' },
    { code: 'Class.Create', scope: 'branch', source: 'role' },
    { code: 'Class.Edit', scope: 'branch', source: 'role' },
    { code: 'Session.Create', scope: 'branch', source: 'role' },
  ],
  designer: [
    { code: 'Dashboard.View', scope: 'branch', source: 'role' },
    { code: 'Certificate.Issue', scope: 'branch', source: 'role' },
    { code: 'Settings.View', scope: 'branch', source: 'role' }, // read-only
  ],
  donor_manager: [
    { code: 'Dashboard.View', scope: 'branch', source: 'role' },
    { code: 'Funding.View', scope: 'organization', source: 'role' },
    { code: 'Donation.Create', scope: 'organization', source: 'role' },
    { code: 'Scholarship.Award', scope: 'organization', source: 'role' },
    { code: 'Impact.View', scope: 'organization', source: 'role' },
    { code: 'Finance.Report', scope: 'branch', source: 'role' },
  ],
};

function buildMockUser(roleCode: string = DEFAULT_ROLE) {
  const permissions = ROLE_PERMISSION_MAP[roleCode] || ROLE_PERMISSION_MAP.general_manager;
  return {
    id: 'mock-user-1',
    username: roleCode,
    full_name: roleCode === 'owner' ? 'Dr. Fatima Rahimi' : 
               roleCode === 'teacher' ? 'Mr. Karim Ahmad' : 
               'Ahmad Rahimi',
    role: roleCode as any,
    branch_id: 'branch-1',
    is_active: true,
    two_factor_enabled: false,
    must_change_password: false,
    created_at: '2026-01-01T00:00:00Z',
    permissions,
    branch: {
      id: 'branch-1',
      name: 'Main Campus - Kabul',
      location: 'Kabul, Afghanistan',
      is_active: true,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
  };
}

const mockUser = buildMockUser(DEFAULT_ROLE);

// Dev helper: restore last dev role from session (used by RoleSwitcher + seeded data)
function getDevOverrideUser(): any | null {
  if (typeof window === 'undefined') return null;
  const devRole = sessionStorage.getItem('dev-role');
  const devUsername = sessionStorage.getItem('dev-username');
  if (devRole) {
    const u = buildMockUser(devRole);
    if (devUsername) {
      u.username = devUsername;
      u.full_name = `${devUsername} (Seeded)`;
    }
    return u;
  }
  return null;
}

const initialUser = getDevOverrideUser() || null;

export const useMockAuth = create<MockAuthState>()((set, get) => ({
  user: initialUser,
  isAuthenticated: !!initialUser,
  isLoading: false,

  login: async (username: string, _password: string) => {
    set({ isLoading: true });
    // Simulate network delay
    await new Promise((r) => setTimeout(r, 550));

    if (username && _password) {
      // Map seeded username → exact role
      let roleToUse = DEFAULT_ROLE;
      let displayName = username;

      // Reverse lookup: find role for this seeded username
      for (const [role, seededName] of Object.entries(SEEDED_USERNAMES)) {
        if (seededName === username || username === role) {
          roleToUse = role;
          displayName = seededName;
          break;
        }
      }

      const newUser = buildMockUser(roleToUse);
      newUser.username = displayName;
      newUser.full_name = `${displayName} (Seeded)`;

      set({ user: newUser, isAuthenticated: true, isLoading: false });
      return true;
    }

    set({ isLoading: false });
    return false;
  },

  logout: () => {
    sessionStorage.removeItem('dev-role');
    sessionStorage.removeItem('dev-username');
    set({ user: null, isAuthenticated: false });
  },

  hasPermission: (code: string) => {
    const user = get().user;
    if (!user?.permissions) return false;
    return user.permissions.some((p) => p.code === code);
  },
}));

// Dev helper: switch role at runtime (used by RoleSwitcher)
// Supports both role codes ('owner') and seeded usernames ('designer')
// Usage: window.__switchRole('owner') or window.__switchRole('designer')
(window as any).__switchRole = (roleOrUsername: string) => {
  let roleCode = roleOrUsername;

  // Resolve seeded username → role
  for (const [role, seeded] of Object.entries(SEEDED_USERNAMES)) {
    if (seeded === roleOrUsername || role === roleOrUsername) {
      roleCode = role;
      break;
    }
  }

  const newUser = buildMockUser(roleCode);

  // Use seeded username if known
  const seededName = SEEDED_USERNAMES[roleCode];
  if (seededName) {
    newUser.username = seededName;
    newUser.full_name = `${seededName} (Seeded)`;
  }

  useMockAuth.setState({ user: newUser, isAuthenticated: true });

  // Broadcast for components that need to react (dashboard, quick actions, queries)
  window.dispatchEvent(new CustomEvent('dev-role-switched', { 
    detail: { role: roleCode, username: newUser.username } 
  }));

  console.log('[DEV] Switched to role:', roleCode, 'username:', newUser.username);
  console.log('[DEV] Permissions:', newUser.permissions.length);
};
