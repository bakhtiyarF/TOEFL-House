/**
 * Application Entry Point
 * Thin shell: routing + auth gate + providers only (per 01_TARGET_ARCHITECTURE.md §7)
 */

import { useEffect } from 'react';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { ErrorBoundary } from '@shared/components/ErrorBoundary';
import { AppRoutes } from './routes';
import { RoleSwitcher } from '@shared/components/RoleSwitcher';
import { PermissionsDebug } from '@shared/components/PermissionsDebug';

// TanStack Query client — one instance, shared globally
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

// Expose for dev role switcher + live data invalidation (very useful with seeded users)
if (typeof window !== 'undefined') {
  (window as any).__queryClient = queryClient;
}

export default function App() {
  // Auto-apply last dev role from sessionStorage (supports the 10 seeded users)
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const devRole = sessionStorage.getItem('dev-role');
      if (devRole && (window as any).__switchRole) {
        // Give the app a moment to mount
        setTimeout(() => {
          (window as any).__switchRole(devRole);
        }, 180);
      }
    }
  }, []);

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <AppRoutes />
          <RoleSwitcher />
          <PermissionsDebug />
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                direction: 'ltr',
              },
            }}
          />
        </BrowserRouter>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}
