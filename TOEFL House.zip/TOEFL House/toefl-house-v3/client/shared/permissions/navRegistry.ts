/**
 * Permission → Nav / Widget Registry
 * Fully generative per 03_DESIGN_SYSTEM §7 + 14_ROLE_WORKSPACE_SPECIFICATIONS.md
 *
 * This is the single source of truth for what nav + dashboard content
 * a user sees based on their resolved permissions (02 §5).
 */

export interface NavRegistryItem {
  permission: string;
  nav?: {
    label: string;
    icon: string;
    href: string;
    group?: string;
  };
  widgets?: string[];
  quickActions?: Array<{ label: string; action: string; icon?: string }>;
}

export const NAV_REGISTRY: NavRegistryItem[] = [
  // === CORE / SHARED ===
  { permission: 'Dashboard.View', nav: { label: 'Dashboard', icon: 'LayoutDashboard', href: '/', group: 'core' }, widgets: ['stats', 'recentActivity'] },

  // === ACADEMIC (used by many roles) ===
  { permission: 'Student.View', nav: { label: 'Students', icon: 'GraduationCap', href: '/academic/students', group: 'academic' }, widgets: ['studentsOverview'] },
  { permission: 'Class.View', nav: { label: 'Classes', icon: 'ClipboardList', href: '/academic/classes', group: 'academic' }, widgets: ['classesOverview', 'attendanceRate', 'pendingPromotions'] },
  { permission: 'Session.View', nav: { label: 'Sessions', icon: 'Calendar', href: '/academic/classes', group: 'academic' } },
  { permission: 'Attendance.View', widgets: ['attendanceSummary'] },
  { permission: 'Exam.View', widgets: ['upcomingExams'] },
  { permission: 'Grade.View', widgets: ['gradesOverview'] },
  { permission: 'Promotion.Approve', widgets: ['pendingPromotions'], quickActions: [{ label: 'Approve Promotion', action: 'approvePromotion' }] },

  // === PEOPLE & HR (06 fully live — Teachers + Evaluations + Salary History) ===
  { permission: 'Teacher.View', nav: { label: 'Teachers', icon: 'Users', href: '/people-hr/teachers', group: 'hr' }, widgets: ['teachersOverview', 'performanceScores'], quickActions: [{ label: 'Add Teacher Evaluation', action: 'addTeacherEvaluation' }] },
  { permission: 'Employee.View', nav: { label: 'Employees', icon: 'Users', href: '/people-hr/employees', group: 'hr' } },

  // === CRM & ENROLLMENT ===
  { permission: 'Lead.View', nav: { label: 'Visitors & Leads', icon: 'UserPlus', href: '/crm/visitors', group: 'crm' }, widgets: ['leadsPipeline', 'followUpsDue'], quickActions: [
    { label: 'Add Visitor / Lead', action: 'addVisitor' },
    { label: 'Log Follow-up', action: 'logFollowup' },
  ] },

  // === FINANCE & PAYROLL ===
  { permission: 'Payment.View', nav: { label: 'Finance', icon: 'DollarSign', href: '/finance', group: 'finance' }, widgets: ['todayRevenue', 'pendingPayments', 'payrollDue'] },
  { permission: 'Budget.Allocate', widgets: ['budgetUtilization'], quickActions: [{ label: 'Allocate Budget', action: 'allocateBudget' }] },

  // === INVENTORY ===
  { permission: 'Book.View', nav: { label: 'Inventory', icon: 'Package', href: '/inventory', group: 'inventory' } },

  // === FUNDING & IMPACT ===
  { permission: 'Funding.View', nav: { label: 'Funding & Impact', icon: 'Heart', href: '/funding', group: 'funding' }, widgets: ['campaignProgress', 'recentDonations', 'impactMetrics'], quickActions: [
    { label: 'Record Donation', action: 'recordDonation' },
    { label: 'Award Scholarship', action: 'awardScholarship' },
    { label: 'View Impact', action: 'viewImpact' },
    { label: 'Export Impact Report', action: 'exportImpactReport' },
    { label: 'View Donors', action: 'viewDonors' },
    { label: 'New Campaign', action: 'newCampaign' },
    { label: 'Donor Ledger', action: 'viewDonorLedger' },
  ] },

  // === PLATFORM / SECURITY (mostly owner) ===
  { permission: 'Settings.View', nav: { label: 'Settings', icon: 'Settings', href: '/settings', group: 'platform' } },
  { permission: 'Audit.View', nav: { label: 'Audit Logs', icon: 'FileText', href: '/settings/audit', group: 'security' } },
  { permission: 'User.View', nav: { label: 'Users & Roles', icon: 'Shield', href: '/settings/users', group: 'security' } },

  // Extra for head_of_department / designer (narrow but real)
  { permission: 'Certificate.Issue', nav: { label: 'Certificates', icon: 'Award', href: '/academic/certificates', group: 'academic' }, widgets: ['certificateQueue'], quickActions: [
    { label: 'Issue Certificate', action: 'issueCertificate' },
  ] },
];

// === Generative helpers ===
export function getNavForPermissions(userPermissions: string[]) {
  const seen = new Set<string>();
  return NAV_REGISTRY
    .filter(item => item.nav && userPermissions.includes(item.permission))
    .map(item => {
      if (seen.has(item.nav!.href)) return null;
      seen.add(item.nav!.href);
      return item.nav;
    })
    .filter(Boolean) as any[];
}

export function getDashboardConfigForPermissions(userPermissions: string[]) {
  const widgets = new Set<string>();
  const quickActions: any[] = [];

  NAV_REGISTRY.forEach(item => {
    if (userPermissions.includes(item.permission)) {
      (item.widgets || []).forEach(w => widgets.add(w));
      (item.quickActions || []).forEach(qa => quickActions.push(qa));
    }
  });

  return { widgets: Array.from(widgets), quickActions };
}

// Owner exclusions (14 §4.1) — these must be absent even for owner
export const OWNER_EXCLUDED = ['Attendance.Edit', 'Grade.Edit', 'Student.Delete', 'Payment.Delete'];

// 06 People-HR specific (for validator + generative)
export const HR_PERMISSIONS = ['Teacher.View', 'Employee.View'];

// Role expectations for 06 (used by validators)
export const HR_ROLES = ['owner', 'general_manager', 'head_of_department', 'finance_manager'];

// 06-specific expectations (for full validation sweep)
export const EXPECTED_HR = {
  teacherNav: ['Teachers', 'Employees'],
  evaluationAction: 'addTeacherEvaluation',
  salaryHistoryVisibleFor: ['owner', 'finance_manager', 'hod'],
  hasTeachersNav: (role: string) => ['owner', 'general_manager', 'head_of_department', 'finance_manager', 'teacher'].includes(role),
};

export function isOwnerExcluded(perm: string, isOwnerRole: boolean) {
  return isOwnerRole && OWNER_EXCLUDED.includes(perm);
}
