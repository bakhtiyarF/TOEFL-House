/**
 * CurrentRoleSummary
 * Small live card showing what the 14_ROLE spec says the current role should see.
 * Helps with instant validation (14 §7).
 * Fully generative.
 */
import { usePermissions } from '@modules/iam/hooks/usePermissions';
import { useAuth } from '@modules/iam/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@shared/components/ui/card';
import { Badge } from '@shared/components/ui/badge';
import { getDashboardConfigForPermissions } from '@shared/permissions/navRegistry';

const ROLE_EXPECTATIONS: Record<string, string> = {
  owner: 'Full access (excl. 4 ops actions)',
  general_manager: 'Branch ops + Budget',
  head_of_department: 'Academic + Promotion',
  finance_manager: 'Finance + Ledger',
  receptionist: 'Front desk + Leads',
  counselor: 'CRM follow-ups',
  teacher: 'Own classes only',
  data_entry: 'Entry (no finance/delete)',
  designer: 'Certificates + Print',
  donor_manager: 'Funding + Impact + Exports',
};

export function CurrentRoleSummary() {
  const { user } = useAuth();
  const { dashboardWidgets, dashboardQuickActions, isOwner } = usePermissions();

  if (import.meta.env.PROD) return null;

  const role = (user as any)?.role || (user as any)?.username || 'unknown';
  const expected = ROLE_EXPECTATIONS[role] || 'Generative (see 14 spec)';

  const { widgets, quickActions } = getDashboardConfigForPermissions(
    (user as any)?.permissions?.map((p: any) => p.code) || []
  );

  return (
    <Card className="border-dashed border-blue-200 bg-blue-50/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          14_ROLE Live Summary
          <Badge variant="outline" className="text-[9px]">{role}</Badge>
          {isOwner && <Badge variant="destructive" className="text-[9px]">OWNER (exclusions on)</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-xs space-y-1">
        <div><strong>Spec expectation:</strong> {expected}</div>
        <div>Live widgets visible: <span className="font-mono">{dashboardWidgets.length}</span> (registry: {widgets.length})</div>
        <div>Live quick actions: <span className="font-mono">{dashboardQuickActions.length}</span></div>
        <div className="text-[10px] text-muted-foreground pt-1">
          Matches 14_ROLE_WORKSPACE_SPECIFICATIONS.md §4. Use RoleSwitcher + Validator for full check.
        </div>
      </CardContent>
    </Card>
  );
}
