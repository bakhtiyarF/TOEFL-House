/**
 * Permissions Debug Panel (dev only)
 * Shows the current resolved permissions + scope (live or mock).
 * Helps verify 02_BUSINESS_LOGIC + 14_ROLE_WORKSPACE_SPECIFICATIONS generative behavior.
 */
import { useAuth } from '@modules/iam/hooks/useAuth';
import { usePermissions } from '@modules/iam/hooks/usePermissions';
import { Badge } from '@shared/components/ui/badge';

export function PermissionsDebug() {
  const { user, isAuthenticated } = useAuth();
  const { userPermissions, isOwner, canEditAttendance, canEditGrade, canDeleteStudent, canDeletePayment } = usePermissions();

  if (import.meta.env.PROD || !isAuthenticated) return null;

  // Show scopes if available on the permission objects (from real PermissionResolutionService)
  const permList = (user as any)?.permissions || userPermissions;

  return (
    <div className="fixed bottom-20 end-4 z-[90] max-w-xs bg-card border rounded-xl shadow p-3 text-[10px] font-mono">
      <div className="flex items-center justify-between mb-1">
        <span className="font-semibold text-primary">PERMISSIONS (dev)</span>
        <Badge variant="outline" className="text-[9px]">{user?.role}</Badge>
      </div>
      <div className="max-h-28 overflow-auto space-y-0.5 text-muted-foreground">
        {Array.isArray(permList) && permList.length > 0 ? (
          permList.slice(0, 10).map((p: any, i: number) => {
            const code = typeof p === 'string' ? p : p.code;
            const scope = typeof p === 'object' ? p.scope : '';
            return <div key={i} className="truncate">• {code} {scope ? `(${scope})` : ''}</div>;
          })
        ) : (
          <div>no permissions resolved</div>
        )}
        {permList?.length > 10 && <div className="text-[9px]">+{permList.length - 10} more…</div>}
      </div>
      <div className="mt-1.5 pt-1 border-t text-[9px] flex flex-wrap gap-x-3 gap-y-0.5">
        {isOwner && <span className="text-amber-600">OWNER — exclusions active</span>}
        {!canEditAttendance && <span className="text-red-500">no Attendance.Edit</span>}
        {!canEditGrade && <span className="text-red-500">no Grade.Edit</span>}
        {!canDeleteStudent && <span className="text-red-500">no Student.Delete</span>}
        {!canDeletePayment && <span className="text-red-500">no Payment.Delete</span>}
      </div>
      <div className="text-[8px] text-muted-foreground mt-1">Generative from 14 + 02 specs</div>
    </div>
  );
}
