/**
 * Dev-only Role Switcher (14_ROLE_WORKSPACE_SPECIFICATIONS + live seeded users)
 * Supports the 10 exact seeded usernames from EnhancedSampleDataSeeder + IamSeeder.
 * Instantly regenerates nav, dashboard widgets, and quick actions.
 */
import { useAuth } from '@modules/iam/hooks/useAuth';
import { Badge } from '@shared/components/ui/badge';
import { toast } from 'sonner';

const ROLES = [
  { code: 'owner', label: 'Owner' },
  { code: 'general_manager', label: 'General Manager' },
  { code: 'head_of_department', label: 'Head of Dept' },
  { code: 'finance_manager', label: 'Finance Mgr' },
  { code: 'receptionist', label: 'Receptionist' },
  { code: 'counselor', label: 'Counselor' },
  { code: 'teacher', label: 'Teacher' },
  { code: 'data_entry', label: 'Data Entry' },
  { code: 'designer', label: 'Designer' },
  { code: 'donor_manager', label: 'Donor Manager' },
] as const;

const SEEDED_USERNAMES: Record<string, string> = {
  owner: 'owner',
  general_manager: 'general_mgr',
  head_of_department: 'hod',
  finance_manager: 'finance_mgr',
  receptionist: 'reception',
  counselor: 'counselor',
  teacher: 'teacher1',
  data_entry: 'data_entry',
  designer: 'designer',
  donor_manager: 'donor_mgr',
};

export function RoleSwitcher() {
  const { user, login } = useAuth();

  const switchRole = async (roleCode: string) => {
    const win = window as any;
    const seededUsername = SEEDED_USERNAMES[roleCode] || roleCode;

    // 1. Best path: global helper (instant + broadcast for all generative components)
    if (typeof win.__switchRole === 'function') {
      win.__switchRole(roleCode);
      window.dispatchEvent(new CustomEvent('dev-role-switched', { detail: { role: roleCode, username: seededUsername } }));
      toast.success(`Switched to ${roleCode} (${seededUsername})`, { duration: 1600 });
      return;
    }

    // 2. Real login with the exact seeded user created by EnhancedSampleDataSeeder
    try {
      const success = await login(seededUsername, 'password');
      if (success) {
        console.log(`[RoleSwitcher] Logged in as seeded ${seededUsername} (${roleCode})`);
        window.dispatchEvent(new CustomEvent('dev-role-switched', { detail: { role: roleCode } }));
        toast.success(`Logged in as ${seededUsername}`);
        return;
      }
    } catch (_) {}

    // 3. Pure mock fallback (still fully generative)
    console.info(`[RoleSwitcher] Mock switch → ${roleCode}`);
    sessionStorage.setItem('dev-role', roleCode);
    sessionStorage.setItem('dev-username', seededUsername);
    (window as any).__switchRole?.(roleCode);
    window.dispatchEvent(new CustomEvent('dev-role-switched', { detail: { role: roleCode } }));
    toast.info(`Dev role: ${roleCode}`);
  };

  if (import.meta.env.PROD) return null;

  const currentDisplay = user?.username || user?.role || '—';
  const isSeeded = Object.values(SEEDED_USERNAMES).includes(currentDisplay);

  return (
    <div className="fixed bottom-4 end-4 z-[100] bg-background/95 border rounded-lg shadow-lg p-2 text-xs flex flex-col gap-1 max-w-[280px]">
      <div className="flex items-center justify-between px-1">
        <span className="font-mono text-[10px] text-muted-foreground">DEV — 10 ROLES + SEED</span>
        <Badge variant="outline" className="text-[9px]">
          {currentDisplay} {isSeeded ? '✓ seeded' : ''}
        </Badge>
      </div>

      <div className="flex flex-wrap gap-1">
        {ROLES.map(({ code, label }) => (
          <button
            key={code}
            onClick={() => switchRole(code)}
            className={`px-1.5 py-px text-[9px] rounded border transition-all ${
              (user?.role === code || user?.username === SEEDED_USERNAMES[code])
                ? 'bg-primary text-primary-foreground border-primary'
                : 'hover:bg-muted'
            }`}
            title={`Switch to ${label} (seeded user: ${SEEDED_USERNAMES[code]}, password=password)`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="text-[8px] text-muted-foreground px-1 leading-tight">
        Generative sidebar + Dashboard + QuickActions (14_ROLE) • After switch: data refetches live
      </div>

      <a 
        href="/dev/validate-roles" 
        className="text-[8px] text-blue-600 hover:underline px-1 block mt-0.5"
        title="Open dedicated 14_ROLE exhaustive validator page"
      >
        → Open /dev/validate-roles (full 10-role checklist)
      </a>
    </div>
  );
}
