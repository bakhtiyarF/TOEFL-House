/**
 * LivePermissionsPanel
 * Shows resolved permissions coming from the backend PermissionResolutionService (02 §5.4)
 * Used to verify generative nav + 14_ROLE specs.
 */
import { useQuery } from '@tanstack/react-query';
import { authApi } from '@modules/iam/api';

export function LivePermissionsPanel() {
  const { data, isLoading } = useQuery({
    queryKey: ['live-permissions'],
    queryFn: () => authApi.me(),
    staleTime: 30_000,
  });

  if (isLoading) return <div className="text-xs text-muted-foreground">Loading permissions…</div>;

  const perms = (data as any)?.permissions || [];

  return (
    <div className="text-xs">
      <div className="font-medium mb-1">Live Resolved Permissions ({perms.length})</div>
      <div className="grid grid-cols-1 gap-1 max-h-40 overflow-auto">
        {perms.slice(0, 20).map((p: any, i: number) => (
          <div key={i} className="flex justify-between border-b border-muted/40 pb-0.5">
            <code className="text-[10px]">{p.code}</code>
            <span className="text-[10px] text-muted-foreground">{p.scope}</span>
          </div>
        ))}
        {perms.length > 20 && <div className="text-[10px] text-muted-foreground">… +{perms.length - 20} more</div>}
      </div>
      <div className="text-[9px] text-muted-foreground mt-1">Source: PermissionResolutionService (02 §5.4)</div>
    </div>
  );
}
