/**
 * ValidationReportButton
 * Generates a copyable structured report of the current role's generative state.
 * Helps document 14_ROLE validation results.
 * DEV ONLY.
 */
import { usePermissions } from '@modules/iam/hooks/usePermissions';
import { useAuth } from '@modules/iam/hooks/useAuth';
import { Button } from '@shared/components/ui/button';
import { toast } from 'sonner';
import { getNavForPermissions, getDashboardConfigForPermissions } from '@shared/permissions/navRegistry';

export function ValidationReportButton() {
  const { user } = useAuth();
  const { dashboardWidgets, dashboardQuickActions, isOwner, navItems } = usePermissions();

  if (import.meta.env.PROD) return null;

  const generateReport = () => {
    const role = (user as any)?.role || (user as any)?.username || 'unknown';
    const perms = (user as any)?.permissions?.map((p: any) => p.code) || [];

    const nav = getNavForPermissions(perms);
    const { widgets, quickActions } = getDashboardConfigForPermissions(perms);

    const report = {
      timestamp: new Date().toISOString(),
      role,
      isOwner,
      navItems: nav.map((n: any) => n.label),
      navCount: nav.length,
      dashboardWidgets: dashboardWidgets,
      dashboardQuickActions: dashboardQuickActions.map((qa: any) => qa.action || qa.label),
      registryWidgets: widgets,
      registryQuickActions: quickActions.map((qa: any) => qa.action || qa.label),
      ownerExclusionsActive: isOwner,
      notes: 'Generated from live generative system (14_ROLE)',
    };

    const text = `TOEFL House v3 — 14_ROLE Validation Report\n` +
      `Role: ${role}\n` +
      `Date: ${report.timestamp}\n\n` +
      `Nav items (${report.navCount}): ${report.navItems.join(', ')}\n\n` +
      `Dashboard widgets: ${report.dashboardWidgets.join(', ')}\n\n` +
      `Quick actions: ${report.dashboardQuickActions.join(', ')}\n\n` +
      `Owner exclusions active: ${report.ownerExclusionsActive}\n\n` +
      JSON.stringify(report, null, 2);

    navigator.clipboard?.writeText(text).then(() => {
      toast.success('14_ROLE validation report copied to clipboard');
    });
  };

  return (
    <Button 
      variant="outline" 
      size="sm" 
      onClick={generateReport}
      className="text-xs"
    >
      Copy Current Role Validation Report
    </Button>
  );
}
