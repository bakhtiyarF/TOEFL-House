/**
 * GenerativeQuickActions
 * Built from the NAV_REGISTRY (14_ROLE_WORKSPACE_SPECIFICATIONS + 03 §7)
 * + live permissions from useAuth / usePermissions.
 * Every widget "ends in an action".
 */
import { useState, useEffect } from 'react';
import { usePermissions } from '@modules/iam/hooks/usePermissions';
import { useAuth } from '@modules/iam/hooks/useAuth';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@shared/components/ui/button';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@shared/components/ui/dialog';
import { Input } from '@shared/components/ui/input';
import { Label } from '@shared/components/ui/label';
import { useCreatePayment, useCreateBudgetLine } from '@modules/finance-payroll/hooks/useFinance';
import { useCreateDonation, useAwardScholarship, useImpactMetrics, useCreateCampaign, useCampaigns } from '@modules/funding-impact/hooks/useFunding';
import { useStudents, useIssueCertificate, useCertificates, useCreateStudent } from '@modules/academic/hooks/useAcademic';
import { usePrintCertificate } from '@modules/academic/hooks/useAcademic';
import { useCreateVisitor, useCreateFollowup, useVisitors } from '@modules/crm-enrollment/hooks/useCrm';
import { useDonations, useDonors } from '@modules/funding-impact/hooks/useFunding';
import { toast } from 'sonner';
import {
  ClipboardList, DollarSign, UserPlus, Users, Award, Heart, TrendingUp, Download,
} from 'lucide-react';

const ACTION_ICONS: Record<string, React.ElementType> = {
  markAttendance: ClipboardList,
  recordPayment: DollarSign,
  registerStudent: UserPlus,
  logFollowup: Users,
  approvePromotion: Award,
  awardScholarship: Heart,
  allocateBudget: DollarSign,
  recordDonation: Heart,
  viewImpact: TrendingUp,
  exportImpactReport: TrendingUp,
  exportDonorLedger: Download,
  printRecentCertificate: Award,
  viewDonorLedger: Users,
};

export function GenerativeQuickActions() {
  const { user } = useAuth();
  const { dashboardQuickActions, hasPermission, isOwner } = usePermissions();
  const qc = useQueryClient();

  // React instantly to dev role switches (seeded users)
  useEffect(() => {
    const handler = () => {
      // Force refetch of all live data used by quick actions
      qc.invalidateQueries({ queryKey: ['academic'] });
      qc.invalidateQueries({ queryKey: ['funding'] });
      qc.invalidateQueries({ queryKey: ['crm'] });
      qc.invalidateQueries({ queryKey: ['finance'] });
    };
    window.addEventListener('dev-role-switched', handler);
    return () => window.removeEventListener('dev-role-switched', handler);
  }, [qc]);

  // Live mutation hooks for quick actions (per 14_ROLE + real backend)
  const createPayment = useCreatePayment();
  const createDonation = useCreateDonation();
  const createBudgetLine = useCreateBudgetLine();
  const awardScholarship = useAwardScholarship();
  const issueCertificate = useIssueCertificate();
  const createVisitor = useCreateVisitor();
  const createFollowup = useCreateFollowup();
  const createStudent = useCreateStudent();
  const createCampaign = useCreateCampaign();
  const printCert = usePrintCertificate();
  const { data: students = [] } = useStudents({ status: 'active' });
  const { data: existingCerts = [] } = useCertificates();
  const { data: impactMetrics = [] } = useImpactMetrics();
  const { data: liveDonors = [] } = useDonors ? useDonors() : { data: [] } as any;
  const { data: liveDonations = [] } = useDonations ? useDonations() : { data: [] } as any;
  const { data: liveCampaigns = [] } = useCampaigns ? useCampaigns() : { data: [] } as any;
  const { data: liveCerts = [] } = useCertificates ? useCertificates() : { data: [] } as any;

  // Lightweight dialog state for generative quick actions (production dialogs — no prompts)
  const [showVisitorDialog, setShowVisitorDialog] = useState(false);
  const [visitorName, setVisitorName] = useState('');
  const [visitorPhone, setVisitorPhone] = useState('');
  const [showCampaignDialog, setShowCampaignDialog] = useState(false);
  const [campaignName, setCampaignName] = useState('');
  const [campaignTarget, setCampaignTarget] = useState('500000');
  const [showFollowupDialog, setShowFollowupDialog] = useState(false);
  const [followupVisitorName, setFollowupVisitorName] = useState('');
  const [followupNote, setFollowupNote] = useState('');
  const [followupNextDate, setFollowupNextDate] = useState('');

  // Additional quick action dialogs (payment + certificate with template)
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [paymentStudentId, setPaymentStudentId] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('15000');
  const [paymentMethod, setPaymentMethod] = useState('cash');

  const [showCertDialog, setShowCertDialog] = useState(false);
  const [certStudentId, setCertStudentId] = useState('');
  const [certNo, setCertNo] = useState('');
  const [certGrade, setCertGrade] = useState('Pass');
  const [certTemplate, setCertTemplate] = useState<'classic' | 'modern' | 'minimal'>('classic');

  // Budget + Scholarship quick dialogs (live)
  const [showBudgetDialog, setShowBudgetDialog] = useState(false);
  const [budgetName, setBudgetName] = useState('Quick Operations Allocation');
  const [budgetAmount, setBudgetAmount] = useState('50000');
  const [budgetPurpose, setBudgetPurpose] = useState('operations');

  const [showScholarshipDialog, setShowScholarshipDialog] = useState(false);
  const [scholarshipStudentId, setScholarshipStudentId] = useState('');
  const [scholarshipAmount, setScholarshipAmount] = useState('12000');
  const [scholarshipSemester, setScholarshipSemester] = useState('Fall 2026');

  // Record Donation dialog (live donors + campaigns)
  const [showDonationDialog, setShowDonationDialog] = useState(false);
  const [donationDonorId, setDonationDonorId] = useState('');
  const [donationAmount, setDonationAmount] = useState('25000');
  const [donationDate, setDonationDate] = useState(new Date().toISOString().split('T')[0]);
  const [donationCampaignId, setDonationCampaignId] = useState('');

  // Register Student dialog (live)
  const [showRegisterDialog, setShowRegisterDialog] = useState(false);
  const [regFullName, setRegFullName] = useState('');
  const [regPhone, setRegPhone] = useState('+93 700 000 000');

  if (!user) return null;

  // Map registry actions to concrete routes + labels
  const actionMap: Record<string, { href: string; label: string }> = {
    markAttendance: { href: '/academic/classes', label: 'Mark Attendance' },
    recordPayment: { href: '/finance', label: 'Record Payment' },
    registerStudent: { href: '/academic/students', label: 'Register Student' },
    logFollowup: { href: '/crm/visitors', label: 'Log Follow-up' },
    approvePromotion: { href: '/academic/classes', label: 'Approve Promotion' },
    awardScholarship: { href: '/funding', label: 'Award Scholarship' },
    allocateBudget: { href: '/finance', label: 'Allocate Budget' },
    recordDonation: { href: '/funding', label: 'Record Donation' },
    viewImpact: { href: '/funding', label: 'View Impact' },
    viewDonors: { href: '/funding', label: 'View Donors' },
    newCampaign: { href: '/funding', label: 'New Campaign' },
    issueCertificate: { href: '/academic/certificates', label: 'Issue Certificate' },
    addVisitor: { href: '/crm/visitors', label: 'Add Visitor / Lead' },
    viewDonorLedger: { href: '/funding', label: 'Donor Ledger' },
    exportImpactReport: { href: '/funding', label: 'Export Impact Report' },
    exportDonorLedger: { href: '/funding', label: 'Export Donor Ledger' },
    printRecentCertificate: { href: '/academic/certificates', label: 'Print Recent Certificate' },
  };

  // Special: For approvePromotion we can pass state hint via hash (ClassesPage promotion tab)
  const getHrefForAction = (action: string) => {
    const base = actionMap[action];
    if (!base) return '#';
    if (action === 'approvePromotion') {
      return '/academic/classes#promotion';
    }
    return base.href;
  };

  const baseVisible = dashboardQuickActions
    .map((qa: any) => {
      const mapped = actionMap[qa.action];
      if (!mapped) return null;
      // Respect owner exclusions
      if (isOwner && (qa.action.includes('Attendance') || qa.action.includes('Grade') || qa.action.includes('Delete'))) {
        return null;
      }
      return { ...qa, ...mapped };
    })
    .filter(Boolean);

  // Always inject a few extra generative quick actions for owner / general_manager / finance / donor (per 14_ROLE + navRegistry)
  const extraActions: any[] = [];
  if ((dashboardQuickActions.some((qa: any) => qa.action === 'recordPayment') || hasPermission('Payment.Create')) && !baseVisible.find((a: any) => a.action === 'recordPayment')) {
    extraActions.push({ action: 'recordPayment', label: 'Record Payment', icon: 'DollarSign' });
  }
  if ((dashboardQuickActions.some((qa: any) => qa.action === 'recordDonation') || hasPermission('Funding.View')) && !baseVisible.find((a: any) => a.action === 'recordDonation')) {
    extraActions.push({ action: 'recordDonation', label: 'Record Donation', icon: 'Heart' });
  }
  if ((dashboardQuickActions.some((qa: any) => qa.action === 'allocateBudget') || hasPermission('Budget.Allocate')) && !baseVisible.find((a: any) => a.action === 'allocateBudget')) {
    extraActions.push({ action: 'allocateBudget', label: 'Allocate Budget', icon: 'DollarSign' });
  }
  if ((dashboardQuickActions.some((qa: any) => qa.action === 'awardScholarship') || hasPermission('Funding.View')) && !baseVisible.find((a: any) => a.action === 'awardScholarship')) {
    extraActions.push({ action: 'awardScholarship', label: 'Award Scholarship', icon: 'Award' });
  }
  if ((dashboardQuickActions.some((qa: any) => qa.action === 'issueCertificate') || hasPermission('Certificate.Issue')) && !baseVisible.find((a: any) => a.action === 'issueCertificate')) {
    extraActions.push({ action: 'issueCertificate', label: 'Issue Certificate', icon: 'Award' });
  }
  if ((dashboardQuickActions.some((qa: any) => qa.action === 'logFollowup') || hasPermission('Lead.Create')) && !baseVisible.find((a: any) => a.action === 'logFollowup')) {
    extraActions.push({ action: 'logFollowup', label: 'Log Follow-up / Add Visitor', icon: 'UserPlus' });
  }

  // Donor manager / Funding extras (per 14_ROLE_WORKSPACE_SPECIFICATIONS)
  if ((hasPermission('Funding.View') || hasPermission('Impact.View')) && !baseVisible.find((a: any) => a.action === 'exportImpactReport')) {
    extraActions.push({ action: 'exportImpactReport', label: 'Export Impact Report', icon: 'TrendingUp' });
  }
  if ((hasPermission('Funding.View') || hasPermission('Impact.View')) && !baseVisible.find((a: any) => a.action === 'exportDonorLedger')) {
    extraActions.push({ action: 'exportDonorLedger', label: 'Export Donor Ledger', icon: 'Download' });
  }

  // Designer / Certificate extras
  if (hasPermission('Certificate.Issue') && !baseVisible.find((a: any) => a.action === 'printRecentCertificate')) {
    extraActions.push({ action: 'printRecentCertificate', label: 'Print Recent Certificate', icon: 'Award' });
  }

  // 06 People-HR: Add Teacher Evaluation quick action (fully live after 06 completion)
  if ((hasPermission('Teacher.View') || hasPermission('Teacher.Edit')) && !baseVisible.find((a: any) => a.action === 'addTeacherEvaluation')) {
    extraActions.push({ action: 'addTeacherEvaluation', label: 'Add Teacher Evaluation', icon: 'Star' });
  }

  const visibleActions = [...baseVisible, ...extraActions];

  // Live action handlers (per 14_ROLE + real backend mutations)
  // Dialog-based flows replace prompts for better UX (production quality)
  const handleQuickAction = (action: string) => {
    if (action === 'recordDonation') {
      // Open production dialog with live donors
      const firstDonor = (liveDonors && liveDonors.length > 0) ? liveDonors[0] : null;
      setDonationDonorId(firstDonor?.id || (liveDonors[0]?.id || ''));
      setDonationAmount('25000');
      setDonationDate(new Date().toISOString().split('T')[0]);
      setShowDonationDialog(true);
      return;
    }

    if (action === 'recordPayment') {
      // Open production dialog with live students
      if (!students.length) {
        toast.error('No students available for payment');
        return;
      }
      const first = students[0];
      setPaymentStudentId(first.id);
      setPaymentAmount('15000');
      setPaymentMethod('cash');
      setShowPaymentDialog(true);
      return;
    }

    if (action === 'registerStudent') {
      // Open production dialog (per 14_ROLE)
      setRegFullName('');
      setRegPhone('+93 700 000 000');
      setShowRegisterDialog(true);
      return;
    }

    if (action === 'approvePromotion') {
      // Navigates to Classes with hash; actual promotion handled in ClassesPage
      window.location.hash = 'promotion';
    }

    if (action === 'allocateBudget') {
      // Open production dialog
      setBudgetName('Quick Operations Allocation');
      setBudgetAmount('50000');
      setBudgetPurpose('operations');
      setShowBudgetDialog(true);
      return;
    }

    if (action === 'awardScholarship') {
      if (!students.length) {
        toast.error('No active students for scholarship');
        return;
      }
      const first = students[0];
      setScholarshipStudentId(first.id);
      setScholarshipAmount('12000');
      setScholarshipSemester('Fall 2026');
      setShowScholarshipDialog(true);
      return;
    }

    if (action === 'issueCertificate') {
      if (!students.length) {
        toast.error('No active students for certificate issuance');
        return;
      }
      const first = students[0];
      setCertStudentId(first.id);
      setCertNo(`CERT-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`);
      setCertGrade('Pass');
      setCertTemplate('classic');
      setShowCertDialog(true);
      return;
    }

    if (action === 'viewImpact') {
      // Live CSV export of impact metrics (donor_manager feature per 14_ROLE)
      const data = impactMetrics && impactMetrics.length ? impactMetrics : [];
      if (!data.length) {
        toast.info('No impact metrics available for export');
        return;
      }
      const csv = 'name,current_value,target_value,progress_percent\n' +
        data.map((m: any) => `${m.name},${m.current_value || 0},${m.target_value || 0},${m.progress_percent || 0}`).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `impact_report_${new Date().toISOString().slice(0,10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Impact metrics exported as CSV');
      return;
    }

    if (action === 'exportImpactReport') {
      // Rich live printable impact report (donor_manager) — opens window + downloadable HTML (print → PDF)
      const data = (impactMetrics && impactMetrics.length ? impactMetrics : liveDonations) as any[];
      const totalRaised = (liveDonations || []).reduce((s: number, d: any) => s + (d.amount || 0), 0);
      const html = `
        <html><head><title>Impact Report ${new Date().toISOString().slice(0,10)}</title>
        <style>body{font-family:system-ui;padding:40px;background:#f8fafc} .report{max-width:900px;margin:auto;background:white;padding:40px;border:1px solid #e2e8f0} h1{color:#0f172a} table{width:100%;border-collapse:collapse;margin:20px 0} th,td{border:1px solid #cbd5e1;padding:8px;text-align:left} th{background:#f1f5f9}</style>
        </head><body>
        <div class="report">
          <h1>TOEFL House — Donor Impact Report</h1>
          <p>Generated: ${new Date().toLocaleString()} (live data)</p>
          <h2>Summary</h2>
          <p>Total Donations Recorded: <strong>${(liveDonations||[]).length}</strong> — Raised: <strong>${totalRaised} AFN</strong></p>
          <h2>Impact Metrics</h2>
          <table><thead><tr><th>Metric</th><th>Current</th><th>Target</th><th>Progress</th></tr></thead>
          <tbody>
            ${(data||[]).map((m:any)=>`<tr><td>${m.name||m.metric}</td><td>${m.current_value||m.value||0}</td><td>${m.target_value||0}</td><td>${m.progress_percent||0}%</td></tr>`).join('')}
          </tbody></table>
          <p style="font-size:11px;color:#64748b">Live from backend • Use Print → Save as PDF</p>
        </div>
        <script>window.print()</script>
        </body></html>`;
      const w = window.open('', '_blank');
      if (w) { w.document.write(html); w.document.close(); }
      // Also download as .html for offline/print-to-PDF
      const blob = new Blob([html], {type:'text/html'});
      const url = URL.createObjectURL(blob);
      const dl = document.createElement('a'); dl.href=url; dl.download=`impact_report_${new Date().toISOString().slice(0,10)}.html`; document.body.appendChild(dl); dl.click(); document.body.removeChild(dl); URL.revokeObjectURL(url);
      toast.success('Full impact report opened (print-to-PDF ready) + HTML downloaded');
      return;
    }

    if (action === 'markAttendance') {
      window.location.href = '/academic/classes#attendance';
      toast.info('Open a class → Attendance tab to mark live');
      return;
    }

    if (action === 'logFollowup') {
      // Open production dialog (per 14_ROLE for counselor/receptionist + live follow-up)
      setFollowupVisitorName('');
      setFollowupNote('Quick follow-up from dashboard');
      setFollowupNextDate(new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10));
      setShowFollowupDialog(true);
      return;
    }

    if (action === 'viewDonors') {
      window.location.href = '/funding';
      toast.info('View full donor ledger in Funding & Impact');
      return;
    }

    if (action === 'newCampaign') {
      // Open production dialog (per 14_ROLE)
      setCampaignName('Quick Campaign ' + new Date().getFullYear());
      setCampaignTarget('500000');
      setShowCampaignDialog(true);
      return;
    }

    if (action === 'addVisitor') {
      // Open production dialog (per 14_ROLE)
      setVisitorName('');
      setVisitorPhone('+93 700 000 000');
      setShowVisitorDialog(true);
      return;
    }

    if (action === 'viewDonorLedger') {
      window.location.href = '/funding';
      toast.info('Opened Funding & Impact → Donations tab (full Donor Ledger)');
      return;
    }

    if (action === 'exportDonorLedger') {
      // Live donor ledger export (CSV + JSON) — donor_manager per 14_ROLE
      const dons = (liveDonations as any[]) || [];
      if (!dons.length) {
        toast.info('No donations for ledger export yet');
        return;
      }
      // CSV
      const csvHeader = 'date,donor,amount,receipt,campaign\n';
      const csvRows = dons.map((d: any) => `${d.date||''},${d.donor_id||''},${d.amount||0},${d.receipt_no||''},${d.campaign_id||''}`).join('\n');
      const csvBlob = new Blob([csvHeader + csvRows], { type: 'text/csv' });
      const csvUrl = URL.createObjectURL(csvBlob);
      const csvA = document.createElement('a'); csvA.href = csvUrl; csvA.download = `donor_ledger_${new Date().toISOString().slice(0,10)}.csv`; document.body.appendChild(csvA); csvA.click(); document.body.removeChild(csvA); URL.revokeObjectURL(csvUrl);

      // JSON
      const jsonBlob = new Blob([JSON.stringify({ exported: new Date().toISOString(), count: dons.length, donations: dons }, null, 2)], { type: 'application/json' });
      const jsonUrl = URL.createObjectURL(jsonBlob);
      const jsonA = document.createElement('a'); jsonA.href = jsonUrl; jsonA.download = `donor_ledger_${new Date().toISOString().slice(0,10)}.json`; document.body.appendChild(jsonA); jsonA.click(); document.body.removeChild(jsonA); URL.revokeObjectURL(jsonUrl);

      toast.success('Donor Ledger exported (CSV + JSON) — live data');
      return;
    }

    if (action === 'printRecentCertificate') {
      // Designer quick action: print / download most recent live certificate with current template
      const recent = (liveCerts as any[]).slice().sort((a:any,b:any) => (b.issue_date||'').localeCompare(a.issue_date||'')).find((c:any) => c.id);
      if (!recent) {
        toast.info('No issued certificates yet. Issue one first.');
        return;
      }
      const tpl = (recent.template as any) || 'classic';
      // Directly trigger the live print hook (opens window + downloads printable.html + .json)
      printCert.mutate({ certificateId: recent.id, template: tpl });
      return;
    }

    if (action === 'addTeacherEvaluation') {
      // NEW: 06 People-HR quick action (live)
      window.location.href = '/people-hr/teachers';
      toast.info('Open Teachers page → click a teacher → "+ Add Evaluation" (live)');
      return;
    }
  };

  // Extra handlers for new dialogs (called from JSX buttons)
  const handleAllocateBudget = () => {
    createBudgetLine.mutate({
      name: budgetName || 'Quick Budget Allocation',
      purpose: budgetPurpose || 'operations',
      allocated_amount: parseFloat(budgetAmount) || 50000,
      cost_type: 'variable',
      branch_id: 'branch-1',
    }, {
      onSuccess: () => {
        toast.success(`Budget allocated (${budgetAmount} AFN) — live`);
        setShowBudgetDialog(false);
      },
      onError: (e: any) => toast.error('Budget allocation failed: ' + (e?.message || 'error')),
    });
  };

  const handleAwardScholarship = () => {
    const stu = (students as any[]).find((s: any) => s.id === scholarshipStudentId);
    awardScholarship.mutate({
      scholarshipId: 'sch-1',
      data: {
        student_id: scholarshipStudentId,
        amount: parseFloat(scholarshipAmount) || 12000,
        semester: scholarshipSemester,
        notes: 'Quick scholarship via dashboard',
      },
    }, {
      onSuccess: () => {
        toast.success(`Scholarship awarded to ${stu?.full_name || 'student'} (${scholarshipAmount} AFN)`);
        setShowScholarshipDialog(false);
      },
      onError: (e: any) => toast.error('Award failed: ' + (e?.message || 'error')),
    });
  };

  const handleRecordDonation = () => {
    if (!donationDonorId) {
      toast.error('Please select a donor');
      return;
    }
    const donor = (liveDonors as any[]).find((d: any) => d.id === donationDonorId);
    createDonation.mutate({
      donor_id: donationDonorId,
      amount: parseFloat(donationAmount) || 25000,
      date: donationDate,
      campaign_id: donationCampaignId || undefined,
      branch_id: 'branch-1',
    }, {
      onSuccess: () => {
        toast.success(`Donation recorded live (${donationAmount} AFN) from ${donor?.full_name || 'donor'}`);
        setShowDonationDialog(false);
        setDonationDonorId('');
        setDonationCampaignId('');
        setDonationAmount('25000');
      },
      onError: (e: any) => toast.error('Donation failed: ' + (e?.message || 'error')),
    });
  };

  const handleRegisterStudent = () => {
    if (!regFullName) {
      toast.error('Full name is required');
      return;
    }
    createStudent.mutate({
      full_name: regFullName,
      phone: regPhone || '+93 700 000 000',
      branch_id: 'branch-1',
    } as any, {
      onSuccess: (s: any) => {
        toast.success('Student registered live: ' + (s.full_name || regFullName));
        setShowRegisterDialog(false);
        setRegFullName('');
        setRegPhone('+93 700 000 000');
        window.location.href = '/academic/students';
      },
      onError: (e: any) => toast.error('Registration failed: ' + (e?.message || 'error')),
    });
  };

  if (visibleActions.length === 0) {
    return (
      <div className="text-xs text-muted-foreground">
        No quick actions for current role/permissions.
      </div>
    );
  }

  return (
    <>
      <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-4">
        {visibleActions.map((action: any, idx: number) => {
          const Icon = ACTION_ICONS[action.action] || ClipboardList;
          const href = getHrefForAction(action.action);
          const isLiveMutation = ['recordDonation', 'recordPayment'].includes(action.action);

          const content = (
            <Button
              variant="outline"
              className="w-full justify-start gap-2 h-auto py-3 text-left"
              onClick={() => {
                if (isLiveMutation || ['addVisitor', 'logFollowup', 'newCampaign', 'allocateBudget', 'awardScholarship', 'recordDonation'].includes(action.action)) {
                  handleQuickAction(action.action);
                }
              }}
              disabled={isLiveMutation && (createDonation.isPending || createPayment.isPending)}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <div>
                <div className="font-medium text-sm">{action.label}</div>
                <div className="text-[10px] text-muted-foreground">
                  {action.action === 'approvePromotion' ? 'Open Classes → Promotion tab (live)' : 
                   isLiveMutation ? 'Live backend mutation' : action.label.toLowerCase()}
                </div>
              </div>
            </Button>
          );

          return isLiveMutation || ['addVisitor', 'logFollowup', 'newCampaign', 'recordPayment', 'issueCertificate', 'allocateBudget', 'awardScholarship', 'registerStudent'].includes(action.action) ? (
            <div key={idx}>{content}</div>
          ) : (
            <Link key={idx} to={href}>
              {content}
            </Link>
          );
        })}
      </div>

      {/* Generative Quick Action Dialogs (production quality — replaces prompts) */}
      {/* Add Visitor Dialog */}
      <Dialog open={showVisitorDialog} onOpenChange={setShowVisitorDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Visitor / Lead</DialogTitle>
            <DialogDescription>Quick live registration from dashboard</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Full Name</Label>
              <Input value={visitorName} onChange={(e) => setVisitorName(e.target.value)} placeholder="Visitor name" />
            </div>
            <div>
              <Label>Phone</Label>
              <Input value={visitorPhone} onChange={(e) => setVisitorPhone(e.target.value)} placeholder="+93 700 000 000" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowVisitorDialog(false)}>Cancel</Button>
            <Button onClick={() => {
              if (!visitorName) return;
              createVisitor.mutate({
                full_name: visitorName,
                phone: visitorPhone || '+93 700 000 000',
                source: 'quick-action',
                interested_course: 'General English',
                branch_id: 'branch-1',
              } as any, {
                onSuccess: () => {
                  toast.success(`Visitor added live: ${visitorName}`);
                  setShowVisitorDialog(false);
                  setVisitorName(''); setVisitorPhone('');
                  window.location.href = '/crm/visitors';
                },
                onError: (e: any) => toast.error('Add visitor failed: ' + (e?.message || 'error')),
              });
            }} disabled={!visitorName || createVisitor.isPending}>Add Visitor</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Campaign Dialog */}
      <Dialog open={showCampaignDialog} onOpenChange={setShowCampaignDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New Campaign</DialogTitle>
            <DialogDescription>Quick live funding campaign (donor_manager)</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Campaign Name</Label>
              <Input value={campaignName} onChange={(e) => setCampaignName(e.target.value)} placeholder="Q4 Scholarship Drive" />
            </div>
            <div>
              <Label>Target Amount (AFN)</Label>
              <Input type="number" value={campaignTarget} onChange={(e) => setCampaignTarget(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCampaignDialog(false)}>Cancel</Button>
            <Button onClick={() => {
              const name = campaignName || 'Quick Campaign ' + new Date().getFullYear();
              const target = parseFloat(campaignTarget) || 500000;
              createCampaign.mutate({
                name,
                target_amount: target,
                status: 'active',
                branch_id: 'branch-1',
              } as any, {
                onSuccess: () => {
                  toast.success('Campaign created live: ' + name);
                  setShowCampaignDialog(false);
                  setCampaignName(''); setCampaignTarget('500000');
                  window.location.href = '/funding';
                },
                onError: (e) => toast.error('Campaign failed: ' + (e?.message || 'error')),
              });
            }} disabled={createCampaign.isPending}>Create Campaign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Log Follow-up Dialog — fully live (per 14_ROLE + CRM) */}
      <Dialog open={showFollowupDialog} onOpenChange={setShowFollowupDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Log Follow-up / Add Visitor</DialogTitle>
            <DialogDescription>Quick live follow-up (counselor / receptionist)</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Visitor / Lead Name</Label>
              <Input value={followupVisitorName} onChange={(e) => setFollowupVisitorName(e.target.value)} placeholder="Visitor name" />
            </div>
            <div>
              <Label>Follow-up Note</Label>
              <Input value={followupNote} onChange={(e) => setFollowupNote(e.target.value)} placeholder="Details of contact" />
            </div>
            <div>
              <Label>Next Contact Date</Label>
              <Input type="date" value={followupNextDate} onChange={(e) => setFollowupNextDate(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFollowupDialog(false)}>Cancel</Button>
            <Button
              disabled={!followupVisitorName || !followupNote || createVisitor.isPending}
              onClick={() => {
                const name = followupVisitorName || 'Quick Lead';
                const note = followupNote || 'Quick follow-up';
                const next = followupNextDate || new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10);

                createVisitor.mutate({
                  full_name: name,
                  phone: '+93 700 000 000',
                  source: 'quick-dashboard',
                  interested_course: 'General English',
                  branch_id: 'branch-1',
                } as any, {
                  onSuccess: (v: any) => {
                    const vid = v?.id || v?.visitor_id;
                    if (vid) {
                      createFollowup.mutate({
                        visitorId: vid,
                        data: { note, next_date: next }
                      }, {
                        onSuccess: () => {
                          toast.success(`Follow-up logged for ${name}`);
                          setShowFollowupDialog(false);
                          setFollowupVisitorName(''); setFollowupNote(''); setFollowupNextDate('');
                          window.location.href = '/crm/visitors';
                        }
                      });
                    } else {
                      toast.success(`Visitor created: ${name}`);
                      setShowFollowupDialog(false);
                      window.location.href = '/crm/visitors';
                    }
                  },
                  onError: (e: any) => toast.error('Follow-up failed: ' + (e?.message || 'error')),
                });
              }}
            >
              Log Follow-up
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Record Payment Dialog — live students + real mutation */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Payment (Quick)</DialogTitle>
            <DialogDescription>Live backend payment for active student</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Student</Label>
              <select
                className="w-full border rounded px-3 py-2 text-sm"
                value={paymentStudentId}
                onChange={(e) => setPaymentStudentId(e.target.value)}
              >
                {(students as any[]).map((s: any) => (
                  <option key={s.id} value={s.id}>{s.full_name} ({s.student_code || s.id})</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount (AFN)</Label>
                <Input type="number" value={paymentAmount} onChange={(e) => setPaymentAmount(e.target.value)} />
              </div>
              <div>
                <Label>Method</Label>
                <select className="w-full border rounded px-3 py-2 text-sm" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                  <option value="cash">Cash</option>
                  <option value="bank">Bank Transfer</option>
                  <option value="card">Card</option>
                </select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPaymentDialog(false)}>Cancel</Button>
            <Button
              disabled={!paymentStudentId || !paymentAmount || createPayment.isPending}
              onClick={() => {
                const stu = (students as any[]).find((s: any) => s.id === paymentStudentId);
                createPayment.mutate({
                  student_id: paymentStudentId,
                  amount: paymentAmount,
                  category: 'fee',
                  payment_method: paymentMethod,
                  notes: 'Quick payment via dashboard',
                }, {
                  onSuccess: () => {
                    toast.success(`Payment recorded for ${stu?.full_name || 'student'} (${paymentAmount} AFN)`);
                    setShowPaymentDialog(false);
                  },
                  onError: (e: any) => toast.error('Payment failed: ' + (e?.message || 'error')),
                });
              }}
            >
              Record Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Issue Certificate Dialog — live + template (designer flow) */}
      <Dialog open={showCertDialog} onOpenChange={setShowCertDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Issue Certificate (Quick)</DialogTitle>
            <DialogDescription>Live issuance with template choice</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Student</Label>
              <select
                className="w-full border rounded px-3 py-2 text-sm"
                value={certStudentId}
                onChange={(e) => setCertStudentId(e.target.value)}
              >
                {(students as any[]).map((s: any) => (
                  <option key={s.id} value={s.id}>{s.full_name}</option>
                ))}
              </select>
            </div>
            <div>
              <Label>Certificate No</Label>
              <Input value={certNo} onChange={(e) => setCertNo(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Grade</Label>
                <select className="w-full border rounded px-3 py-2 text-sm" value={certGrade} onChange={(e) => setCertGrade(e.target.value)}>
                  <option>Pass</option><option>Merit</option><option>Distinction</option><option>A</option>
                </select>
              </div>
              <div>
                <Label>Template</Label>
                <select className="w-full border rounded px-3 py-2 text-sm" value={certTemplate} onChange={(e) => setCertTemplate(e.target.value as any)}>
                  <option value="classic">Classic</option>
                  <option value="modern">Modern</option>
                  <option value="minimal">Minimal</option>
                </select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCertDialog(false)}>Cancel</Button>
            <Button
              disabled={!certStudentId || !certNo || issueCertificate.isPending}
              onClick={() => {
                const stu = (students as any[]).find((s: any) => s.id === certStudentId);
                issueCertificate.mutate({
                  studentId: certStudentId,
                  data: { certificate_no: certNo, grade: certGrade, template: certTemplate },
                }, {
                  onSuccess: () => {
                    toast.success(`Certificate issued to ${stu?.full_name} (${certNo}) — ${certTemplate}`);
                    setShowCertDialog(false);
                  },
                  onError: (e: any) => toast.error('Issue failed: ' + (e?.message || 'error')),
                });
              }}
            >
              Issue Certificate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Record Donation Dialog — live donors */}
      <Dialog open={showDonationDialog} onOpenChange={setShowDonationDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Donation (Quick)</DialogTitle>
            <DialogDescription>Live donation from donor</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Donor *</Label>
              <select
                className="w-full border rounded px-3 py-2 text-sm"
                value={donationDonorId}
                onChange={(e) => setDonationDonorId(e.target.value)}
              >
                <option value="">Select donor...</option>
                {(liveDonors as any[]).map((d: any) => (
                  <option key={d.id} value={d.id}>{d.full_name} ({d.type || 'donor'})</option>
                ))}
              </select>
            </div>
            <div>
              <Label>Campaign (optional)</Label>
              <select
                className="w-full border rounded px-3 py-2 text-sm"
                value={donationCampaignId}
                onChange={(e) => setDonationCampaignId(e.target.value)}
              >
                <option value="">General / No campaign</option>
                {(liveCampaigns as any[]).filter((c: any) => c.status === 'active').map((c: any) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount (AFN) *</Label>
                <Input type="number" value={donationAmount} onChange={(e) => setDonationAmount(e.target.value)} />
              </div>
              <div>
                <Label>Date</Label>
                <Input type="date" value={donationDate} onChange={(e) => setDonationDate(e.target.value)} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDonationDialog(false)}>Cancel</Button>
            <Button onClick={handleRecordDonation} disabled={createDonation.isPending || !donationDonorId}>Record Donation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Register Student Dialog — live */}
      <Dialog open={showRegisterDialog} onOpenChange={setShowRegisterDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Register Student (Quick)</DialogTitle>
            <DialogDescription>Live student registration</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Full Name *</Label>
              <Input value={regFullName} onChange={(e) => setRegFullName(e.target.value)} placeholder="Student full name" />
            </div>
            <div>
              <Label>Phone</Label>
              <Input value={regPhone} onChange={(e) => setRegPhone(e.target.value)} placeholder="+93 700 000 000" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRegisterDialog(false)}>Cancel</Button>
            <Button onClick={handleRegisterStudent} disabled={!regFullName || createStudent.isPending}>Register Student</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Allocate Budget Dialog — live */}
      <Dialog open={showBudgetDialog} onOpenChange={setShowBudgetDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Allocate Budget (Quick)</DialogTitle>
            <DialogDescription>Live budget line creation</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Budget Name</Label>
              <Input value={budgetName} onChange={(e) => setBudgetName(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount (AFN)</Label>
                <Input type="number" value={budgetAmount} onChange={(e) => setBudgetAmount(e.target.value)} />
              </div>
              <div>
                <Label>Purpose</Label>
                <select className="w-full border rounded px-3 py-2 text-sm" value={budgetPurpose} onChange={(e) => setBudgetPurpose(e.target.value)}>
                  <option value="operations">Operations</option>
                  <option value="teacher_salary">Teacher Salary</option>
                  <option value="scholarship">Scholarship</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBudgetDialog(false)}>Cancel</Button>
            <Button onClick={handleAllocateBudget} disabled={createBudgetLine.isPending}>Allocate Budget</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Award Scholarship Dialog — live */}
      <Dialog open={showScholarshipDialog} onOpenChange={setShowScholarshipDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Award Scholarship (Quick)</DialogTitle>
            <DialogDescription>Live scholarship award (updates tuition)</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Student</Label>
              <select
                className="w-full border rounded px-3 py-2 text-sm"
                value={scholarshipStudentId}
                onChange={(e) => setScholarshipStudentId(e.target.value)}
              >
                {(students as any[]).map((s: any) => (
                  <option key={s.id} value={s.id}>{s.full_name}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount (AFN)</Label>
                <Input type="number" value={scholarshipAmount} onChange={(e) => setScholarshipAmount(e.target.value)} />
              </div>
              <div>
                <Label>Semester</Label>
                <Input value={scholarshipSemester} onChange={(e) => setScholarshipSemester(e.target.value)} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowScholarshipDialog(false)}>Cancel</Button>
            <Button onClick={handleAwardScholarship} disabled={awardScholarship.isPending}>Award Scholarship</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
