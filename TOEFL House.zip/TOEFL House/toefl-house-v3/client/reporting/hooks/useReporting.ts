import { useQuery, useMutation } from '@tanstack/react-query';

const API_BASE = '/api';

async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers },
    credentials: 'include',
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export function useDashboardSummary() {
  return useQuery({
    queryKey: ['reporting', 'dashboard'],
    queryFn: () => request<any>('/dashboard'),
    staleTime: 20_000,
  });
}

export function useGenerateReport() {
  return useMutation({
    mutationFn: async ({ type, params }: { type: string; params?: any }) => {
      if (type === 'financial') {
        return request('/reports/financial', {
          method: 'POST',
          body: JSON.stringify(params),
        });
      }
      if (type === 'payroll') {
        return request('/reports/payroll', {
          method: 'POST',
          body: JSON.stringify(params),
        });
      }
      if (type === 'transcript' && params?.studentId) {
        return request(`/reports/students/${params.studentId}/transcript`);
      }
      if (type === 'roster' && params?.classId) {
        return request(`/reports/classes/${params.classId}/roster`);
      }
      if (type === 'certificate' && params?.certificateId) {
        return request(`/reports/certificates/${params.certificateId}?template=${params.template || 'classic'}`);
      }
      throw new Error('Unknown report type');
    },
  });
}

export function useDashboard() {
  return useQuery({
    queryKey: ['reporting', 'dashboard-full'],
    queryFn: () => request<any>('/dashboard'),
    staleTime: 15_000,
  });
}