<?php

namespace App\Listeners;

use App\Events\TeacherCreated;
use App\Modules\Iam\Models\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

/**
 * Send Teacher Created Notification Listener
 *
 * Sends notifications when a new teacher is created.
 */
class SendTeacherCreatedNotification implements ShouldQueue
{
    use InteractsWithQueue;

    /**
     * Handle the event.
     */
    public function handle(TeacherCreated $event): void
    {
        $teacher = $event->teacher;

        try {
            // Notify branch administrators
            $admins = $teacher->branch->users()
                ->whereHas('roles', function ($query) {
                    $query->whereIn('name', ['admin', 'hr_manager']);
                })
                ->get();

            foreach ($admins as $admin) {
                Notification::create([
                    'user_id' => $admin->id,
                    'type' => 'success',
                    'title' => 'New Teacher Added',
                    'message' => "A new teacher '{$teacher->full_name}' has been added to your branch.",
                    'data' => [
                        'teacher_id' => $teacher->id,
                        'teacher_name' => $teacher->full_name,
                        'branch_name' => $teacher->branch->name,
                    ],
                    'action_url' => "/teachers/{$teacher->id}",
                    'read' => false,
                ]);
            }

            Log::info("Teacher created notifications sent for teacher {$teacher->id}");
        } catch (\Exception $e) {
            Log::error("Failed to send teacher created notifications: " . $e->getMessage());
        }
    }
}
