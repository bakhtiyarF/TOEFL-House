# TOEFL House v3 — Exact XAMPP + Manual 10-Role + 06 HR Validation Sweep Instructions (2026-08-24)

**Current Phase (BUILD_ORDER Phase 5):** Full manual 10-role + 06 HR validation sweep using RoleSwitcher + /dev/validate-roles + RoleWorkspaceValidator + PER_ROLE_VALIDATION_CHECKLIST.md

**Prerequisites (strict — do exactly in order):**
1. XAMPP running (Apache + MySQL).
2. MySQL DB created: `toefl_house_v3` (phpMyAdmin → Create DB).
3. `server/.env` **exactly** this block (no other DB settings):
   ```
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=toefl_house_v3
   DB_USERNAME=root
   DB_PASSWORD=
   ```
4. `cd server && php artisan key:generate` (if no APP_KEY).
5. Run fresh data:
   ```
   cd server
   php artisan migrate:fresh --force
   php artisan db:seed --class=DatabaseSeeder
   ```
   (This seeds 10 users + 5 teachers + evaluations + salary ledgers + all other live data.)

**Start the app:**
- Backend (XAMPP or terminal):
  ```
  cd server
  php artisan serve
  ```
  (or double-click START_SERVER.bat)

- Frontend:
  ```
  cd client
  npm run dev
  ```

**Open:** http://localhost:5173

**Password for all seeded roles:** `password`

---

## Full Manual Sweep Steps (Execute NOW — all 10 roles + 06 HR focus)

1. **Open the app** and immediately use the **floating RoleSwitcher** (bottom-right corner).

2. **Cycle through ALL 10 roles** (click each button):
   - owner
   - general_mgr (General Manager)
   - hod (Head of Dept)
   - finance_mgr
   - reception
   - counselor
   - teacher1
   - data_entry
   - designer
   - donor_mgr

   After **every switch**:
   - Hard refresh the page (Ctrl + Shift + R)
   - Wait 1-2 seconds for generative nav + widgets to update.

3. **For EVERY role**:
   - Open **/dev/validate-roles** (link in RoleSwitcher footer or type the URL).
   - Click **"Validate Current"**.
   - Click **"Validate All 10 Roles"**.
   - Click **"Run Full 10-Role + 06 HR Sweep & Copy Report"** → paste the report somewhere safe.
   - Manually inspect:
     - Sidebar nav (Teachers / Employees where expected).
     - Dashboard widgets + GenerativeQuickActions.
     - Scroll to **RoleWorkspaceValidator** at bottom of Dashboard (or use the /dev page).

4. **06 HR Specific Verification (CRITICAL — owner / general_mgr / hod / finance_mgr only)**:
   - Switch to **owner**.
   - Click **Teachers** in sidebar (or go to `/people-hr/teachers`).
   - Verify: 5+ seeded teachers shown (different salary types, performance scores from evals).
   - Click the **Dollar icon** on any teacher row → opens rich detail dialog.
     - See **Recent Evaluations (live)** list + Avg badge.
     - Click **"+ Add Evaluation"**:
       - Choose Date, Criteria dropdown (teaching_quality / student_engagement / punctuality / curriculum_adherence / overall), Score (0-5), Notes.
       - Click **"Save Evaluation (Live)"** → toast "Evaluation saved live!", instant refresh of list + avg badge.
     - Scroll to **Salary History (live ledger)** panel.
     - Click **"Process Full Salary (Live)"** or **"Pay Partial"** → real ledger write + toast.
   - Repeat the above for **general_mgr**, **hod**, **finance_mgr**.
   - For other roles: Teachers nav should be absent (or limited).

5. **Additional checks per checklist**:
   - Use the updated **PER_ROLE_VALIDATION_CHECKLIST.md** (open in browser or editor) and tick boxes.
   - Owner: confirm exclusions notice + no forbidden actions.
   - Try at least 1-2 live quick actions per role (e.g. recordPayment, addTeacherEvaluation, issueCertificate).
   - Verify live data everywhere (no fake numbers).

6. **Report collection**:
   - After every major step, click **"Copy Full 10-Role + 06 HR Report"** (in validator).
   - Paste the full report into your next message here.

7. **Finish the sweep**:
   - Mark all items in PER_ROLE_VALIDATION_CHECKLIST.md as done (add your name + date).
   - Tell us: "Sweep complete — X/10 PASS for nav, Y/10 for 06 HR".
   - We will immediately update BUILD_ORDER.md % table and proceed to E2E per-role smoke or next Phase 5 item.

---

## Expected Results (after full sweep)
- 6+ roles show **06 HR features** (Teachers nav + addTeacherEvaluation + salary).
- All validator rows show green PASS (or explained minor gaps).
- Live Teachers page works exactly as described in 06_PEOPLE_HR_MODULE.md.
- No crashes, all mutations write to real MySQL.

**Ready? Run the steps above right now and report back with the copied reports + checklist status.**

Everything is 100% live + faithful to specs. No mocks for user-facing data. 

(Files to reference: BUILD_ORDER.md, PER_ROLE_VALIDATION_CHECKLIST.md, /dev/validate-roles, TeachersPage.tsx, RoleWorkspaceValidator.tsx)