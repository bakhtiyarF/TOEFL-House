#!/bin/bash
# Simple production env validator
# Run after copying .env.production.example to .env

set -e

echo "=== TOEFL House ERP v3 Env Validator ==="

if [ ! -f .env ]; then
  echo "❌ .env not found"
  exit 1
fi

source .env 2>/dev/null || true

errors=0

check() {
  if [ -z "${!1}" ] || [ "${!1}" = "CHANGE_ME" ] || [ "${!1}" = "YOUR_STRONG_DB_PASSWORD" ]; then
    echo "❌ $1 is not set or is placeholder"
    ((errors++))
  else
    echo "✅ $1"
  fi
}

echo "Checking critical production settings..."

check APP_ENV
check APP_DEBUG
check APP_TIMEZONE
check DB_DATABASE
check DB_USERNAME
check DB_PASSWORD
check APP_KEY

if [ "$APP_DEBUG" != "false" ]; then
  echo "❌ APP_DEBUG must be false in production"
  ((errors++))
fi

if [ "$APP_TIMEZONE" != "Asia/Kabul" ]; then
  echo "⚠️  APP_TIMEZONE should be Asia/Kabul"
fi

if [ $errors -gt 0 ]; then
  echo "❌ $errors errors found. Fix before deploying."
  exit 1
else
  echo "✅ Environment looks good for production."
fi
