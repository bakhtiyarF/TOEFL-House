#!/bin/bash
# TOEFL House ERP v3 — Simple Production Deploy Script
# Per 13_INFRASTRUCTURE_AND_DEPLOYMENT.md §5
#
# Usage (on server):
#   ./scripts/deploy.sh v3.0.0-launch
#
# Assumes:
# - Git tag already created
# - .env configured for production
# - sudo access for systemctl / nginx

set -euo pipefail

TAG=${1:-latest}
APP_DIR="/var/www/toefl-house-v3"
BACKUP_DIR="/var/backups/toefl"

echo "=== Deploying TOEFL House ERP v3 — $TAG ==="

# 1. Backup current DB (13 §8)
echo "[1/6] Creating database backup..."
mkdir -p "$BACKUP_DIR"
php artisan backup:database --path="$BACKUP_DIR/pre-deploy-$(date +%Y%m%d-%H%M).sql" || true

# 2. Pull code
echo "[2/6] Pulling $TAG..."
cd "$APP_DIR"
git fetch --tags
git checkout "$TAG"

# 3. Install dependencies (no dev)
echo "[3/6] Installing production dependencies..."
cd server
composer install --no-interaction --prefer-dist --no-dev --optimize-autoloader

cd ../client
npm ci --production
npm run build

# 4. Laravel maintenance + migrate
echo "[4/6] Running migrations (with maintenance window)..."
cd ../server
php artisan down || true
php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 5. Permissions + storage
echo "[5/6] Fixing permissions..."
chown -R www-data:www-data storage bootstrap/cache
chmod -R 775 storage bootstrap/cache
php artisan storage:link

# 6. Restart services
echo "[6/6] Restarting services..."
php artisan up
sudo systemctl restart php8.3-fpm nginx || sudo systemctl restart php-fpm nginx || true
sudo systemctl restart toefl-queue || true   # if using custom queue service

echo "✅ Deploy of $TAG complete."
echo "   Verify: https://your-domain.com"
echo "   Check logs: tail -f storage/logs/laravel.log"